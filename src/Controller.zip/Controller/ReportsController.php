<?php

/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Utility\Security;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;
use Cake\Mailer\Email;
use Cake\ORM\Table;
use Cake\Datasource\Exception\RecordNotFoundException;


/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link http://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */
class ReportsController extends AppController
{



    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Security');
        $this->loadModel('UserTypes');
        $this->loadModel('Users');
        $this->loadModel('Customers');
        $this->loadModel('CustomerContacts');
        $this->loadModel('Products');
        $this->loadModel('Quotes');
        $this->loadModel('QuoteLineItems');
        $this->loadModel('QuoteLineItemMeta');
        $this->loadModel('Orders');
        $this->loadModel('OrderItems');
        $this->loadModel('OrderItemStatus');
        $this->loadModel('Calculators');
        $this->loadModel('Vendors');
        $this->loadModel('Shipments');
        $this->loadModel('SherryCache');
        $this->loadModel('SherryBatches');
        $this->loadModel('Fabrics');
        $this->loadModel('Linings');
        $this->loadModel('FabricMarkupRules');
        $this->loadModel('Assemblies');
        $this->loadModel('Bedspreads');
        $this->loadModel('BedspreadSizes');
        $this->loadModel('BsDataMap');
        $this->loadModel('CubicleCurtains');
        $this->loadModel('CubicleCurtainSizes');
        $this->loadModel('MiscellaneousProducts');
        $this->loadModel('Services');
        $this->loadModel('TrackSystems');
        $this->loadModel('WindowTreatments');
        $this->loadModel('QuoteNotes');
        $this->loadModel('QuoteDiscounts');
        $this->loadModel('QuoteLineItemNotes');
        $this->loadModel('LibraryImages');
        $this->loadModel('LibraryCategories');
        $this->loadModel('CcDataMap');
        $this->loadModel('WtDataMap');
        $this->loadModel('WindowTreatmentSizes');
        $this->loadModel('QuoteBomRequirements');
        $this->loadModel('MaterialPurchases');
        $this->loadModel('MaterialInventory');
        $this->loadModel('MaterialUsages');
        $this->loadModel('Projects');
        $this->loadModel('ShippingMethods');
        $this->loadModel('Msr');
        $this->loadModel('QuoteTypes');
        $this->loadModel('ProductClasses');
        $this->loadModel('ProductSubclasses');
        $this->loadModel('OrderLineItems');

        /** PPSASCRUM-62 start **/
        $this->loadModel('ShipTo');
        $this->loadModel('Facility');
        /** PPSASCRUM-62 end **/
    }


    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        /**PPSA-40 start **/
        if ($this->request->action == 'msr' || $this->request->action == 'bulkeditmsr' || $this->request->action == 'productiondetailbacklog' || $this->request->action == 'backlogreport' || $this->request->action == 'bookingreport' || $this->request->action == 'backlogsummary' || $this->request->action == 'getmsrlist' || $this->request->action == 'consolidatedquotes' || $this->request->action == 'consolidateddraftquotes' || $this->request->action == 'bigquotes' || $this->request->action == 'quotesnewlines') {

            $this->Security->config('unlockedActions', ['msr', 'getmsrlist', 'backlogreport', 'bookingreport', 'backlogsummary', 'productiondetailbacklog', 'bulkeditmsr', 'consolidatedquotes', 'consolidateddraftquotes', 'bigquotes', 'quotesnewlines']);
            $this->eventManager()->off($this->Csrf);
            $this->eventManager()->off($this->Security);
        }
        /**PPSA-40 end **/
    }


    public function index() {}

	public function productiondetailbacklog(){
        $productMap = array(
            'cubicle-curtain' => 'Cubicle Curtain',
            'box-pleated' => 'Box Pleated Valance',
            'straight-cornice' => 'Straight Cornice',
            'bedspread' => 'Calculated Bedspread',
            'bedspread-manual' => 'Manually Entered Bedspread',
            'pinch-pleated' => 'Pinch Pleated Drapery'
        );

        $allsettings = $this->getsettingsarray();

        if ($this->request->data) {
            $this->autoRender = false;

            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");

            $objPHPExcel = new \PHPExcel();
            $objPHPExcel->setActiveSheetIndex(0);


            $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'ORDER #');
            $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'QUOTE #');

            $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'STAGE');

            $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'PM');
            $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'CUSTOMER');
            $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'CUSTOMER PO');
            $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'RECIPIENT');
            $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'SHIP DATE');

            $objPHPExcel->getActiveSheet()->SetCellValue('I1', 'SCHEDULED'); //moved from AB

            $objPHPExcel->getActiveSheet()->SetCellValue('J1', 'BOOK DATE');
            $objPHPExcel->getActiveSheet()->SetCellValue('K1', 'BATCH');
            $objPHPExcel->getActiveSheet()->SetCellValue('L1', 'LINE');

            $objPHPExcel->getActiveSheet()->SetCellValue('M1', 'LOCATION');

            $objPHPExcel->getActiveSheet()->SetCellValue('N1', 'QTY');
            $objPHPExcel->getActiveSheet()->SetCellValue('O1', 'UNIT');
            $objPHPExcel->getActiveSheet()->SetCellValue('P1', 'LINE ITEM');
            $objPHPExcel->getActiveSheet()->SetCellValue('Q1', 'FABRIC');
            $objPHPExcel->getActiveSheet()->SetCellValue('R1', 'COLOR');

            $objPHPExcel->getActiveSheet()->SetCellValue('S1', 'CUT WIDTH');
            $objPHPExcel->getActiveSheet()->SetCellValue('T1', 'FIN WIDTH');

            $objPHPExcel->getActiveSheet()->SetCellValue('U1', 'LENGTH');

            $objPHPExcel->getActiveSheet()->SetCellValue('V1', 'TOTAL LF');
            $objPHPExcel->getActiveSheet()->SetCellValue('W1', 'YDS / UNIT');
            $objPHPExcel->getActiveSheet()->SetCellValue('X1', 'TOTAL YARDS');
            $objPHPExcel->getActiveSheet()->SetCellValue('Y1', 'BASE');
            $objPHPExcel->getActiveSheet()->SetCellValue('Z1', 'TIERS');
            $objPHPExcel->getActiveSheet()->SetCellValue('AA1', 'ADJ PRICE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AB1', 'EXT PRICE');



            $objPHPExcel->getActiveSheet()->SetCellValue('AC1', 'PRODUCED');
            $objPHPExcel->getActiveSheet()->SetCellValue('AD1', 'SHIPPED');

            $objPHPExcel->getActiveSheet()->SetCellValue('AE1', 'TRACKING #');

            $objPHPExcel->getActiveSheet()->SetCellValue('AF1', 'INVOICED');

            $objPHPExcel->getActiveSheet()->SetCellValue('AG1', 'LINE NOTES');

            $objPHPExcel->getActiveSheet()->SetCellValue('AH1', 'BS QUILT');
            $objPHPExcel->getActiveSheet()->SetCellValue('AI1', 'BS MAT SIZE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AJ1', 'BS DROP');
            $objPHPExcel->getActiveSheet()->SetCellValue('AK1', 'BS WIDTHS EA');
            $objPHPExcel->getActiveSheet()->SetCellValue('AL1', 'BS TOP WIDTHS EA');
            $objPHPExcel->getActiveSheet()->SetCellValue('AM1', 'BS TOP WIDTHS CL');
            $objPHPExcel->getActiveSheet()->SetCellValue('AN1', 'BS TOP CUT SIZE W');
            $objPHPExcel->getActiveSheet()->SetCellValue('AO1', 'BS TOP CUT SIZE L');
            $objPHPExcel->getActiveSheet()->SetCellValue('AP1', 'BS DROP CUT SIZE W');
            $objPHPExcel->getActiveSheet()->SetCellValue('AQ1', 'BS DROP CUT SIZE L');
            $objPHPExcel->getActiveSheet()->SetCellValue('AR1', 'CC MESH SIZE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AS1', 'CC MESH COLOR');
            $objPHPExcel->getActiveSheet()->SetCellValue('AT1', 'CC WIDTHS EA');
            $objPHPExcel->getActiveSheet()->SetCellValue('AU1', 'CC CUT LENGTH');
            $objPHPExcel->getActiveSheet()->SetCellValue('AV1', 'CC ACTUAL LF');


            $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(40);
            $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(55);
            $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15); //SCHEDULED moved from AB

            $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(75);

            $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(30);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(15);


            $objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AD')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AE')->setWidth(29);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AF')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AG')->setWidth(70);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AH')->setWidth(32);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AI')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AJ')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AK')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AL')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AM')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AN')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AO')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AP')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AQ')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AR')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AS')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AT')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AU')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AV')->setWidth(16);


            $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(22);
            $objPHPExcel->getActiveSheet()->getStyle('A1:AV1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);

            $objPHPExcel->getActiveSheet()->getStyle('A1:AV1')->applyFromArray(
                array(
                    'fill' => array(
                        'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'F8CBAD')
                    )
                )
            );


            $rowCount = 2;

            $conditions = array();

            $conditions += array('status !=' => 'Canceled');

            if ((isset($this->request->data['datestart']) && strlen(trim($this->request->data['datestart'])) > 0) && (isset($this->request->data['dateend']) && strlen(trim($this->request->data['dateend'])) > 0)) {
                $conditions += array('created >=' => strtotime($this->request->data['datestart'] . ' 00:00:00'));
                $conditions += array('created <=' => strtotime($this->request->data['dateend'] . ' 23:59:59'));
            }

            if (isset($this->request->data['quotenumber']) && strlen(trim($this->request->data['quotenumber'])) > 0) {
            }

            if (isset($this->request->data['ordernumber']) && strlen(trim($this->request->data['ordernumber'])) > 0) {
            }

            if (isset($this->request->data['clientponumber']) && strlen(trim($this->request->data['clientponumber'])) > 0) {
            }


            if (isset($this->request->data['customer']) && count($this->request->data['customer']) > 0) {
                if (count($this->request->data['customer']) == 1) {
                    $conditions += array('customer_id' => $this->request->data['customer'][0]);
                } elseif (count($this->request->data['customer']) > 1) {
                    $conditions += array('customer_id IN' => $this->request->data['customer']);
                }
            }

            if (isset($this->request->data['hciagent']) && count($this->request->data['hciagent']) > 0) {
                if (count($this->request->data['hciagent']) == 1) {
                    $conditions += array('user_id' => $this->request->data['hciagent'][0]);
                } elseif (count($this->request->data['hciagent']) > 1) {
                    $conditions += array('user_id IN' => $this->request->data['hciagent']);
                }
            }

            $orderLookup = $this->Orders->find('all', ['conditions' => $conditions, 'order' => ['order_number' => 'asc']])->toArray();

            foreach ($orderLookup as $orderRow) {

                $quoteItemsLoop = $this->QuoteLineItems->find('all', ['conditions' => ['quote_id' => $orderRow['quote_id']], 'order' => ['line_number' => 'asc']])->toArray();

                $quoteData = $this->Quotes->get($orderRow['quote_id'])->toArray();

                $customer = $this->Customers->get($orderRow['customer_id'])->toArray();
                $thisCustomer = $this->Customers->get($orderRow['customer_id'])->toArray();

                foreach ($quoteItemsLoop as $quoteItem) {
                    if ($quoteItem['parent_line'] == 0) {

                        $orderItemFind = $this->OrderItems->find('all', ['conditions' => ['quote_line_item_id' => $quoteItem['id']]])->toArray();
                        foreach ($orderItemFind as $orderItem) {

                            //look for BATCHES, if found, loop through those, then loop through the remainders or unbatched items
                            $batchesScheduled = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status IN' => ['Scheduled', 'Completed', 'Invoiced', 'Shipped']]])->toArray();
                            $qtyShipped = 0;
                            $qtyInvoiced = 0;
                            $qtyCompleted = 0;
                            $qtyScheduled = 0;

                            $loop = array(
                                'batches' => array(),
                                'unbatched' => 0
                            );

                            $scheduledBatchesThisLine = 0;

                            foreach ($batchesScheduled as $batchData) {
                                switch ($batchData['status']) {
                                    case 'Shipped':
                                        $qtyShipped = ($qtyShipped + intval($batchData['qty_involved']));
                                        break;
                                    case 'Invoiced':
                                        $qtyInvoiced = ($qtyInvoiced + intval($batchData['qty_involved']));
                                        break;
                                    case 'Scheduled':
                                        $qtyScheduled = ($qtyScheduled + intval($batchData['qty_involved']));
                                        $loop['batches'][] = array('batchid' => $batchData['sherry_batch_id'], 'qty' => $batchData['qty_involved'], 'scheduledTS' => $batchData['time']);
                                        $scheduledBatchesThisLine++;
                                        break;
                                    case 'Completed':
                                        $qtyCompleted = ($qtyCompleted + intval($batchData['qty_involved']));
                                        break;
                                }
                            }

                            //loop back through again to add Shipped or Invoiced timestamps to batches that have them
                            foreach ($batchesScheduled as $batchData) {
                                switch ($batchData['status']) {
                                    case 'Shipped':
                                        foreach ($loop['batches'] as $num => $batchloopitem) {
                                            if ($batchloopitem['batchid'] == $batchData['sherry_batch_id']) {
                                                $loop['batches'][$num]['shippedTS'] = $batchData['time'];
                                            }
                                        }
                                        break;
                                    case 'Invoiced':
                                        foreach ($loop['batches'] as $num => $batchloopitem) {
                                            if ($batchloopitem['batchid'] == $batchData['sherry_batch_id']) {
                                                $loop['batches'][$num]['invoicedTS'] = $batchData['time'];
                                            }
                                        }
                                        break;
                                }
                            }

                            $remainingUnscheduled = (intval($quoteItem['qty']) - $qtyScheduled);
                            $remainingUninvoiced = (intval($quoteItem['qty']) - $qtyInvoiced);
                            $remainingUnshipped = (intval($quoteItem['qty']) - $qtyShipped);
                            $remainingIncompleteScheduled = (intval($quoteItem['qty']) - $qtyCompleted);

                            $loop['unbatched'] = $remainingUnscheduled;


                            $itemMetas = $this->QuoteLineItemMeta->find('all', ['conditions' => ['quote_item_id' => $quoteItem['id']]])->toArray();
                            $metaArray = array();
                            foreach ($itemMetas as $meta) {
                                $metaArray[$meta['meta_key']] = $meta['meta_value'];
                            }

                            if ($quoteItem['product_type'] != 'custom' && $quoteItem['product_type'] != 'services' && $quoteItem['product_type'] != 'track_systems') {


                                if ($metaArray['fabrictype'] != 'none' && $metaArray['fabrictype'] != 'typein') {

                                    if (isset($metaArray['fabricid']) && strlen(trim($metaArray['fabricid'])) > 0 && $metaArray['fabricid'] != '0') {
                                        $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                    } else {
                                        $thisFabric = array('fabric_name' => '', 'color' => '');
                                    }

                                    //$thisFabric=$this->Fabrics->get($metaArray['fabricid'])->toArray();
                                } elseif ($metaArray['fabrictype'] == 'typein') {
                                    $thisFabric = array('fabric_name' => $metaArray['fabric_name'], 'color' => $metaArray['fabric_color']);
                                } else {
                                    $thisFabric = array('fabric_name' => '', 'color' => '');
                                }
                            } else {
                                if ($metaArray['fabrictype'] != 'none' && $metaArray['fabrictype'] != 'typein') {
                                    if (isset($metaArray['fabricid']) && strlen(trim($metaArray['fabricid'])) > 0 && $metaArray['fabricid'] != '0') {
                                        $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                    } else {
                                        $thisFabric = array('fabric_name' => '', 'color' => '');
                                    }
                                } elseif ($metaArray['fabrictype'] == 'typein') {
                                    $thisFabric = array('fabric_name' => $metaArray['fabric_name'], 'color' => $metaArray['fabric_color']);
                                } else {
                                    $thisFabric = array('fabric_name' => '', 'color' => '');
                                }
                            }



                            $thisbookingdate = '';

                            //lookup the original Order Item Status for this line item and get the date value
                            $itemstatuslookup = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Not Started']])->toArray();
                            foreach ($itemstatuslookup as $itemstatusrow) {
                                //$thisbookingdate=date('n/j/Y',$itemstatusrow['time']);
                                $bookDateTimeObj = new \DateTime();
                                $bookDateTimeObj->setTimestamp($itemstatusrow['time']);

                                $thisbookingdate = \PHPExcel_Shared_Date::PHPToExcel($bookDateTimeObj);
                            }


                            $customerValue = $thisCustomer['company_name'];
                            $customerPOValue = $orderRow['po_number'];
                            $facilityValue = $orderRow['facility'];


                            $quoteNumberValue = '';
                            if ($quoteData['revision'] > 0) {
                                $quoteNumberValue = $quoteData['quote_number'] . "\n[REV " . $quoteData['revision'] . "]";
                            } else {
                                $quoteNumberValue = $quoteData['quote_number'];
                            }



                            if ($orderRow['due'] < 1000) {
                                $shipDateValue = '';
                            } else {
                                //$shipDateValue=date('n/d/Y',$orderRow['due']);
                                $dueDateTimeObj = new \DateTime();
                                $dueDateTimeObj->setTimestamp($orderRow['due']);
                                $shipDateValue = \PHPExcel_Shared_Date::PHPToExcel($dueDateTimeObj);
                            }

                            $lineNumberValue = $quoteItem['line_number'];
                            $locationValue = $quoteItem['room_number'];
                            $unitValue = $quoteItem['unit'];
                            $itemDescription = '';

                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

                            if ($metaArray['lineitemtype'] == 'calculator') {
                                if ($metaArray['calculator-used'] == "straight-cornice") {
                                    $itemDescription .= $metaArray['cornice-type'] . " Cornice";
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                    $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];
                                    $welts = '';
                                    if ($metaArray['welt-top'] == '1' && $metaArray['welt-bottom'] == '1') {
                                        $welts = "Top + Bottom";
                                    } else {
                                        if ($metaArray['welt-top'] == '1') {
                                            $welts = "Top Only";
                                        } elseif ($metaArray['welt-bottom'] == '1') {
                                            $welts = "Bottom Only";
                                        }
                                    }
                                    if ($welts != '') {
                                        $itemDescription .= "<br><b>Welts:</b> " . $welts;
                                    } else {
                                        $itemDescription .= "<br><b>Welts:</b> None";
                                    }
                                    if ($metaArray['individual-nailheads'] == '1') {
                                        $itemDescription .= "<br>Individual Nailheads";
                                    }
                                    if ($metaArray['nailhead-trim'] == '1') {
                                        $itemDescription .= "<br>Nailhead Trim";
                                    }
                                    if ($metaArray['covered-buttons'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['covered-buttons-count'] . " Covered Buttons";
                                    }

                                    if ($metaArray['horizontal-straight-banding'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['horizontal-straight-banding-count'] . " H Straight Banding";
                                    }
                                    if ($metaArray['horizontal-shaped-banding'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['horizontal-shaped-banding-count'] . " H Shaped Banding";
                                    }
                                    if ($metaArray['extra-welts'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['extra-welts-count'] . " Extra Welts";
                                    }
                                    if ($metaArray['trim-sewn-on'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['trim-lf'] . " LF Sewn-On Trim";
                                    }
                                    if ($metaArray['tassels'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['tassels-count'] . " Tassels";
                                    }
                                    if ($metaArray['drill-holes'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['drill-hole-count'] . " Drill Holes";
                                    }
                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "bedspread" || $metaArray['calculator-used'] == "bedspread-manual") {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Up-the-Roll";
                                    }

                                    $itemDescription .= "<br>";
                                    if (isset($metaArray['style']) && strlen(trim($metaArray['style'])) > 0) {
                                        $itemDescription .= "Style: " . $metaArray['style'];
                                    }
                                    if (isset($metaArray['quilted']) && $metaArray['quilted'] == '1') {
                                        $itemDescription .= "<br>Quilted";
                                        if (isset($metaArray['quilting-pattern']) && strlen(trim($metaArray['quilting-pattern'])) > 0) {
                                            $itemDescription .= ", " . $metaArray['quilting-pattern'];
                                        }
                                        if (isset($metaArray['matching-thread']) && $metaArray['matching-thread'] == '1') {
                                            $itemDescription .= ", Matching Thread";
                                        }
                                        $itemDescription .= ", " . $thisFabric['bs_backing_material'] . " Backing";
                                    } else {
                                        $itemDescription .= "<br>Unquilted";
                                    }

                                    $itemDescription .= "<br>Mattress: ";
                                    if (!isset($metaArray['custom-top-width-mattress-w'])) {
                                        $itemDescription .= "36&quot;";
                                    } else {
                                        $itemDescription .= $metaArray['custom-top-width-mattress-w'] . "&quot;";
                                    }

                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "box-pleated") {
                                    $itemDescription .= $metaArray['valance-type'] . " Valance";

                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    $itemDescription .= "<br>" . $metaArray['pleats'] . " Pleats";

                                    $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                    $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];

                                    if ($metaArray['straight-banding'] == 1) {
                                        $itemDescription .= "<br>Straight Banding";
                                    }
                                    if ($metaArray['shaped-banding'] == 1) {
                                        $itemDescription .= "<Br>Shaped Banding";
                                    }
                                    if ($metaArray['trim-sewn-on'] == 1) {
                                        $itemDescription .= "<br>Sewn-On Trim";
                                    }
                                    if ($metaArray['welt-covered-in-fabric'] == 1) {
                                        $itemDescription .= "<br>Welt Covered In Fabric";
                                    }
                                    if ($metaArray['contrast-fabric-inside-pleat'] == 1) {
                                        $itemDescription .= "<br>Contrast Fabric Inside Pleat";
                                    }
                                    if (isset($metaArray['vert-repeat']) && floatval($metaArray['vert-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vert-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "cubicle-curtain") {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    if ($metaArray['mesh'] > 0 && $metaArray['mesh'] != '') {
                                        $itemDescription .= "<br><b>Mesh:</b> " . $metaArray['mesh'] . "&quot; " . $metaArray['mesh-color'] . " (" . str_replace(" Mesh", "", $metaArray['mesh-type']) . ")";
                                    }
                                    if ($metaArray['mesh-type'] == 'None') {
                                        $itemDescription .= "<br>NO MESH";
                                    }
                                    if ($metaArray['mesh-type'] == 'Integral Mesh') {
                                        $itemDescription .= "<br>INTEGRAL MESH";
                                    }
                                    if ($metaArray['liner'] == 1) {
                                        $itemDescription .= "<br>Liner";
                                    }
                                    if ($metaArray['nylon-mesh'] == 1) {
                                        $itemDescription .= "<br>Nylon Mesh";
                                    }
                                    if ($metaArray['angled-mesh'] == 1) {
                                        $itemDescription .= "<br>Angled Mesh";
                                    }
                                    if ($metaArray['mesh-frame'] != 'No Frame') {
                                        $itemDescription .= "<br><b>Mesh Frame:</b> " . $metaArray['mesh-frame'];
                                    }
                                    if ($metaArray['hidden-mesh'] == 1) {
                                        $itemDescription .= "<br>Hidden Mesh";
                                    }

                                    if ($metaArray['snap-tape'] != "None") {
                                        $itemDescription .= "<br>" . $metaArray['snap-tape'] . " Snap Tape (" . $metaArray['snaptape-lf'] . ")";
                                    }
                                    if ($metaArray['velcro'] != 'None') {
                                        $itemDescription .= "<br>" . $metaArray['velcro'] . " Velcro (" . $metaArray['velcro-lf'] . " LF)";
                                    }
                                    if ($metaArray['weights'] == 1) {
                                        $itemDescription .= "<br>" . $metaArray['weight-count'] . " Weights";
                                    }
                                    if ($metaArray['magnets'] == 1) {
                                        $itemDescription .= "<br>" . $metaArray['magnet-count'] . " Magnets";
                                    }
                                    if ($metaArray['banding'] == 1) {
                                        $itemDescription .= "<br>Banding";
                                    }
                                    if ($metaArray['buttonholes'] == 1) {
                                        $itemDescription .= "<br>" . $metaArray['buttonhole-count'] . " Buttonholes";
                                    }
                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == 'pinch-pleated') {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['unit-of-measure'] == 'pair') {
                                        $itemDescription .= "<br>Pair";
                                    } elseif ($metaArray['unit-of-measure'] == 'panel') {
                                        $itemDescription .= "<br>" . $metaArray['panel-type'] . " Panel";
                                    }
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    if (isset($metaArray['linings_id']) && floatval($metaArray['linings_id']) > 0) {
                                        $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                        $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];
                                    }
                                    $itemDescription .= "<br><b>Hardware:</b> " . ucfirst($metaArray['hardware']);
                                    if ($metaArray['trim-sewn-on'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['trim-lf'] . " LF Sewn-On Trim";
                                    }
                                    if ($metaArray['tassels'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['tassels-count'] . " Tassels";
                                    }
                                }
                            } elseif ($metaArray['lineitemtype'] == 'simpleproduct') {
                                switch ($quoteItem['product_type']) {
                                    case "cubicle_curtains":
                                        $itemDescription .= "Price List CC";
                                        if ($thisFabric['railroaded'] == '1') {
                                            $itemDescription .= "<br>Fabric Railroaded";
                                        } else {
                                            $itemDescription .= "<br>Fabric Vertically Seamed";
                                        }
                                        if ($metaArray['mesh'] > 0 && $metaArray['mesh'] != '') {
                                            $itemDescription .= "<br><b>Mesh:</b> " . $metaArray['mesh'] . "&quot; " . $metaArray['mesh-color'] . " (MOM)";
                                        }
                                        if ($metaArray['mesh'] == 'No Mesh' || $metaArray['mesh'] == '0') {
                                            $itemDescription .= "<br>NO MESH";
                                        }
                                        if (floatval($thisFabric['vertical_repeat']) > 0) {
                                            $itemDescription .= "<br>Matched Repeat (" . $thisFabric['vertical_repeat'] . "&quot;)";
                                        }
                                        break;
                                    case "bedspreads":
                                        $itemDescription .= "Price List BS";
                                        $thisBS = "";
                                        try {
                                            $thisBS = $this->Bedspreads->get($quoteItem['product_id'])->toArray();
                                            } catch (RecordNotFoundException $e) { }
    								

                                        if ($thisFabric['railroaded'] == '1') {
                                            $itemDescription .= "<br>Fabric Railroaded";
                                        } else {
                                            $itemDescription .= "<br>Fabric Vertically Seamed";
                                        }
                                        $itemDescription .= "<br>Style: ";
                                        $styleval = explode(" (", $metaArray['style']);
                                        $itemDescription .= $styleval[0];
                                        if (!empty($thisBS) && $thisBS['quilted'] == '1') {
                                            $itemDescription .= "<br>Quilted, Double Onion, " . $thisFabric['bs_backing_material'] . " Backing";
                                        } else {
                                            $itemDescription .= "<br>Unquilted";
                                        }
                                        $itemDescription .= "<br>Mattress: ";
                                        if (!isset($metaArray['custom-top-width-mattress-w'])) {
                                            $itemDescription .= "36&quot;";
                                        } else {
                                            $itemDescription .= $metaArray['custom-top-width-mattress-w'] . "&quot;";
                                        }

                                        if (floatval($thisFabric['vertical_repeat']) > 0) {
                                            $itemDescription .= "<br>Matched Repeat (" . $thisFabric['vertical_repeat'] . "&quot;)";
                                        }
                                        break;
                                    case "services":
                                        $itemDescription .= $quoteItem['title'];
                                        break;
                                    case "window_treatments":
                                        if ($metaArray['wttype'] == 'Pinch Pleated Drapery') {
                                            $itemDescription .= "<b>" . ucfirst($metaArray['unit-of-measure']) . "</b><br>";
                                        }
                                        $itemDescription .= 'Price List ' . $metaArray['wttype'];
                                        if (preg_match("#Cornice#i", $metaArray['wttype']) || preg_match("#Valance#i", $metaArray['wttype'])) {
                                            $itemDescription .= "<br>Fabric Vertically Seamed";
                                        }
                                        if (preg_match("#Valance#i", $metaArray['wttype'])) {
                                            $itemDescription .= "<br>" . $metaArray['pleats'] . " Pleats";
                                        }
                                        if (isset($metaArray['linings_id']) && floatval($metaArray['linings_id']) > 0) {
                                            $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                            $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];
                                        }
                                        if (preg_match("#Cornice#i", $metaArray['wttype'])) {
                                            $welts = '';
                                            if ($metaArray['welt-top'] == '1' && $metaArray['welt-bottom'] == '1') {
                                                $welts = "Top + Bottom";
                                            } else {
                                                if ($metaArray['welt-top'] == '1') {
                                                    $welts = "Top Only";
                                                } elseif ($metaArray['welt-bottom'] == '1') {
                                                    $welts = "Bottom Only";
                                                }
                                            }
                                            if ($welts != '') {
                                                $itemDescription .= "<br><b>Welts:</b> " . $welts;
                                            } else {
                                                $itemDescription .= "<br><b>Welts:</b> None";
                                            }
                                        }

                                        break;
                                    case "track_systems":
                                        $itemDescription .= "<b>" . $quoteItem['title'] . "</b>";
                                        if (isset($metaArray['_component_numlines']) && intval($metaArray['_component_numlines']) > 0) {
                                            $itemDescription .= "<br><button style=\"padding:4px; border:1px solid #000; background:#CCC; color:#000; font-size:11px;\" onclick=\"loadTrackBreakdown('" . $quoteItem['id'] . "');\" type=\"button\">List Components</button>";
                                        }
                                        break;
                                }
                            } elseif ($metaArray['lineitemtype'] == 'custom' || $metaArray['lineitemtype'] == 'newcatchall') {
                                $itemDescription .= "<b>" . $quoteItem['title'] . "</b>";
                                $itemDescription .= "<br>" . $quoteItem['description'];
                                $itemDescription .= "<br>" . nl2br($metaArray['specs']);
                            }

                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////


                            $ttwizard = new \PHPExcel_Helper_HTML;
                            $lineItemValue = $ttwizard->toRichTextObject($itemDescription);


                            $fabricValue = '';
                            $fabricFR = '';
                            if (isset($thisFabric['flammability']) && strlen(trim($thisFabric['flammability'])) > 0) {
                                $fabricFR = '<br><b>FR: ' . $thisFabric['flammability'] . '</b>';
                            }

                            if ($quoteItem['product_type'] == 'track_systems') {
                                $fabricValue .= '---';
                            } elseif ($quoteItem['product_type'] == 'custom') {
                                if (isset($metaArray['com-fabric']) && $metaArray['com-fabric'] == "1") {
                                    $fabricValue .= "COM ";
                                }
                                if ($fabricAlias = $this->getFabricAlias($metaArray['fabricid'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $fabricValue .= $fabricAlias['fabric_name'] . "<br>" . $metaArray['fabric_name'] . $fabricFR;
                                    } else {
                                        $fabricValue .= $metaArray['fabric_name'] . "<br><em>(" . $fabricAlias['fabric_name'] . ")</em>" . $fabricFR;
                                    }
                                } else {
                                    $fabricValue .= $metaArray['fabric_name'] . $fabricFR;
                                }
                            } else {
                                if (isset($metaArray['com-fabric']) && $metaArray['com-fabric'] == "1") {
                                    $fabricValue .= "COM ";
                                }
                                if ($fabricAlias = $this->getFabricAlias($thisFabric['id'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $fabricValue .= "<b>" . $fabricAlias['fabric_name'] . "</b><br>" . $thisFabric['fabric_name'];
                                    } else {
                                        $fabricValue .= $thisFabric['fabric_name'] . "<br><em>(" . $fabricAlias['fabric_name'] . ")</em>";
                                    }
                                } else {
                                    $fabricValue .= $thisFabric['fabric_name'];
                                }
                                $fabricValue .= $fabricFR;
                            }

                            $fabricwizard = new \PHPExcel_Helper_HTML;
                            $fabricrichText = $fabricwizard->toRichTextObject($fabricValue);


                            $colorValue = '';
                            if ($quoteItem['product_type'] == 'track_systems') {
                                $colorValue .= '---';
                            } elseif ($quoteItem['product_type'] == 'custom') {
                                if ($fabricAlias = $this->getFabricAlias($metaArray['fabricid'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $colorValue .= "<b>" . $fabricAlias['color'] . "</b><br>" . $metaArray['fabric_color'];
                                    } else {
                                        $colorValue .= $metaArray['fabric_color'] . "<br><em>(" . $fabricAlias['color'] . ")</em>";
                                    }
                                } else {
                                    $colorValue .= $metaArray['fabric_color'];
                                }
                            } else {
                                if ($fabricAlias = $this->getFabricAlias($thisFabric['id'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $colorValue .= "<b>" . $fabricAlias['color'] . "</b><Br>" . $thisFabric['color'];
                                    } else {
                                        $colorValue .= $thisFabric['color'] . "<br><em>(" . $fabricAlias['color'] . ")</em>";
                                    }
                                } else {
                                    $colorValue .= $thisFabric['color'];
                                }
                            }

                            $colorwizard = new \PHPExcel_Helper_HTML;
                            $colorrichText = $colorwizard->toRichTextObject($colorValue);

                            $cutwidthValue = '';
                            $finwidthValue = '';

                            if ($quoteItem['product_type'] == 'track_systems') {
                                $cutwidthValue .= '---';
                            } elseif ($quoteItem['product_type'] == "bedspreads") {
                                $cutwidthValue .= number_format(floatval($metaArray['width']), 0, '', '');
                                if (isset($metaArray['width']) && strlen(trim($metaArray['width'])) > 0) {
                                    $finwidthValue .= $metaArray['width'];
                                }
                            } elseif ($quoteItem['product_type'] == "cubicle_curtains") {
                                $cutwidthValue .= number_format(floatval($metaArray['width']), 0, '', '');
                                if (isset($metaArray['expected-finish-width']) && strlen(trim($metaArray['expected-finish-width'])) > 0) {
                                    $finwidthValue .= $metaArray['expected-finish-width'];
                                }
                            } elseif ($quoteItem['product_type'] == 'window_treatments') {
                                if ($metaArray['wttype'] == 'Pinch Pleated Drapery') {
                                    $cutwidthValue .= number_format(floatval($metaArray['rod-width']), 0, '', '') . " (Rod)";
                                    $finwidthValue .= $metaArray['default-return'] . " (Return)";
                                } elseif (preg_match("#Cornice#i", $metaArray['wttype']) || preg_match("#Valance#i", $metaArray['wttype'])) {
                                    $cutwidthValue .= number_format(floatval($metaArray['width']), 0, '', '') . " (Face)";
                                    if (isset($metaArray['return']) && floatval(trim($metaArray['return'])) > 0) {
                                        $finwidthValue .= $metaArray['return'] . " (Return)";
                                    } else {
                                        $finwidthValue .= "No Return";
                                    }
                                }
                            } else {
                                if ($metaArray['calculator-used'] == "box-pleated") {
                                    if (isset($metaArray['face']) && strlen(trim($metaArray['face'])) > 0) {
                                        $cutwidthValue .= $metaArray['face'] . " (Face)";
                                    }
                                    if (isset($metaArray['return']) && floatval(trim($metaArray['return'])) > 0) {
                                        $finwidthValue .= $metaArray['return'] . " (Return)";
                                    } else {
                                        $finwidthValue .= "No Return";
                                    }
                                } elseif ($metaArray['calculator-used'] == "bedspread" || $metaArray['calculator-used'] == "bedspread-manual") {
                                    if (isset($metaArray['width']) && strlen(trim($metaArray['width'])) > 0) {
                                        $finwidthValue .= $metaArray['width'];
                                    }
                                } elseif ($metaArray['calculator-used'] == "cubicle-curtain") {
                                    if (isset($metaArray['width']) && strlen(trim($metaArray['width'])) > 0) {
                                        $cutwidthValue .= $metaArray['width'];
                                    }
                                    if (isset($metaArray['expected-finish-width']) && strlen(trim($metaArray['expected-finish-width'])) > 0) {
                                        $finwidthValue .= $metaArray['expected-finish-width'];
                                    } else {
                                        if (isset($metaArray['fw']) && strlen(trim($metaArray['fw'])) > 0) {
                                            $finwidthValue .= $metaArray['fw'];
                                        }
                                    }
                                } elseif ($metaArray['calculator-used'] == "straight-cornice") {
                                    if (isset($metaArray['face']) && strlen(trim($metaArray['face'])) > 0) {
                                        $cutwidthValue .= $metaArray['face'] . " (Face)";
                                    }
                                    if (isset($metaArray['return']) && floatval(trim($metaArray['return'])) > 0) {
                                        $finwidthValue .= $metaArray['return'] . " (Return)";
                                    } else {
                                        $finwidthValue .= "No Return";
                                    }
                                } elseif ($metaArray['calculator-used'] == 'pinch-pleated') {
                                    if ($metaArray['unit-of-measure'] == 'pair') {
                                        if (isset($metaArray['rod-width']) && strlen(trim($metaArray['rod-width'])) > 0) {
                                            $cutwidthValue .= $metaArray['rod-width'] . " (Rod)";
                                        }
                                    } else {
                                        if (isset($metaArray['fabric-widths-per-panel'])) {
                                            $cutwidthValue .= $metaArray['fabric-widths-per-panel'] . " Widths";
                                        }
                                    }
                                    if (isset($metaArray['fullness']) && strlen(trim($metaArray['fullness'])) > 0) {
                                        $finwidthValue .= $metaArray['fullness'] . "X Fullness";
                                    }
                                    if (isset($metaArray['default-return']) && strlen(trim($metaArray['default-return'])) > 0) {
                                        $finwidthValue .= "<br>" . $metaArray['default-return'] . " Ret";
                                    }
                                    if (isset($metaArray['default-overlap']) && strlen(trim($metaArray['default-overlap'])) > 0) {
                                        $finwidthValue .= "<br>" . $metaArray['default-overlap'] . " Ovrlp";
                                    }
                                }
                            }

                            $cutwidthwizard = new \PHPExcel_Helper_HTML;
                            $cutwidthValue = $cutwidthwizard->toRichTextObject($cutwidthValue);

                            $finwidthwizard = new \PHPExcel_Helper_HTML;
                            $finwidthValue = $finwidthwizard->toRichTextObject($finwidthValue);

                            $lengthValue = '';
                            if ($quoteItem['product_type'] == 'track_systems') {
                                $lengthValue = '---';
                            } else {
                                if ($metaArray['calculator-used'] == "box-pleated") {
                                    $lengthValue .= $metaArray['height'] . " (Height)";
                                } elseif ($metaArray['calculator-used'] == "straight-cornice") {
                                    $lengthValue .= $metaArray['height'] . " (Height)";
                                } else {
                                    $lengthValue .= $metaArray['length'];
                                    if ($quoteItem['product_type'] == 'window_treatments' && (preg_match("#Cornice#i", $metaArray['wttype']) || preg_match("#Valance#i", $metaArray['wttype']))) {
                                        $lengthValue .= " (Height)";
                                    }
                                }
                                if (isset($metaArray['fl-short']) && floatval($metaArray['fl-short']) > 0) {
                                    $lengthValue .= "<br>" . $metaArray['fl-short'] . "(Short Point)";
                                }
                            }
                            $lengthwizard = new \PHPExcel_Helper_HTML;
                            $lengthrichText = $lengthwizard->toRichTextObject($lengthValue);






                            if (isset($metaArray['yds-per-unit'])) {
                                $ydsperunitValue = $metaArray['yds-per-unit'];
                            } else {
                                $ydsperunitValue = '---';
                            }




                            $bestprice = $quoteItem['best_price'];
                            $installadjustmentpercentage = 0;
                            $tieradjustmentpercentage = 0;
                            $tierDiscountOrPremium = 'Disc';
                            $rebateadjustmentpercentage = 0;

                            if ($metaArray['specialpricing'] == '1') {
                                $tieradjusted = number_format(floatval($quoteItem['best_price']), 2, '.', ',');
                                $installadjusted = number_format(floatval($quoteItem['best_price']), 2, '.', ',');
                                $rebateadjusted = number_format(floatval($quoteItem['best_price']), 2, '.', ',');
                                $pmiadjusted = number_format(floatval($quoteItem['pmi_adjusted']), 2, '.', ',');
                                $pmiadjustmentdollars = number_format((floatval(str_replace(',', '', $pmiadjusted)) - floatval(str_replace(',', '', $rebateadjusted))), 2, '.', ',');
                            } else {
                                $tieradjusted = number_format(floatval($quoteItem['tier_adjusted_price']), 2, '.', ',');
                                $installadjusted = number_format(floatval($quoteItem['install_adjusted_price']), 2, '.', ',');
                                $rebateadjusted = number_format(floatval($quoteItem['rebate_adjusted_price']), 2, '.', ',');
                                $pmiadjusted = number_format(floatval($quoteItem['pmi_adjusted']), 2, '.', ',');

                                $tieradjustmentpercentage = round(abs((((1 / floatval(str_replace(',', '', $quoteItem['best_price']))) * floatval(str_replace(',', '', $tieradjusted))) * 100)), 2);
                                $installadjustmentpercentage = round(abs(((1 - ((1 / floatval(str_replace(',', '', $tieradjusted))) * floatval(str_replace(',', '', $installadjusted)))) * 100)), 2);
                                $rebateadjustmentpercentage = round(abs(((1 - ((1 / floatval(str_replace(',', '', $installadjusted))) * floatval(str_replace(',', '', $rebateadjusted)))) * 100)), 2);
                                $pmiadjustmentdollars = number_format((floatval(str_replace(',', '', $pmiadjusted)) - floatval(str_replace(',', '', $rebateadjusted))), 2, '.', ',');
                            }

                            $breakdownValue = '';
                            $basePriceValue = number_format($bestprice, 2, '.', ',');

                            if ($metaArray['specialpricing'] == '1') {
                                $breakdownValue .= "<font color=\"#FF0000\"><b><em>SPECIAL PRICING</em></b></font>";
                            } else {
                                $breakdownValue .= "<font color=\"#0000FF\">" . $tieradjusted . " Tier (";
                                if (floatval(str_replace(',', '', $quoteItem['best_price'])) > floatval(str_replace(',', '', $tieradjusted))) {
                                    $breakdownValue .= '-' . $tieradjustmentpercentage . "% Disc";
                                } elseif (floatval(str_replace(',', '', $quoteItem['best_price'])) < floatval(str_replace(',', '', $tieradjusted))) {
                                    if ($tieradjustmentpercentage > 100) {
                                        $breakdownValue .= '+' . ($tieradjustmentpercentage - 100) . "% Prem";
                                    } else {
                                        $breakdownValue .= '+' . $tieradjustmentpercentage . "% Prem";
                                    }
                                } else {
                                    $breakdownValue .= "0%";
                                }

                                $breakdownValue .= ")<br>" . $installadjusted . " INST (+" . $installadjustmentpercentage . "%)<br>" . $rebateadjusted . " ADD ";
                                $breakdownValue .= "(+" . $rebateadjustmentpercentage . "%)";
                                $breakdownValue .= "<br>" . $pmiadjusted . " PMI (+\$" . $pmiadjustmentdollars . ")</font>";
                            }


                            $breakdownwizard = new \PHPExcel_Helper_HTML;
                            $breakdownrichText = $breakdownwizard->toRichTextObject($breakdownValue);



                            if ($quoteItem['override_active'] == 1) {
                                $adjustedColValue = number_format(floatval($quoteItem['override_price']), 2, '.', '');
                            } else {
                                $adjustedColValue = number_format(floatval($pmiadjusted), 2, '.', '');
                            }







                            $extendedPriceValue = number_format($extendedprice, 2, '.', ',');

                            $dateScheduled = '';
                            $dateShipped = '';
                            $dateInvoiced = '';
                            $dateProduced = '';
                            $trackingNumber = '';


                            $lineNotesValue = '';
                            $lineNotes = $this->QuoteLineItemNotes->find('all', ['conditions' => ['quote_item_id' => $quoteItem['id']], 'order' => ['time' => 'asc']])->toArray();
                            foreach ($lineNotes as $lineNoteRow) {
                                $thisNoteUser = $this->Users->get($lineNoteRow['user_id'])->toArray();
                                if ($lineNoteRow['visible_to_customer'] == 0) {
                                    $lineNotesValue .= '[INTERNAL] ';
                                }
                                $lineNotesValue .= $lineNoteRow['message'] . ' <font color="#0000FF"><em>' . $thisNoteUser['first_name'] . ' ' . substr($thisNoteUser['last_name'], 0, 1) . ' @ ' . date('n/j/y g:iA', $lineNoteRow['time']) . '</em></font><br>';
                            }

                            $linenoteswizard = new \PHPExcel_Helper_HTML;
                            $linenotesrichText = $linenoteswizard->toRichTextObject($lineNotesValue);



                            //start inner loop of $loop
                            //begin with UNBATCHED
                            if ($loop['unbatched'] > 0) {
                                $qtyValue = $loop['unbatched'];
                                $batchValue = 'N/A';

                                $totalLFvalue = '';

                                $totalydsvalue = '';
                                if ($metaArray['lineitemtype'] == 'simpleproduct') {
                                    $totalydsvalue .= round((floatval($metaArray['yds-per-unit']) * floatval($qtyValue)), 2);
                                } elseif ($metaArray['lineitemtype'] == "custom") {
                                    if (floatval($metaArray['total-yds']) > 0) {
                                        $totalydsvalue .= round(((floatval($metaArray['total-yds']) / floatval($quoteItem['qty'])) * intval($qtyValue)), 2);
                                    } else {
                                        $totalydsvalue .= round((floatval($metaArray['yds-per-unit']) * floatval($qtyValue)), 2);
                                    }
                                } else {
                                    $totalydsvalue .= round(((floatval($metaArray['total-yds']) / floatval($quoteItem['qty'])) * intval($qtyValue)), 2);
                                }


                                if ($metaArray['specialpricing'] == '1') {
                                    if ($quoteItem['override_active'] == 1) {
                                        $extendedprice = (floatval($quoteItem['override_price']) * floatval($qtyValue));
                                    } else {
                                        $extendedprice = (floatval($quoteItem['best_price']) * floatval($qtyValue));
                                    }
                                } else {
                                    if ($quoteItem['override_active'] == 1) {
                                        $extendedprice = (floatval($quoteItem['override_price']) * floatval($qtyValue));
                                    } else {
                                        $extendedprice = number_format((floatval($quoteItem['pmi_adjusted']) * $qtyValue), 2, '.', '');
                                    }
                                }



                                if ($quoteItem['product_type'] == 'track_systems') {
                                    if ($quoteItem['unit'] == 'linear feet') {
                                        $totalLFvalue .= $qtyValue;
                                    } else {
                                        $totalLFvalue .= '---';
                                    }
                                } else {
                                    if (isset($metaArray['labor-billable'])) {
                                        $totalLFvalue .= (floatval($metaArray['labor-billable']) * floatval($qtyValue));
                                    } else {
                                        $totalLFvalue .= "---";
                                    }
                                }

                                if ($orderRow['project_manager_id'] == 0 || is_null($orderRow['project_manager_id'])) {
                                    $managerName = 'N/A';
                                } else {
                                    $pmLookup = $this->Users->get($orderRow['project_manager_id'])->toArray();
                                    $managerName = $pmLookup['first_name'] . ' ' . $pmLookup['last_name'];
                                }

                                $totallfrichText = $totalLFvalue;

                                //recalc and override the TOTAL LF, TOTAL YARDS, EXTENDED PRICE variables for [this qty]


                                $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $orderRow['order_number']);
                                $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $quoteNumberValue);

                                $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $orderRow['stage']);

                                $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $managerName);

                                $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $customerValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $customerPOValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $facilityValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $shipDateValue);
                                $objPHPExcel->getActiveSheet()->getStyle('H' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $dateScheduled); //moved from AB

                                $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $thisbookingdate);
                                $objPHPExcel->getActiveSheet()->getStyle('J' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $batchValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $lineNumberValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowCount, $locationValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowCount, $qtyValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowCount, $unitValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowCount, $lineItemValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowCount, $fabricrichText);
                                $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowCount, $colorrichText);
                                $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowCount, $cutwidthValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowCount, $finwidthValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowCount, $lengthrichText);
                                $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowCount, $totallfrichText);
                                $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowCount, $ydsperunitValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('X' . $rowCount, $totalydsvalue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('Y' . $rowCount, $basePriceValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('Z' . $rowCount, $breakdownrichText);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AA' . $rowCount, $adjustedColValue);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AB' . $rowCount, $extendedprice);


                                $objPHPExcel->getActiveSheet()->SetCellValue('AC' . $rowCount, $dateProduced);
                                $objPHPExcel->getActiveSheet()->getStyle('AC' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                $objPHPExcel->getActiveSheet()->SetCellValue('AD' . $rowCount, $dateShipped);
                                $objPHPExcel->getActiveSheet()->getStyle('AD' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                $objPHPExcel->getActiveSheet()->SetCellValue('AE' . $rowCount, $trackingNumber);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AF' . $rowCount, $dateInvoiced);
                                $objPHPExcel->getActiveSheet()->getStyle('AF' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                $objPHPExcel->getActiveSheet()->SetCellValue('AG' . $rowCount, $linenotesrichText);




                                $bsQuilt = '';
                                $bsMatSize = '';
                                $bsDrop = '';
                                $bsWidthsEa = '';
                                $bsTopWidthsEa = '';
                                $bsTopWidthsCL = '';
                                $bsTopCutSizeW = '';
                                $bsTopCutSizeL = '';
                                $bsDropCutSizeW = '';
                                $bsDropCutSizeL = '';
                                $ccMeshSize = '';
                                $ccMeshColor = '';
                                $ccWidthsEa = '';
                                $ccCL = '';
                                $ccActualLF = '';


                                if ($quoteItem['product_type'] == 'bedspreads' || ($quoteItem['product_type'] == 'calculator' && ($metaArray['calculator-used'] == 'bedspread' || $metaArray['calculator-used'] == 'bedspread-manual'))) {

                                    if ($metaArray['quilted'] == '1') {
                                        $bsQuilt = $metaArray['quilting-pattern'] . ' 6oz';
                                        if (isset($metaArray['fabricid']) && strlen($metaArray['fabricid']) > 0) {
                                            $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                            $bsQuilt .= ' ' . $thisFabric['bs_backing_material'];
                                        }
                                    } else {
                                        $bsQuilt = 'None';
                                    }

                                    $bsMatSize = $metaArray['custom-top-width-mattress-w'];
                                    $bsDrop = ((floatval($metaArray['width']) - floatval($metaArray['custom-top-width-mattress-w'])) / 2);
                                    $bsWidthsEa = floatval($metaArray['layout']);
                                    $bsTopWidthsEa = intval($qtyValue);
                                    $bsTopWidthsCL = $metaArray['top-widths'];

                                    $bsTopCutSizeL = $metaArray['top-widths'];

                                    if ($metaArray['railroaded'] == '1') {
                                        $bsTopCutSizeW = (floatval($metaArray['length']) + (floatval($metaArray['extra-inches-seam-hems']) * 2));

                                        $bsDropCutSizeW = 'N/A';
                                        $bsDropCutSizeL = 'N/A';
                                    } else {
                                        $bsTopCutSizeW = $metaArray['top-cut'];

                                        $bsDropCutSizeW = $metaArray['drop-cut'];
                                        $bsDropCutSizeL = $metaArray['drop-widths'];
                                    }
                                }


                                if ($quoteItem['product_type'] == 'cubicle_curtains' || ($quoteItem['product_type'] == 'calculator' && $metaArray['calculator-used'] == 'cubicle-curtain')) {
                                    $ccMeshSize = (floatval($metaArray['mesh']) + floatval($allsettings['mesh_heading']));
                                    $ccMeshColor = $metaArray['mesh-color'];
                                    if ($quoteItem['product_type'] == 'cubicle_curtains') {
                                        $eachstart = (floatval($metaArray['width']) / 72);
                                        $ccWidthsEa = substr($eachstart, 0, ((strpos($eachstart, '.') + 1) + 2));
                                    } else {
                                        $ccWidthsEa = substr($metaArray['widths-each'], 0, ((strpos($metaArray['widths-each'], '.') + 1) + 2));
                                    }


                                    if ($quoteItem['product_type'] == 'cubicle_curtains') {
                                        $meta_length = floatval($metaArray['length']);
                                        $meta_mesh = floatval($metaArray['mesh']);
                                        $inches_per_hem = floatval($allsettings['inches_per_hem']);
                                        $inches_per_seam = floatval($allsettings['inches_per_seam']);
                                        $inches_per_head = floatval($allsettings['inches_for_header']);

                                        if ($metaArray['mesh-type'] == 'None') {
                                            $ccCL = ($meta_length + $inches_per_hem + $inches_per_head);
                                        } else {
                                            $vert_rpt = floatval($metaArray['vertical-repeat']);
                                            $mesh_heading = floatval($allsettings['mesh_heading']);
                                            $mesh_type_calc = (($meta_length - $meta_mesh - $mesh_heading) + $inches_per_hem + $inches_per_seam);
                                            if ($vert_rpt == 0) {
                                                $ccCL = $mesh_type_calc;
                                            } else {
                                                $ccCL = (ceil($mesh_type_calc / $vert_rpt) * $vert_rpt);
                                            }
                                        }
                                    } else {
                                        $ccCL = $metaArray['cl'];
                                    }

                                    $ccActualLF = (floatval($metaArray['labor-billable']) * intval($qtyValue));
                                }


                                $objPHPExcel->getActiveSheet()->SetCellValue('AH' . $rowCount, $bsQuilt);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AI' . $rowCount, $bsMatSize);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AJ' . $rowCount, $bsDrop);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AK' . $rowCount, $bsWidthsEa);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AL' . $rowCount, $bsTopWidthsEa);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AM' . $rowCount, $bsTopWidthsCL);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AN' . $rowCount, $bsTopCutSizeW);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AO' . $rowCount, $bsTopCutSizeL);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AP' . $rowCount, $bsDropCutSizeW);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AQ' . $rowCount, $bsDropCutSizeL);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AR' . $rowCount, $ccMeshSize);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AS' . $rowCount, $ccMeshColor);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AT' . $rowCount, $ccWidthsEa);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AU' . $rowCount, $ccCL);
                                $objPHPExcel->getActiveSheet()->SetCellValue('AV' . $rowCount, $ccActualLF);


                                if ($rowCount % 2 == 0) {
                                    $thisrowcolor = 'F8F8F8';
                                } else {
                                    $thisrowcolor = 'FFFFFF';
                                }

                                $objPHPExcel->getActiveSheet()->getStyle('A' . $rowCount . ':AV' . $rowCount)->applyFromArray(
                                    array(
                                        'fill' => array(
                                            'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                                            'color' => array('rgb' => $thisrowcolor)
                                        )
                                    )
                                );

                                $brlines = explode("<br", $itemDescription);
                                if (count($brlines) < 5) {
                                    $rowheight = 90;
                                } elseif (count($brlines) >= 5 && count($brlines) < 8) {
                                    $rowheight = 120;
                                } else {
                                    $rowheight = 145;
                                }

                                $objPHPExcel->getActiveSheet()->getRowDimension($rowCount)->setRowHeight($rowheight);

                                $rowCount++;
                            }


                            //then loop through BATCHED
                            foreach ($loop['batches'] as $num => $batchloopitem) {
                                $totalLFvalue = '';

                                if ((isset($batchloopitem['invoicedTS']) && $batchloopitem['invoicedTS'] > 1000) && (isset($batchloopitem['shippedTS']) && $batchloopitem['shippedTS'] > 1000)) {
                                    //ignore this row, it's already shipped and invoiced
                                } else {
                                    $qtyValue = $batchloopitem['qty'];
                                    $batchValue = $batchloopitem['batchid'];

                                    if ($metaArray['specialpricing'] == '1') {
                                        if ($quoteItem['override_active'] == 1) {
                                            $extendedprice = (floatval($quoteItem['override_price']) * floatval($qtyValue));
                                        } else {
                                            $extendedprice = (floatval($quoteItem['best_price']) * floatval($qtyValue));
                                        }
                                    } else {
                                        if ($quoteItem['override_active'] == 1) {
                                            $extendedprice = (floatval($quoteItem['override_price']) * floatval($qtyValue));
                                        } else {
                                            $extendedprice = number_format((floatval($quoteItem['pmi_adjusted']) * $qtyValue), 2, '.', '');
                                        }
                                    }

                                    $totalydsvalue = '';
                                    if ($metaArray['lineitemtype'] == 'simpleproduct') {
                                        $totalydsvalue .= round((floatval($metaArray['yds-per-unit']) * floatval($qtyValue)), 2);
                                    } elseif ($metaArray['lineitemtype'] == "custom") {
                                        if (floatval($metaArray['total-yds']) > 0) {
                                            $totalydsvalue .= round(((floatval($metaArray['total-yds']) / floatval($quoteItem['qty'])) * intval($qtyValue)), 2);
                                        } else {
                                            $totalydsvalue .= round((floatval($metaArray['yds-per-unit']) * floatval($qtyValue)), 2);
                                        }
                                    } else {
                                        $totalydsvalue .= round(((floatval($metaArray['total-yds']) / floatval($quoteItem['qty'])) * intval($qtyValue)), 2);
                                    }


                                    if ($quoteItem['product_type'] == 'track_systems') {
                                        if ($quoteItem['unit'] == 'linear feet') {
                                            $totalLFvalue .= $qtyValue;
                                        } else {
                                            $totalLFvalue .= '---';
                                        }
                                    } else {
                                        if (isset($metaArray['labor-billable'])) {
                                            $totalLFvalue .= (floatval($metaArray['labor-billable']) * floatval($qtyValue));
                                        } else {
                                            $totalLFvalue .= "---";
                                        }
                                    }

                                    $totallfrichText = $totalLFvalue;

                                    $dateScheduled = '';
                                    $dateShipped = '';
                                    $trackingNumber = '';



                                    $shipStatusesThisBatch = $this->OrderItemStatus->find('all', ['conditions' => ['sherry_batch_id' => $batchValue, 'status' => 'Shipped', 'shipment_id !=' => NULL, 'shipment_id !=' => 0]])->toArray();
                                    foreach ($shipStatusesThisBatch as $shipStatus) {
                                        $shipment = $this->Shipments->get($shipStatus['shipment_id'])->toArray();
                                        $trackingNumber = $shipment['tracking_number'];
                                    }

                                    //look up whether this line has been Shipped, if so, populate the variable
                                    $thisLineBatchesShipped = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Shipped', 'sherry_batch_id' => $batchValue]])->toArray();
                                    foreach ($thisLineBatchesShipped as $shippedBatch) {
                                        //$dateShipped = date('n/j/Y',$shippedBatch['time']);
                                        $shipDateTimeObj = new \DateTime();
                                        $shipDateTimeObj->setTimestamp($shippedBatch['time']);
                                        $dateShipped = \PHPExcel_Shared_Date::PHPToExcel($shipDateTimeObj);
                                    }


                                    $dateScheduled = '';
                                    $thisLineBatchesScheduled = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Scheduled', 'sherry_batch_id' => $batchValue]])->toArray();
                                    foreach ($thisLineBatchesScheduled as $scheduledBatch) {
                                        //$dateScheduled = date('n/j/Y',$scheduledBatch['time']);
                                        $schedDateTimeObj = new \DateTime();
                                        $schedDateTimeObj->setTimestamp($scheduledBatch['time']);

                                        $dateScheduled = \PHPExcel_Shared_Date::PHPToExcel($schedDateTimeObj);
                                    }


                                    $dateProduced = '';
                                    $thisLineBatchesCompleted = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Completed', 'sherry_batch_id' => $batchValue]])->toArray();
                                    foreach ($thisLineBatchesCompleted as $producedBatch) {
                                        //$dateProduced = date('n/j/Y',$producedBatch['time']);
                                        $prodDateTimeObj = new \DateTime();
                                        $prodDateTimeObj->setTimestamp($producedBatch['time']);

                                        $dateProduced = \PHPExcel_Shared_Date::PHPToExcel($prodDateTimeObj);
                                    }

                                    $dateInvoiced = '';

                                    //look up whether this line has been Invoiced, if so, populate the variable
                                    $thisLineBatchesInvoiced = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Invoiced', 'sherry_batch_id' => $batchValue]])->toArray();
                                    foreach ($thisLineBatchesInvoiced as $invoicedBatch) {
                                        //$dateInvoiced = date('n/j/Y',$invoicedBatch['time']);
                                        $invDateTimeObj = new \DateTime();
                                        $invDateTimeObj->setTimestamp($invoicedBatch['time']);

                                        $dateInvoiced = \PHPExcel_Shared_Date::PHPToExcel($invDateTimeObj);
                                    }



                                    //recalc and override the TOTAL LF, TOTAL YARDS, EXTENDED PRICE variables for [this qty]
                                    if ($orderRow['project_manager_id'] == 0 || is_null($orderRow['project_manager_id'])) {
                                        $managerName = 'N/A';
                                    } else {
                                        $pmLookup = $this->Users->get($orderRow['project_manager_id'])->toArray();
                                        $managerName = $pmLookup['first_name'] . ' ' . $pmLookup['last_name'];
                                    }

                                    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $orderRow['order_number']);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $quoteNumberValue);

                                    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $orderRow['stage']);

                                    $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $managerName);

                                    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $customerValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $customerPOValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $facilityValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $shipDateValue);
                                    $objPHPExcel->getActiveSheet()->getStyle('H' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $dateScheduled);
                                    $objPHPExcel->getActiveSheet()->getStyle('I' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $thisbookingdate);
                                    $objPHPExcel->getActiveSheet()->getStyle('J' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $batchValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $lineNumberValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowCount, $locationValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowCount, $qtyValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowCount, $unitValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowCount, $lineItemValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowCount, $fabricrichText);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowCount, $colorrichText);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowCount, $cutwidthValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowCount, $finwidthValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowCount, $lengthrichText);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowCount, $totallfrichText);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowCount, $ydsperunitValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('X' . $rowCount, $totalydsvalue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('Y' . $rowCount, $basePriceValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('Z' . $rowCount, $breakdownrichText);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AA' . $rowCount, $adjustedColValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AB' . $rowCount, $extendedprice);



                                    $objPHPExcel->getActiveSheet()->SetCellValue('AC' . $rowCount, $dateProduced);
                                    $objPHPExcel->getActiveSheet()->getStyle('AC' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('AD' . $rowCount, $dateShipped);
                                    $objPHPExcel->getActiveSheet()->getStyle('AD' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('AE' . $rowCount, $trackingNumber);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AF' . $rowCount, $dateInvoiced);
                                    $objPHPExcel->getActiveSheet()->getStyle('AF' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('AG' . $rowCount, $linenotesrichText);





                                    $bsQuilt = '';
                                    $bsMatSize = '';
                                    $bsDrop = '';
                                    $bsWidthsEa = '';
                                    $bsTopWidthsEa = '';
                                    $bsTopWidthsCL = '';
                                    $bsTopCutSizeW = '';
                                    $bsTopCutSizeL = '';
                                    $bsDropCutSizeW = '';
                                    $bsDropCutSizeL = '';
                                    $ccMeshSize = '';
                                    $ccMeshColor = '';
                                    $ccWidthsEa = '';
                                    $ccCL = '';
                                    $ccActualLF = '';


                                    if ($quoteItem['product_type'] == 'bedspreads' || ($quoteItem['product_type'] == 'calculator' && ($metaArray['calculator-used'] == 'bedspread' || $metaArray['calculator-used'] == 'bedspread-manual'))) {

                                        if ($metaArray['quilted'] == '1') {
                                            $bsQuilt = $metaArray['quilting-pattern'] . ' 6oz';
                                            if (isset($metaArray['fabricid']) && strlen($metaArray['fabricid']) > 0) {
                                                $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                                $bsQuilt .= ' ' . $thisFabric['bs_backing_material'];
                                            }
                                        } else {
                                            $bsQuilt = 'None';
                                        }

                                        $bsMatSize = $metaArray['custom-top-width-mattress-w'];
                                        $bsDrop = ((floatval($metaArray['width']) - floatval($metaArray['custom-top-width-mattress-w'])) / 2);
                                        $bsWidthsEa = floatval($metaArray['layout']);
                                        $bsTopWidthsEa = intval($qtyValue);
                                        $bsTopWidthsCL = $metaArray['top-widths'];

                                        $bsTopCutSizeL = $metaArray['top-widths'];

                                        if ($metaArray['railroaded'] == '1') {
                                            $bsTopCutSizeW = (floatval($metaArray['length']) + (floatval($metaArray['extra-inches-seam-hems']) * 2));

                                            $bsDropCutSizeW = 'N/A';
                                            $bsDropCutSizeL = 'N/A';
                                        } else {
                                            $bsTopCutSizeW = $metaArray['top-cut'];

                                            $bsDropCutSizeW = $metaArray['drop-cut'];
                                            $bsDropCutSizeL = $metaArray['drop-widths'];
                                        }
                                    }


                                    if ($quoteItem['product_type'] == 'cubicle_curtains' || ($quoteItem['product_type'] == 'calculator' && $metaArray['calculator-used'] == 'cubicle-curtain')) {
                                        $ccMeshSize = (floatval($metaArray['mesh']) + floatval($allsettings['mesh_heading']));
                                        $ccMeshColor = $metaArray['mesh-color'];

                                        if ($quoteItem['product_type'] == 'cubicle_curtains') {
                                            $eachstart = (floatval($metaArray['width']) / 72);
                                            $ccWidthsEa = substr($eachstart, 0, ((strpos($eachstart, '.') + 1) + 2));
                                        } else {
                                            $ccWidthsEa = substr($metaArray['widths-each'], 0, ((strpos($metaArray['widths-each'], '.') + 1) + 2));
                                        }

                                        if ($quoteItem['product_type'] == 'cubicle_curtains') {
                                            $meta_length = floatval($metaArray['length']);
                                            $meta_mesh = floatval($metaArray['mesh']);
                                            $inches_per_hem = floatval($allsettings['inches_per_hem']);
                                            $inches_per_seam = floatval($allsettings['inches_per_seam']);
                                            $inches_per_head = floatval($allsettings['inches_for_header']);

                                            if ($metaArray['mesh-type'] == 'None') {
                                                $ccCL = ($meta_length + $inches_per_hem + $inches_per_head);
                                            } else {
                                                $vert_rpt = floatval($metaArray['vertical-repeat']);
                                                $mesh_heading = floatval($allsettings['mesh_heading']);
                                                $mesh_type_calc = (($meta_length - $meta_mesh - $mesh_heading) + $inches_per_hem + $inches_per_seam);
                                                if ($vert_rpt == 0) {
                                                    $ccCL = $mesh_type_calc;
                                                } else {
                                                    $ccCL = (ceil($mesh_type_calc / $vert_rpt) * $vert_rpt);
                                                }
                                            }
                                        } else {
                                            $ccCL = $metaArray['cl'];
                                        }


                                        $ccActualLF = (floatval($metaArray['labor-billable']) * intval($qtyValue));
                                    }


                                    $objPHPExcel->getActiveSheet()->SetCellValue('AH' . $rowCount, $bsQuilt);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AI' . $rowCount, $bsMatSize);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AJ' . $rowCount, $bsDrop);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AK' . $rowCount, $bsWidthsEa);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AL' . $rowCount, $bsTopWidthsEa);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AM' . $rowCount, $bsTopWidthsCL);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AN' . $rowCount, $bsTopCutSizeW);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AO' . $rowCount, $bsTopCutSizeL);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AP' . $rowCount, $bsDropCutSizeW);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AQ' . $rowCount, $bsDropCutSizeL);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AR' . $rowCount, $ccMeshSize);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AS' . $rowCount, $ccMeshColor);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AT' . $rowCount, $ccWidthsEa);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AU' . $rowCount, $ccCL);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AV' . $rowCount, $ccActualLF);




                                    if ($rowCount % 2 == 0) {
                                        $thisrowcolor = 'F8F8F8';
                                    } else {
                                        $thisrowcolor = 'FFFFFF';
                                    }

                                    $objPHPExcel->getActiveSheet()->getStyle('A' . $rowCount . ':AV' . $rowCount)->applyFromArray(
                                        array(
                                            'fill' => array(
                                                'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                                                'color' => array('rgb' => $thisrowcolor)
                                            )
                                        )
                                    );

                                    $brlines = explode("<br", $itemDescription);
                                    if (count($brlines) < 5) {
                                        $rowheight = 90;
                                    } elseif (count($brlines) >= 5 && count($brlines) < 8) {
                                        $rowheight = 120;
                                    } else {
                                        $rowheight = 145;
                                    }

                                    $objPHPExcel->getActiveSheet()->getRowDimension($rowCount)->setRowHeight($rowheight);

                                    $rowCount++;
                                }
                            }
                        }
                    }
                }
            }

            $objPHPExcel->getActiveSheet()->getStyle('A1:A' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('B1:B' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('C1:C' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('D1:D' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('E1:E' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('F1:F' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('G1:G' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('H1:H' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('I1:I' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('J1:J' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('K1:K' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('L1:L' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('M1:M' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('N1:N' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('O1:O' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('P1:P' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('Q1:Q' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('R1:R' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('S1:S' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('T1:T' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('U1:U' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('V1:V' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('W1:W' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('X1:X' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('Y1:Y' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('Z1:Z' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AA1:AA' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AB1:AB' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AC1:AC' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AD1:AD' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AE1:AE' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AF1:AF' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AG1:AG' . $rowCount)->getAlignment()->setHorizontal('left');

            $objPHPExcel->getActiveSheet()->getStyle('AH1:AH' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AI1:AI' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AJ1:AJ' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AK1:AK' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AL1:AL' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AM1:AM' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AN1:AN' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AO1:AO' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AP1:AP' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AQ1:AQ' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AR1:AR' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AS1:AS' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AT1:AT' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AU1:AU' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AV1:AV' . $rowCount)->getAlignment()->setHorizontal('center');


            $objPHPExcel->getActiveSheet()->getStyle('A1:AV' . $rowCount)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);

            $objPHPExcel->getActiveSheet()->getStyle('A1:AV' . $rowCount)->getAlignment()->setWrapText(true);



            $objPHPExcel->getActiveSheet()->getStyle("A1:AV" . $rowCount)->applyFromArray(
                array(
                    'borders' => array(
                        'allborders' => array(
                            'style' => \PHPExcel_Style_Border::BORDER_THIN,
                            'color' => array('rgb' => '111111')
                        )
                    )
                )
            );

            $objPHPExcel->getActiveSheet()->freezePane('A2');



            // Redirect output to a client’s web browser (Excel5)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="Production Details Backlog Report.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');

            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0

            $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
        } else {
            //display the form
            $allusers = $this->Users->find('all', ['order' => ['last_name' => 'asc', 'first_name' => 'asc']])->toArray();
            $this->set('allusers', $allusers);

            $allcompanies = $this->Customers->find('all', ['order' => ['company_name' => 'asc']])->toArray();
            $this->set('allcompanies', $allcompanies);

            $allfabrics = $this->Fabrics->find('all', ['order' => ['fabric_name' => 'asc', 'color' => 'asc']])->toArray();
            $this->set('allfabrics', $allfabrics);
        }
    }

	public function producedorders(){


        if (isset($this->request->data['report_date_start']) && isset($this->request->data['report_date_end'])) {
            $this->autoRender = false;

            $startTS = strtotime($this->request->data['report_date_start'] . ' 00:00:00');
            $endTS = strtotime($this->request->data['report_date_end'] . ' 23:59:59');





            $days = ceil(((($endTS + 1) - $startTS) / 86400));

            $dateList = array();
            for ($i = 1; $i <= $days; $i++) {
                $dateList[] = date('Y-m-d', ($startTS + (($i - 1) * 86400) + 21600));
            }


            //separate query needed for 'failed to produce' table
            $lookupFailedBatches = $this->SherryCache->find('all', ['conditions' => ['date IN' => $dateList]])->toArray();
            $failedBatches = array();
            foreach ($lookupFailedBatches as $batch) {
                if ($batch['batch_completed_date'] == 0 || $batch['batch_completed_date'] > strtotime($batch['date'] . ' 17:00:00')) {
                    $failedBatches[] = $batch;
                }
            }

            $this->set('failedBatches', $failedBatches);


            $conditions = [
                'batch_completed_date >=' => $startTS,
                'batch_completed_date <' => $endTS //,
                //'OR' => ['date IN' => $dateList]
            ];

            $batches = $this->SherryCache->find('all', ['conditions' => $conditions])->toArray();
            $this->set('batches', $batches);


            $shipments = array();
            foreach ($batches as $batch) {
                $shipStatusesThisBatch = $this->OrderItemStatus->find('all', ['conditions' => ['sherry_batch_id' => $batch['batch_id'], 'status' => 'Shipped', 'shipment_id !=' => NULL, 'shipment_id !=' => 0]])->toArray();
                foreach ($shipStatusesThisBatch as $shipStatus) {
                    $shipment = $this->Shipments->get($shipStatus['shipment_id'])->toArray();
                    $shipments[$batch['batch_id']] = array('tracking' => $shipment['tracking_number'], 'delivery_address' => $shipment['tracking_number']);
                }
            }
            $this->set('shipments', $shipments);

            $this->set('inputs', $this->request->data);
            $this->render('viewproducedorders');
        }
    }


	public function producedordersdownload($start,$end){
        $this->autoRender = false;


        $startTS = strtotime($start . ' 00:00:00');
        $endTS = strtotime($end . ' 23:59:59');

        $days = ceil(((($endTS + 1) - $startTS) / 86400));

        $dateList = array();
        for ($i = 1; $i <= $days; $i++) {
            $dateList[] = date('Y-m-d', ($startTS + (($i - 1) * 86400) + 21600));
        }

        $conditions = [
            'batch_completed_date >=' => $startTS,
            'batch_completed_date <' => $endTS //,
            //'OR' => ['date IN' => $dateList]
        ];

        $batches = $this->SherryCache->find('all', ['conditions' => $conditions])->toArray();


        //separate query needed for 'failed to produce' table
        $lookupFailedBatches = $this->SherryCache->find('all', ['conditions' => ['date IN' => $dateList]])->toArray();
        $failedBatches = array();
        foreach ($lookupFailedBatches as $batch) {
            if ($batch['batch_completed_date'] == 0 || $batch['batch_completed_date'] > strtotime($batch['date'] . ' 17:00:00')) {
                $failedBatches[] = $batch;
            }
        }

        $this->set('failedBatches', $failedBatches);


        require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
        require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");

        $objPHPExcel = new \PHPExcel();

        $objPHPExcel->createSheet(0);
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->getActiveSheet()->setTitle('PRODUCED');

        $rowNumber = 1;

        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, 'SCHEDULED');
        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, 'PRODUCED');
        $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, 'WO#');
        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, 'BATCH#');
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, 'Dollars');
        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, 'CC ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, 'CC LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, 'TRK LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, 'BS ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, 'DRAPE ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, 'DRAPE WIDTHS');
        //$objPHPExcel->getActiveSheet()->SetCellValue('L'.$rowNumber, 'TT ea');
        //$objPHPExcel->getActiveSheet()->SetCellValue('M'.$rowNumber, 'TT LF');

        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, 'VAL ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, 'VAL LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, 'CORN ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, 'CORN LF');

        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, 'WT HW');
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, 'B&S');

        $objPHPExcel->getActiveSheet()->getStyle('A1:Q1')->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(19);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(12);


        $objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('E1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('G1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('I1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('J1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('K1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('L1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('M1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('N1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('O1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('P1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('Q1')->getAlignment()->setHorizontal('center');



        $producedTotals = array(
            'dollars' => 0,
            'ccqty' => 0,
            'cclf' => 0,
            'tracklf' => 0,
            'bs' => 0,
            'drapeqty' => 0,
            'drapewidths' => 0,
            //'ttqty' => 0,
            //'ttlf' => 0,	
            'valqty' => 0,
            'vallf' => 0,
            'cornqty' => 0,
            'cornlf' => 0,
            'wthw' => 0,
            'blinds' => 0
        );

        $data = '';

        foreach ($batches as $batch) {
            if ($batch['batch_completed_date'] > $startTS && $batch['batch_completed_date'] <= $endTS) {

                $rowNumber++;

                $data .= print_r($batch, 1);

                $producedTotals['dollars'] = ($producedTotals['dollars'] + floatval($batch['dollars']));
                $producedTotals['ccqty'] = ($producedTotals['ccqty'] + floatval($batch['cc']));
                $producedTotals['cclf'] = ($producedTotals['cclf'] + floatval($batch['cclf']));
                $producedTotals['tracklf'] = ($producedTotals['tracklf'] + floatval($batch['trklf']));
                $producedTotals['bs'] = ($producedTotals['bs'] + floatval($batch['bs']));
                $producedTotals['drapeqty'] = ($producedTotals['drapeqty'] + floatval($batch['drape']));
                $producedTotals['drapewidths'] = ($producedTotals['drapewidths'] + floatval($batch['drape_widths']));
                //$producedTotals['ttqty'] = ($producedTotals['ttqty'] + floatval($batch['wt']));
                //$producedTotals['ttlf'] = ($producedTotals['ttlf'] + floatval($batch['wtlf']));
                $producedTotals['valqty'] = ($producedTotals['valqty'] + floatval($batch['val']));
                $producedTotals['vallf'] = ($producedTotals['vallf'] + floatval($batch['vallf']));
                $producedTotals['cornqty'] = ($producedTotals['cornqty'] + floatval($batch['corn']));
                $producedTotals['cornlf'] = ($producedTotals['cornlf'] + floatval($batch['cornlf']));

                $producedTotals['wthw'] = ($producedTotals['wthw'] + floatval($batch['wthw']));
                $producedTotals['blinds'] = ($producedTotals['blinds'] + floatval($batch['blinds']));


                if ($batch['cc'] > 0) {
                    $ccea = $batch['cc'];
                } else {
                    $ccea = "";
                }

                if ($batch['cclf'] > 0) {
                    $cclf = $batch['cclf'];
                } else {
                    $cclf = "";
                }

                if ($batch['trklf'] > 0) {
                    $trklf = $batch['trklf'] . " LF";
                } else {
                    $trklf = "";
                }

                if ($batch['bs'] > 0) {
                    $bsea = $batch['bs'];
                } else {
                    $bsea = "";
                }

                if ($batch['drape'] > 0) {
                    $drapeea = $batch['drape'];
                } else {
                    $drapeea = "";
                }

                if ($batch['drape_widths'] > 0) {
                    $drapewidths = $batch['drape_widths'];
                } else {
                    $drapewidths = "";
                }

                /*
                if($batch['wt'] > 0){
        			$ttea=$batch['wt'];
        		}else{
        			$ttea="";
        		}
        		
        		if($batch['wtlf'] > 0){
        			$ttlf=$batch['wtlf'];
        		}else{
        			$ttlf="";
        		}
        		*/

                if ($batch['val'] > 0) {
                    $valea = $batch['val'];
                } else {
                    $valea = "";
                }

                if ($batch['vallf'] > 0) {
                    $vallf = $batch['vallf'];
                } else {
                    $vallf = "";
                }

                if ($batch['corn'] > 0) {
                    $cornea = $batch['corn'];
                } else {
                    $cornea = "";
                }

                if ($batch['cornlf'] > 0) {
                    $cornlf = $batch['cornlf'];
                } else {
                    $cornlf = "";
                }

                if ($batch['wthw'] > 0) {
                    $wthw = $batch['wthw'];
                } else {
                    $wthw = "";
                }

                if ($batch['blinds'] > 0) {
                    $bands = $batch['blinds'];
                } else {
                    $bands = "";
                }

                $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, $batch['date']);
                $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, date('n/j/y', $batch['batch_completed_date']));
                $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, $batch['order_number']);
                $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, $batch['batch_id']);
                $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, "$" . number_format($batch['dollars'], 2, '.', ','));
                $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, $ccea);
                $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, $cclf);
                $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $trklf);
                $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $bsea);
                $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $drapeea);
                $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $drapewidths);
                $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $valea);
                $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $vallf);
                $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $cornea);
                $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $cornlf);
                $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $wthw);
                $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $bands);
            }
        }

        $rowNumber++;

        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, 'TOTALS');
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, '$' . number_format($producedTotals['dollars'], 2, '.', ','));
        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, $producedTotals['ccqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, $producedTotals['cclf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $producedTotals['tracklf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $producedTotals['bs']);
        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $producedTotals['drapeqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $producedTotals['drapewidths']);
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $producedTotals['valqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $producedTotals['vallf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $producedTotals['cornqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $producedTotals['cornlf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $producedTotals['wthw']);
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $producedTotals['blinds']);

        $objPHPExcel->getActiveSheet()->getStyle('D' . $rowNumber . ':Q' . $rowNumber)->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );


        $objPHPExcel->createSheet(1);
        $objPHPExcel->setActiveSheetIndex(1);
        $objPHPExcel->getActiveSheet()->setTitle('FAILED TO PRODUCE');



        $rowNumber = 1;

        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, 'SCHEDULED');
        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, 'PRODUCED');
        $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, 'WO#');
        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, 'BATCH#');
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, 'Dollars');
        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, 'CC ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, 'CC LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, 'TRK LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, 'BS ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, 'DRAPE ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, 'DRAPE WIDTHS');
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, 'VAL ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, 'VAL LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, 'CORN ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, 'CORN LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, 'WT HW');
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, 'B&S');



        $objPHPExcel->getActiveSheet()->getStyle('A1:Q1')->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(19);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(12);




        $objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('E1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('G1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('I1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('J1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('K1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('L1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('M1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('N1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('O1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('P1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('Q1')->getAlignment()->setHorizontal('center');


        $notProducedTotals = array(
            'dollars' => 0,
            'ccqty' => 0,
            'cclf' => 0,
            'tracklf' => 0,
            'bs' => 0,
            'drapeqty' => 0,
            'drapewidths' => 0,
            //'ttqty' => 0,
            //'ttlf' => 0,	
            'valqty' => 0,
            'vallf' => 0,
            'cornqty' => 0,
            'cornlf' => 0,
            'wthw' => 0,
            'blinds' => 0
        );

        $failedcount = 0;

        $rowNumber++;

        foreach ($failedBatches as $batch) {
            //if(is_null($batch['batch_completed_date']) || $batch['batch_completed_date'] == 0 || $batch['batch_completed_date'] > $endTS){
            $failedcount++;

            $notProducedTotals['dollars'] = ($notProducedTotals['dollars'] + floatval($batch['dollars']));
            $notProducedTotals['ccqty'] = ($notProducedTotals['ccqty'] + floatval($batch['cc']));
            $notProducedTotals['cclf'] = ($notProducedTotals['cclf'] + floatval($batch['cclf']));
            $notProducedTotals['tracklf'] = ($notProducedTotals['tracklf'] + floatval($batch['trklf']));
            $notProducedTotals['bs'] = ($notProducedTotals['bs'] + floatval($batch['bs']));
            $notProducedTotals['drapeqty'] = ($notProducedTotals['drapeqty'] + floatval($batch['drape']));
            $notProducedTotals['drapewidths'] = ($notProducedTotals['drapewidths'] + floatval($batch['drape_widths']));

            //$notProducedTotals['ttqty'] = ($notProducedTotals['ttqty'] + floatval($batch['wt']));
            //$notProducedTotals['ttlf'] = ($notProducedTotals['ttlf'] + floatval($batch['wtlf']));
            $notProducedTotals['valqty'] = ($notProducedTotals['valqty'] + floatval($batch['val']));
            $notProducedTotals['vallf'] = ($notProducedTotals['vallf'] + floatval($batch['vallf']));
            $notProducedTotals['cornqty'] = ($notProducedTotals['cornqty'] + floatval($batch['corn']));
            $notProducedTotals['cornlf'] = ($notProducedTotals['cornlf'] + floatval($batch['cornlf']));

            $notProducedTotals['wthw'] = ($notProducedTotals['wthw'] + floatval($batch['wthw']));
            $notProducedTotals['blinds'] = ($notProducedTotals['blinds'] + floatval($batch['blinds']));


            if ($batch['cc'] > 0) {
                $ccea = $batch['cc'];
            } else {
                $ccea = "";
            }

            if ($batch['cclf'] > 0) {
                $cclf = $batch['cclf'];
            } else {
                $cclf = "";
            }

            if ($batch['trklf'] > 0) {
                $trklf = $batch['trklf'] . " LF";
            } else {
                $trklf = "";
            }

            if ($batch['bs'] > 0) {
                $bsea = $batch['bs'];
            } else {
                $bsea = "";
            }

            if ($batch['drape'] > 0) {
                $drapeea = $batch['drape'];
            } else {
                $drapeea = "";
            }

            if ($batch['drape_widths'] > 0) {
                $drapewidths = $batch['drape_widths'];
            } else {
                $drapewidths = "";
            }

            /*
                if($batch['wt'] > 0){
        			$ttea=$batch['wt'];
        		}else{
        			$ttea="";
        		}
        		
        		if($batch['wtlf'] > 0){
        			$ttlf=$batch['wtlf'];
        		}else{
        			$ttlf="";
        		}
        		*/

            if ($batch['val'] > 0) {
                $valea = $batch['val'];
            } else {
                $valea = "";
            }

            if ($batch['vallf'] > 0) {
                $vallf = $batch['vallf'];
            } else {
                $vallf = "";
            }

            if ($batch['corn'] > 0) {
                $cornea = $batch['corn'];
            } else {
                $cornea = "";
            }

            if ($batch['cornlf'] > 0) {
                $cornlf = $batch['cornlf'];
            } else {
                $cornlf = "";
            }

            if ($batch['wthw'] > 0) {
                $wthw = $batch['wthw'];
            } else {
                $wthw = "";
            }

            if ($batch['blinds'] > 0) {
                $bands = $batch['blinds'];
            } else {
                $bands = "";
            }

            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, $batch['date']);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, '---');
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, $batch['order_number']);
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, $batch['batch_id']);
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, "$" . number_format($batch['dollars'], 2, '.', ','));
            $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, $ccea);
            $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, $cclf);
            $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $trklf);
            $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $bsea);
            $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $drapeea);
            $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $drapewidths);
            $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $valea);
            $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $vallf);
            $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $cornea);
            $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $cornlf);
            $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $wthw);
            $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $bands);

            $rowNumber++;
            //}
        }


        //$rowNumber++;

        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, 'TOTALS');
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, '$' . number_format($notProducedTotals['dollars'], 2, '.', ','));
        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, $notProducedTotals['ccqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, $notProducedTotals['cclf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $notProducedTotals['tracklf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $notProducedTotals['bs']);
        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $notProducedTotals['drapeqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $notProducedTotals['drapewidths']);
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $notProducedTotals['valqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $notProducedTotals['vallf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $notProducedTotals['cornqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $notProducedTotals['cornlf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $notProducedTotals['wthw']);
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $notProducedTotals['blinds']);


        $objPHPExcel->getActiveSheet()->getStyle('D' . $rowNumber . ':Q' . $rowNumber)->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );

        $objPHPExcel->setActiveSheetIndex(0);

        $objPHPExcel->removeSheetByIndex(2);


        // Redirect output to a client’s web browser (Excel5)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Production Report ' . $start . '-' . $end . '.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }



	public function invoicedordersdownload($start,$end){
        $this->autoRender = false;


        $startTS = strtotime($start . ' 00:00:00');
        $endTS = strtotime($end . ' 23:59:59');

        $days = ceil(((($endTS + 1) - $startTS) / 86400));

        $dateList = array();
        for ($i = 1; $i <= $days; $i++) {
            $dateList[] = date('Y-m-d', ($startTS + (($i - 1) * 86400) + 21600));
        }

        $conditions = [
            'batch_invoiced_date >=' => $startTS,
            'batch_invoiced_date <' => $endTS
        ];

        $batches = $this->SherryCache->find('all', ['conditions' => $conditions])->toArray();


        require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
        require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");

        $objPHPExcel = new \PHPExcel();

        $objPHPExcel->createSheet(0);
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->getActiveSheet()->setTitle('INVOICED');


        $rowNumber = 1;

        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, 'SCHEDULED');
        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, 'PRODUCED');
        $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, 'SHIPPED');
        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, 'INVOICED');
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, 'WO#');
        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, 'BATCH#');
        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, 'Dollars');
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, 'CC ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, 'CC LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, 'TRK LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, 'BS ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, 'DRAPE ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, 'DRAPE WIDTHS');
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, 'VAL ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, 'VAL LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, 'CORN ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, 'CORN LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, 'WT HW');
        $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, 'B&S');
        $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowNumber, 'TRACKING #');

        $objPHPExcel->getActiveSheet()->getStyle('A1:T1')->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(19);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(22);


        $objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('E1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('G1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('I1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('J1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('K1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('L1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('M1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('N1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('O1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('P1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('Q1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('R1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('S1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('T1')->getAlignment()->setHorizontal('center');


        $shippedTotals = array(
            'dollars' => 0,
            'ccqty' => 0,
            'cclf' => 0,
            'tracklf' => 0,
            'bs' => 0,
            'drapeqty' => 0,
            'drapewidths' => 0,
            //'ttqty' => 0,
            //'ttlf' => 0,	
            'valqty' => 0,
            'vallf' => 0,
            'cornqty' => 0,
            'cornlf' => 0,
            'wthw' => 0,
            'blinds' => 0
        );

        $data = '';
        $shipments = array();

        foreach ($batches as $batch) {

            $shipStatusesThisBatch = $this->OrderItemStatus->find('all', ['conditions' => ['sherry_batch_id' => $batch['batch_id'], 'status' => 'Shipped', 'shipment_id !=' => NULL, 'shipment_id !=' => 0]])->toArray();
            foreach ($shipStatusesThisBatch as $shipStatus) {
                $shipment = $this->Shipments->get($shipStatus['shipment_id'])->toArray();
                $shipments[$batch['batch_id']] = array('tracking' => $shipment['tracking_number'], 'delivery_address' => $shipment['tracking_number']);
            }


            if ($batch['batch_invoiced_date'] > $startTS && $batch['batch_invoiced_date'] <= $endTS) {

                $rowNumber++;

                $data .= print_r($batch, 1);

                $shippedTotals['dollars'] = ($shippedTotals['dollars'] + floatval($batch['dollars']));
                $shippedTotals['ccqty'] = ($shippedTotals['ccqty'] + floatval($batch['cc']));
                $shippedTotals['cclf'] = ($shippedTotals['cclf'] + floatval($batch['cclf']));
                $shippedTotals['tracklf'] = ($shippedTotals['tracklf'] + floatval($batch['trklf']));
                $shippedTotals['bs'] = ($shippedTotals['bs'] + floatval($batch['bs']));
                $shippedTotals['drapeqty'] = ($shippedTotals['drapeqty'] + floatval($batch['drape']));
                $shippedTotals['drapewidths'] = ($shippedTotals['drapewidths'] + floatval($batch['drape_widths']));
                //$shippedTotals['ttqty'] = ($shippedTotals['ttqty'] + floatval($batch['wt']));
                //$shippedTotals['ttlf'] = ($shippedTotals['ttlf'] + floatval($batch['wtlf']));
                $shippedTotals['valqty'] = ($shippedTotals['valqty'] + floatval($batch['val']));
                $shippedTotals['vallf'] = ($shippedTotals['vallf'] + floatval($batch['vallf']));
                $shippedTotals['cornqty'] = ($shippedTotals['cornqty'] + floatval($batch['corn']));
                $shippedTotals['cornlf'] = ($shippedTotals['cornlf'] + floatval($batch['cornlf']));
                $shippedTotals['wthw'] = ($shippedTotals['wthw'] + floatval($batch['wthw']));
                $shippedTotals['blinds'] = ($shippedTotals['blinds'] + floatval($batch['blinds']));


                if ($batch['cc'] > 0) {
                    $ccea = $batch['cc'];
                } else {
                    $ccea = "";
                }

                if ($batch['cclf'] > 0) {
                    $cclf = $batch['cclf'];
                } else {
                    $cclf = "";
                }

                if ($batch['trklf'] > 0) {
                    $trklf = $batch['trklf'] . " LF";
                } else {
                    $trklf = "";
                }

                if ($batch['bs'] > 0) {
                    $bsea = $batch['bs'];
                } else {
                    $bsea = "";
                }

                if ($batch['drape'] > 0) {
                    $drapeea = $batch['drape'];
                } else {
                    $drapeea = "";
                }

                if ($batch['drape_widths'] > 0) {
                    $drapewidths = $batch['drape_widths'];
                } else {
                    $drapewidths = "";
                }

                /*
                if($batch['wt'] > 0){
        			$ttea=$batch['wt'];
        		}else{
        			$ttea="";
        		}
        		
        		if($batch['wtlf'] > 0){
        			$ttlf=$batch['wtlf'];
        		}else{
        			$ttlf="";
        		}
        		*/

                if ($batch['val'] > 0) {
                    $valea = $batch['val'];
                } else {
                    $valea = "";
                }

                if ($batch['vallf'] > 0) {
                    $vallf = $batch['vallf'];
                } else {
                    $vallf = "";
                }

                if ($batch['corn'] > 0) {
                    $cornea = $batch['corn'];
                } else {
                    $cornea = "";
                }

                if ($batch['cornlf'] > 0) {
                    $cornlf = $batch['cornlf'];
                } else {
                    $cornlf = "";
                }


                if ($batch['wthw'] > 0) {
                    $wthw = $batch['wthw'];
                } else {
                    $wthw = "";
                }

                if ($batch['blinds'] > 0) {
                    $bands = $batch['blinds'];
                } else {
                    $bands = "";
                }


                if (isset($shipments[$batch['batch_id']]['tracking'])) {
                    $trackingnumber = $shipments[$batch['batch_id']]['tracking'];
                } else {
                    $trackingnumber = '';
                }


                if ($batch['batch_invoiced_date'] > 1000) {
                    $invoicedDate = date('n/j/y', $batch['batch_invoiced_date']);
                } else {
                    $invoicedDate = '---';
                }

                if ($batch['batch_completed_date'] > 1000) {
                    $completedDate = date('n/j/y', $batch['batch_completed_date']);
                } else {
                    $completedDate = '---';
                }


                if ($batch['batch_shipped_date'] > 1000) {
                    //$shippedDate=date('n/j/y',$batch['batch_shipped_date']);
                    $batchShippedDateTimeObj = new \DateTime();
                    $batchShippedDateTimeObj->setTimestamp($batch['batch_shipped_date']);
                    $shippedDate = \PHPExcel_Shared_Date::PHPToExcel($batchShippedDateTimeObj);
                } else {
                    $shippedDate = '';
                }

                $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, $batch['date']);
                $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, $completedDate);
                $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, $shippedDate);
                $objPHPExcel->getActiveSheet()->getStyle('C' . $rowNumber)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, $invoicedDate);
                $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, $batch['order_number']);
                $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, $batch['batch_id']);
                $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, "$" . number_format($batch['dollars'], 2, '.', ','));
                $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $ccea);
                $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $cclf);
                $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $trklf);
                $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $bsea);
                $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $drapeea);
                $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $drapewidths);
                $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $valea);
                $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $vallf);
                $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $cornea);
                $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $cornlf);
                $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, $wthw);
                $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, $bands);
                $objPHPExcel->getActiveSheet()->SetCellValueExplicit('T' . $rowNumber, $trackingnumber, \PHPExcel_Cell_DataType::TYPE_STRING);
            }
        }

        $rowNumber++;

        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, 'TOTALS');
        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, '$' . number_format($shippedTotals['dollars'], 2, '.', ','));
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $shippedTotals['ccqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $shippedTotals['cclf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $shippedTotals['tracklf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $shippedTotals['bs']);
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $shippedTotals['drapeqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $shippedTotals['drapewidths']);
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $shippedTotals['valqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $shippedTotals['vallf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $shippedTotals['cornqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $shippedTotals['cornlf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, $shippedTotals['wthw']);
        $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, $shippedTotals['blinds']);

        $objPHPExcel->getActiveSheet()->getStyle('F' . $rowNumber . ':S' . $rowNumber)->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );


        $objPHPExcel->removeSheetByIndex(1);


        // Redirect output to a client’s web browser (Excel5)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Invoiced Report ' . $start . '-' . $end . '.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }



	public function shippedordersdownload($start,$end){
        $this->autoRender = false;


        $startTS = strtotime($start . ' 00:00:00');
        $endTS = strtotime($end . ' 23:59:59');

        $days = ceil(((($endTS + 1) - $startTS) / 86400));

        $dateList = array();
        for ($i = 1; $i <= $days; $i++) {
            $dateList[] = date('Y-m-d', ($startTS + (($i - 1) * 86400) + 21600));
        }

        $conditions = [
            'batch_shipped_date >=' => $startTS,
            'batch_shipped_date <' => $endTS //,
            //'OR' => ['date IN' => $dateList]
        ];

        $batches = $this->SherryCache->find('all', ['conditions' => $conditions])->toArray();

        //separate query needed for 'failed to produce' table
        $lookupFailedBatches = $this->SherryCache->find('all', ['conditions' => ['date IN' => $dateList]])->toArray();
        $failedBatches = array();
        foreach ($lookupFailedBatches as $batch) {
            if ($batch['batch_shipped_date'] == 0 || $batch['batch_shipped_date'] > strtotime($batch['date'] . ' 17:00:00')) {
                $failedBatches[] = $batch;
            }
        }

        $this->set('failedBatches', $failedBatches);

        require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
        require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");

        $objPHPExcel = new \PHPExcel();

        $objPHPExcel->createSheet(0);
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->getActiveSheet()->setTitle('SHIPPED');

        $rowNumber = 1;

        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, 'SCHEDULED');
        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, 'PRODUCED');
        $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, 'SHIPPED');
        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, 'INVOICED');
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, 'WO#');

        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, 'TYPE');

        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, 'CUSTOMER');
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, 'CUST PO#');

        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, 'RECIPIENT');

        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, 'BATCH#');
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, 'Dollars');
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, 'CC ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, 'CC LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, 'TRK LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, 'BS ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, 'DRAPE ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, 'DRAPE WIDTHS');
        $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, 'VAL ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, 'VAL LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowNumber, 'CORN ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowNumber, 'CORN LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowNumber, 'WT HW');
        $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowNumber, 'B&S');
        $objPHPExcel->getActiveSheet()->SetCellValue('X' . $rowNumber, 'TRACKING #');

        $objPHPExcel->getActiveSheet()->getStyle('A1:X1')->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(16);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(19);
        $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(22);


        $objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('E1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('G1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('I1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('J1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('K1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('L1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('M1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('N1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('O1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('P1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('Q1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('R1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('S1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('T1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('U1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('V1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('W1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('X1')->getAlignment()->setHorizontal('center');


        $shippedTotals = array(
            'dollars' => 0,
            'ccqty' => 0,
            'cclf' => 0,
            'tracklf' => 0,
            'bs' => 0,
            'drapeqty' => 0,
            'drapewidths' => 0,
            //'ttqty' => 0,
            //'ttlf' => 0,	
            'valqty' => 0,
            'vallf' => 0,
            'cornqty' => 0,
            'cornlf' => 0,
            'wthw' => 0,
            'blinds' => 0
        );

        $data = '';
        $shipments = array();

        foreach ($batches as $batch) {

            $shipStatusesThisBatch = $this->OrderItemStatus->find('all', ['conditions' => ['sherry_batch_id' => $batch['batch_id'], 'status' => 'Shipped', 'shipment_id !=' => NULL, 'shipment_id !=' => 0]])->toArray();
            foreach ($shipStatusesThisBatch as $shipStatus) {
                $shipment = $this->Shipments->get($shipStatus['shipment_id'])->toArray();
                $shipments[$batch['batch_id']] = array('tracking' => $shipment['tracking_number'], 'delivery_address' => $shipment['tracking_number']);
            }


            if ($batch['batch_shipped_date'] > $startTS && $batch['batch_shipped_date'] <= $endTS) {

                $rowNumber++;

                $data .= print_r($batch, 1);

                $shippedTotals['dollars'] = ($shippedTotals['dollars'] + floatval($batch['dollars']));
                $shippedTotals['ccqty'] = ($shippedTotals['ccqty'] + floatval($batch['cc']));
                $shippedTotals['cclf'] = ($shippedTotals['cclf'] + floatval($batch['cclf']));
                $shippedTotals['tracklf'] = ($shippedTotals['tracklf'] + floatval($batch['trklf']));
                $shippedTotals['bs'] = ($shippedTotals['bs'] + floatval($batch['bs']));
                $shippedTotals['drapeqty'] = ($shippedTotals['drapeqty'] + floatval($batch['drape']));
                $shippedTotals['drapewidths'] = ($shippedTotals['drapewidths'] + floatval($batch['drape_widths']));
                //$shippedTotals['ttqty'] = ($shippedTotals['ttqty'] + floatval($batch['wt']));
                //$shippedTotals['ttlf'] = ($shippedTotals['ttlf'] + floatval($batch['wtlf']));
                $shippedTotals['valqty'] = ($shippedTotals['valqty'] + floatval($batch['val']));
                $shippedTotals['vallf'] = ($shippedTotals['vallf'] + floatval($batch['vallf']));
                $shippedTotals['cornqty'] = ($shippedTotals['cornqty'] + floatval($batch['corn']));
                $shippedTotals['cornlf'] = ($shippedTotals['cornlf'] + floatval($batch['cornlf']));
                $shippedTotals['wthw'] = ($shippedTotals['wthw'] + floatval($batch['wthw']));
                $shippedTotals['blinds'] = ($shippedTotals['blinds'] + floatval($batch['blinds']));


                if ($batch['cc'] > 0) {
                    $ccea = $batch['cc'];
                } else {
                    $ccea = "";
                }

                if ($batch['cclf'] > 0) {
                    $cclf = $batch['cclf'];
                } else {
                    $cclf = "";
                }

                if ($batch['trklf'] > 0) {
                    $trklf = $batch['trklf'] . " LF";
                } else {
                    $trklf = "";
                }

                if ($batch['bs'] > 0) {
                    $bsea = $batch['bs'];
                } else {
                    $bsea = "";
                }

                if ($batch['drape'] > 0) {
                    $drapeea = $batch['drape'];
                } else {
                    $drapeea = "";
                }

                if ($batch['drape_widths'] > 0) {
                    $drapewidths = $batch['drape_widths'];
                } else {
                    $drapewidths = "";
                }

                /*
                if($batch['wt'] > 0){
        			$ttea=$batch['wt'];
        		}else{
        			$ttea="";
        		}
        		
        		if($batch['wtlf'] > 0){
        			$ttlf=$batch['wtlf'];
        		}else{
        			$ttlf="";
        		}
        		*/

                if ($batch['val'] > 0) {
                    $valea = $batch['val'];
                } else {
                    $valea = "";
                }

                if ($batch['vallf'] > 0) {
                    $vallf = $batch['vallf'];
                } else {
                    $vallf = "";
                }

                if ($batch['corn'] > 0) {
                    $cornea = $batch['corn'];
                } else {
                    $cornea = "";
                }

                if ($batch['cornlf'] > 0) {
                    $cornlf = $batch['cornlf'];
                } else {
                    $cornlf = "";
                }

                if ($batch['wthw'] > 0) {
                    $wthw = $batch['wthw'];
                } else {
                    $wthw = "";
                }

                if ($batch['blinds'] > 0) {
                    $bands = $batch['blinds'];
                } else {
                    $bands = "";
                }


                if (isset($shipments[$batch['batch_id']]['tracking'])) {
                    $trackingnumber = $shipments[$batch['batch_id']]['tracking'];
                } else {
                    $trackingnumber = '';
                }


                if ($batch['batch_invoiced_date'] > 1000) {
                    $invoicedDate = date('n/j/y', $batch['batch_invoiced_date']);
                } else {
                    $invoicedDate = '---';
                }

                $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, $batch['date']);
                $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, date('n/j/y', $batch['batch_completed_date']));
                $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, date('n/j/y', $batch['batch_shipped_date']));
                $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, $invoicedDate);
                $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, $batch['order_number']);
                $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, $batch['order_type']);
                $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, $batch['company_name']);
                $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $batch['customer_po_number']);

                $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $batch['facility']);

                $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $batch['batch_id']);
                $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $batch['dollars']);
                $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $ccea);
                $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $cclf);
                $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $trklf);
                $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $bsea);
                $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $drapeea);
                $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $drapewidths);
                $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, $valea);
                $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, $vallf);
                $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowNumber, $cornea);
                $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowNumber, $cornlf);
                $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowNumber, $wthw);
                $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowNumber, $bands);
                $objPHPExcel->getActiveSheet()->SetCellValueExplicit('X' . $rowNumber, $trackingnumber, \PHPExcel_Cell_DataType::TYPE_STRING);
            }
        }

        $rowNumber++;


        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, 'TOTALS');
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $shippedTotals['dollars']);
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $shippedTotals['ccqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $shippedTotals['cclf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $shippedTotals['tracklf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $shippedTotals['bs']);
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $shippedTotals['drapeqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $shippedTotals['drapewidths']);
        $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, $shippedTotals['valqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, $shippedTotals['vallf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowNumber, $shippedTotals['cornqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowNumber, $shippedTotals['cornlf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowNumber, $shippedTotals['wthw']);
        $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowNumber, $shippedTotals['blinds']);


        //set DOLLARS column to CURRENCY format
        $objPHPExcel->getActiveSheet()->getStyle('K2:K' . $rowNumber)->getNumberFormat()->setFormatCode(\PHPExcel_Style_NumberFormat::FORMAT_CURRENCY_USD);


        $objPHPExcel->getActiveSheet()->getStyle('J' . $rowNumber . ':W' . $rowNumber)->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );


        $objPHPExcel->createSheet(1);
        $objPHPExcel->setActiveSheetIndex(1);
        $objPHPExcel->getActiveSheet()->setTitle('FAILED TO SHIP');



        $rowNumber = 1;

        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, 'SCHEDULED');
        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, 'PRODUCED');
        $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, 'SHIPPED');
        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, 'INVOICED');
        $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, 'WO#');

        $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, 'TYPE');

        $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, 'CUSTOMER');
        $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, 'CUST PO#');

        $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, 'RECIPIENT');

        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, 'BATCH#');

        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, 'Dollars');
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, 'CC ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, 'CC LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, 'TRK LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, 'BS ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, 'DRAPE ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, 'DRAPE WIDTHS');
        $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, 'VAL ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, 'VAL LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowNumber, 'CORN ea');
        $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowNumber, 'CORN LF');
        $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowNumber, 'WT HW');
        $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowNumber, 'B&S');
        $objPHPExcel->getActiveSheet()->SetCellValue('X' . $rowNumber, 'TRACKING #');



        $objPHPExcel->getActiveSheet()->getStyle('A1:X1')->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(16);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(19);
        $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(22);


        $objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('B1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('C1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('D1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('E1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('F1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('G1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('H1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('I1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('J1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('K1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('L1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('M1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('N1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('O1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('P1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('Q1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('R1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('S1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('T1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('U1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('V1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('W1')->getAlignment()->setHorizontal('center');
        $objPHPExcel->getActiveSheet()->getStyle('X1')->getAlignment()->setHorizontal('center');


        $notShippedTotals = array(
            'dollars' => 0,
            'ccqty' => 0,
            'cclf' => 0,
            'tracklf' => 0,
            'bs' => 0,
            'drapeqty' => 0,
            'drapewidths' => 0,
            //'ttqty' => 0,
            //'ttlf' => 0,    
            'valqty' => 0,
            'vallf' => 0,
            'cornqty' => 0,
            'cornlf' => 0,
            'wthw' => 0,
            'blinds' => 0
        );

        $failedcount = 0;

        $rowNumber++;

        foreach ($failedBatches as $batch) {
            //if(is_null($batch['batch_shipped_date']) || $batch['batch_shipped_date'] == 0 || $batch['batch_shipped_date'] > $endTS){
            $failedcount++;

            $notShippedTotals['dollars'] = ($notShippedTotals['dollars'] + floatval($batch['dollars']));
            $notShippedTotals['ccqty'] = ($notShippedTotals['ccqty'] + floatval($batch['cc']));
            $notShippedTotals['cclf'] = ($notShippedTotals['cclf'] + floatval($batch['cclf']));
            $notShippedTotals['tracklf'] = ($notShippedTotals['tracklf'] + floatval($batch['trklf']));
            $notShippedTotals['bs'] = ($notShippedTotals['bs'] + floatval($batch['bs']));
            $notShippedTotals['drapeqty'] = ($notShippedTotals['drapeqty'] + floatval($batch['drape']));
            $notShippedTotals['drapewidths'] = ($notShippedTotals['drapewidths'] + floatval($batch['drape_widths']));
            $notShippedTotals['valqty'] = ($notShippedTotals['valqty'] + floatval($batch['val']));
            $notShippedTotals['vallf'] = ($notShippedTotals['vallf'] + floatval($batch['vallf']));
            $notShippedTotals['cornqty'] = ($notShippedTotals['cornqty'] + floatval($batch['corn']));
            $notShippedTotals['cornlf'] = ($notShippedTotals['cornlf'] + floatval($batch['cornlf']));
            $notShippedTotals['wthw'] = ($notShippedTotals['wthw'] + floatval($batch['wthw']));
            $notShippedTotals['blinds'] = ($notShippedTotals['blinds'] + floatval($batch['blinds']));

            if ($batch['cc'] > 0) {
                $ccea = $batch['cc'];
            } else {
                $ccea = "";
            }

            if ($batch['cclf'] > 0) {
                $cclf = $batch['cclf'];
            } else {
                $cclf = "";
            }

            if ($batch['trklf'] > 0) {
                $trklf = $batch['trklf'] . " LF";
            } else {
                $trklf = "";
            }

            if ($batch['bs'] > 0) {
                $bsea = $batch['bs'];
            } else {
                $bsea = "";
            }

            if ($batch['drape'] > 0) {
                $drapeea = $batch['drape'];
            } else {
                $drapeea = "";
            }

            if ($batch['drape_widths'] > 0) {
                $drapewidths = $batch['drape_widths'];
            } else {
                $drapewidths = "";
            }

            /*
                if($batch['wt'] > 0){
        			$ttea=$batch['wt'];
        		}else{
        			$ttea="";
        		}
        		
        		if($batch['wtlf'] > 0){
        			$ttlf=$batch['wtlf'];
        		}else{
        			$ttlf="";
        		}
        		*/

            if ($batch['val'] > 0) {
                $valea = $batch['val'];
            } else {
                $valea = "";
            }

            if ($batch['vallf'] > 0) {
                $vallf = $batch['vallf'];
            } else {
                $vallf = "";
            }

            if ($batch['corn'] > 0) {
                $cornea = $batch['corn'];
            } else {
                $cornea = "";
            }

            if ($batch['cornlf'] > 0) {
                $cornlf = $batch['cornlf'];
            } else {
                $cornlf = "";
            }

            if ($batch['wthw'] > 0) {
                $wthw = $batch['wthw'];
            } else {
                $wthw = "";
            }

            if ($batch['blinds'] > 0) {
                $bands = $batch['blinds'];
            } else {
                $bands = "";
            }


            if ($batch['batch_completed_date'] == 0) {
                $ifCompleted = '---';
            } else {
                $ifCompleted = date('n/j/y', $batch['batch_completed_date']);
            }

            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowNumber, $batch['date']);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowNumber, $ifCompleted);
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowNumber, '---');
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowNumber, '---');
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowNumber, $batch['order_number']);

            $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowNumber, $batch['order_type']);

            $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowNumber, $batch['company_name']);
            $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowNumber, $batch['customer_po_number']);

            $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowNumber, $batch['facility']);

            $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, $batch['batch_id']);
            $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $batch['dollars']);
            $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $ccea);
            $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $cclf);
            $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $trklf);
            $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $bsea);
            $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $drapeea);
            $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $drapewidths);
            $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, $valea);
            $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, $vallf);
            $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowNumber, $cornea);
            $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowNumber, $cornlf);
            $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowNumber, $wthw);
            $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowNumber, $bands);
            $objPHPExcel->getActiveSheet()->SetCellValue('X' . $rowNumber, '---');

            //}
            $rowNumber++;
        }


        $objPHPExcel->getActiveSheet()->getStyle('K2:K' . $rowNumber)->getNumberFormat()->setFormatCode(\PHPExcel_Style_NumberFormat::FORMAT_CURRENCY_USD_SIMPLE);

        //$rowNumber++;

        $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowNumber, 'TOTALS');
        $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowNumber, $notProducedTotals['dollars']);
        $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowNumber, $notShippedTotals['ccqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowNumber, $notShippedTotals['cclf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowNumber, $notShippedTotals['tracklf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowNumber, $notShippedTotals['bs']);
        $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowNumber, $notShippedTotals['drapeqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowNumber, $notShippedTotals['drapewidths']);
        $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowNumber, $notShippedTotals['valqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowNumber, $notShippedTotals['vallf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowNumber, $notShippedTotals['cornqty']);
        $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowNumber, $notShippedTotals['cornlf']);
        $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowNumber, $notShippedTotals['wthw']);
        $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowNumber, $notShippedTotals['blinds']);

        //set DOLLARS column to CURRENCY format
        $objPHPExcel->getActiveSheet()->getStyle('K2:K' . $rowNumber)->getNumberFormat()->setFormatCode(\PHPExcel_Style_NumberFormat::FORMAT_CURRENCY_USD_SIMPLE);


        $objPHPExcel->getActiveSheet()->getStyle('J' . $rowNumber . ':W' . $rowNumber)->applyFromArray(
            array(
                'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => '000000')
                ),
                'font' => array(
                    'bold' => true,
                    'color' => array('rgb' => 'FFFFFF')
                )
            )
        );

        $objPHPExcel->setActiveSheetIndex(0);

        $objPHPExcel->removeSheetByIndex(2);


        // Redirect output to a client’s web browser (Excel5)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="Shipping Report ' . $start . '-' . $end . '.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }



	public function invoicedorders(){
        if (isset($this->request->data['report_date_start']) && isset($this->request->data['report_date_end'])) {
            $this->autoRender = false;

            $startTS = strtotime($this->request->data['report_date_start'] . ' 00:00:00');
            $endTS = strtotime($this->request->data['report_date_end'] . ' 23:59:59');


            $days = ceil(((($endTS + 1) - $startTS) / 86400));

            $dateList = array();
            for ($i = 1; $i <= $days; $i++) {
                $dateList[] = date('Y-m-d', ($startTS + (($i - 1) * 86400) + 21600));
            }

            $conditions = [
                'batch_invoiced_date >=' => $startTS,
                'batch_invoiced_date <' => $endTS
            ];




            $batches = $this->SherryCache->find('all', ['conditions' => $conditions])->toArray();
            $this->set('batches', $batches);


            $this->set('inputs', $this->request->data);
            $this->render('viewinvoicedorders');
        }
    }



	public function shippedorders(){

        if (isset($this->request->data['report_date_start']) && isset($this->request->data['report_date_end'])) {
            $this->autoRender = false;

            $startTS = strtotime($this->request->data['report_date_start'] . ' 00:00:00');
            $endTS = strtotime($this->request->data['report_date_end'] . ' 23:59:59');


            $days = ceil(((($endTS + 1) - $startTS) / 86400));

            $dateList = array();
            for ($i = 1; $i <= $days; $i++) {
                $dateList[] = date('Y-m-d', ($startTS + (($i - 1) * 86400) + 21600));
            }

            $conditions = [
                'batch_shipped_date >=' => $startTS,
                'batch_shipped_date <' => $endTS //,
                //'OR' => ['date IN' => $dateList]
            ];




            $batches = $this->SherryCache->find('all', ['conditions' => $conditions])->toArray();
            $this->set('batches', $batches);


            //separate query needed for 'failed to produce' table
            $lookupFailedBatches = $this->SherryCache->find('all', ['conditions' => ['date IN' => $dateList]])->toArray();
            $failedBatches = array();
            foreach ($lookupFailedBatches as $batch) {
                if ($batch['batch_shipped_date'] == 0 || $batch['batch_shipped_date'] > strtotime($batch['date'] . ' 17:00:00')) {
                    $failedBatches[] = $batch;
                }
            }

            $this->set('failedBatches', $failedBatches);


            $shipments = array();
            foreach ($batches as $batch) {
                $shipStatusesThisBatch = $this->OrderItemStatus->find('all', ['conditions' => ['sherry_batch_id' => $batch['batch_id'], 'status' => 'Shipped', 'shipment_id !=' => NULL, 'shipment_id !=' => 0]])->toArray();
                foreach ($shipStatusesThisBatch as $shipStatus) {
                    $shipment = $this->Shipments->get($shipStatus['shipment_id'])->toArray();
                    $shipments[$batch['batch_id']] = array('tracking' => $shipment['tracking_number'], 'delivery_address' => $shipment['tracking_number']);
                }
            }
            $this->set('shipments', $shipments);

            $this->set('inputs', $this->request->data);
            $this->render('viewshippedorders');
        }
    }



	public function backlogreport($type='backlog'){
        $productMap = array(

            'cubicle-curtain' => 'Cubicle Curtain',

            'box-pleated' => 'Box Pleated Valance',

            'straight-cornice' => 'Straight Cornice',

            'bedspread' => 'Calculated Bedspread',

            'bedspread-manual' => 'Manually Entered Bedspread',

            'pinch-pleated' => 'Pinch Pleated Drapery',

            /* PPSASCRUM-326: start */
            /* PPSASCRUM-56: start */
            'new-pinch-pleated' => 'Pinch Pleated Drapery',
            /* PPSASCRUM-56: end */

            /* PPSASCRUM-305: start */
            'ripplefold-drapery' => 'Ripplefold Drapery',
            
            /* PPSASCRUM-384: start */
            'ripplefold-drapery' => 'Accordiafold Drapery'
            /* PPSASCRUM-384: end */
            /* PPSASCRUM-305: end */
            /* PPSASCRUM-326: end */

        );


        if ($this->request->data) {
            $this->autoRender = false;

            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");

            $objPHPExcel = new \PHPExcel();
            $objPHPExcel->setActiveSheetIndex(0);


            $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'ORDER #');

            $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'ORDER STATUS');

            $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'QUOTE #');

            $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'ORDER TYPE');

            $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'STAGE');

            $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'PM');
            $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'CUSTOMER');
            $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'CUSTOMER PO');
            $objPHPExcel->getActiveSheet()->SetCellValue('I1', 'RECIPIENT');
            $objPHPExcel->getActiveSheet()->SetCellValue('J1', 'SHIP DATE');

            $objPHPExcel->getActiveSheet()->SetCellValue('K1', 'SCHEDULED'); //moved from AB

            $objPHPExcel->getActiveSheet()->SetCellValue('L1', 'BOOK DATE');
            $objPHPExcel->getActiveSheet()->SetCellValue('M1', 'BATCH');
            $objPHPExcel->getActiveSheet()->SetCellValue('N1', 'LINE');

            $objPHPExcel->getActiveSheet()->SetCellValue('O1', 'LOCATION');

            $objPHPExcel->getActiveSheet()->SetCellValue('P1', 'QTY');


            $objPHPExcel->getActiveSheet()->SetCellValue('Q1', 'CLASS');
            $objPHPExcel->getActiveSheet()->SetCellValue('R1', 'SUBCLASS');


            $objPHPExcel->getActiveSheet()->SetCellValue('S1', 'UNIT');
            $objPHPExcel->getActiveSheet()->SetCellValue('T1', 'LINE ITEM');
            $objPHPExcel->getActiveSheet()->SetCellValue('U1', 'FABRIC');
            $objPHPExcel->getActiveSheet()->SetCellValue('V1', 'COLOR');

            $objPHPExcel->getActiveSheet()->SetCellValue('W1', 'CUT WIDTH');
            $objPHPExcel->getActiveSheet()->SetCellValue('X1', 'FIN WIDTH');

            $objPHPExcel->getActiveSheet()->SetCellValue('Y1', 'LENGTH');

            $objPHPExcel->getActiveSheet()->SetCellValue('Z1', 'CC LF');

            $objPHPExcel->getActiveSheet()->SetCellValue('AA1', 'DRP WIDTHS');
            $objPHPExcel->getActiveSheet()->SetCellValue('AB1', 'TOP TR LF');


            $objPHPExcel->getActiveSheet()->SetCellValue('AC1', 'YDS / UNIT');
            $objPHPExcel->getActiveSheet()->SetCellValue('AD1', 'TOTAL YARDS');
            $objPHPExcel->getActiveSheet()->SetCellValue('AE1', 'BASE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AF1', 'TIERS');
            $objPHPExcel->getActiveSheet()->SetCellValue('AG1', 'ADJ PRICE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AH1', 'EXT PRICE');



            $objPHPExcel->getActiveSheet()->SetCellValue('AI1', 'PRODUCED');
            $objPHPExcel->getActiveSheet()->SetCellValue('AJ1', 'SHIPPED');

            $objPHPExcel->getActiveSheet()->SetCellValue('AK1', 'TRACKING #');
            /**PPSASCRUM-113 start **/
            $objPHPExcel->getActiveSheet()->SetCellValue('AL1', 'INVOICED DATE');
            /**PPSASCRUM-113 start **/

            $objPHPExcel->getActiveSheet()->SetCellValue('AM1', 'LINE NOTES');




            $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(40);
            $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(55);
            $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15); //SCHEDULED moved from AB

            $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);


            $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(22);
            $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(22);


            $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(75);

            $objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(20);


            $objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(20);


            $objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AD')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AE')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AF')->setWidth(30);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AG')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AH')->setWidth(15);


            $objPHPExcel->getActiveSheet()->getColumnDimension('AI')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AJ')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AK')->setWidth(29);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AL')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AM')->setWidth(70);



            $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(22);
            $objPHPExcel->getActiveSheet()->getStyle('A1:AM1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);

            $objPHPExcel->getActiveSheet()->getStyle('A1:AM1')->applyFromArray(
                array(
                    'fill' => array(
                        'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'F8CBAD')
                    )
                )
            );


            $rowCount = 2;

            $conditions = array();

            if ($type == 'backlog') {
                $conditions += array('status NOT IN' => array('Shipped', 'Canceled'));
            } else {
                $conditions += array('status !=' => 'Canceled');
            }

            if ((isset($this->request->data['datestart']) && strlen(trim($this->request->data['datestart'])) > 0) && (isset($this->request->data['dateend']) && strlen(trim($this->request->data['dateend'])) > 0)) {
                $conditions += array('created >=' => strtotime($this->request->data['datestart'] . ' 00:00:00'));
                $conditions += array('created <=' => strtotime($this->request->data['dateend'] . ' 23:59:59'));
            }

            if (isset($this->request->data['quotenumber']) && strlen(trim($this->request->data['quotenumber'])) > 0) {
            }

            if (isset($this->request->data['ordernumber']) && strlen(trim($this->request->data['ordernumber'])) > 0) {
            }

            if (isset($this->request->data['clientponumber']) && strlen(trim($this->request->data['clientponumber'])) > 0) {
            }


            if (isset($this->request->data['customer']) && count($this->request->data['customer']) > 0) {
                if (count($this->request->data['customer']) == 1) {
                    $conditions += array('customer_id' => $this->request->data['customer'][0]);
                } elseif (count($this->request->data['customer']) > 1) {
                    $conditions += array('customer_id IN' => $this->request->data['customer']);
                }
            }

            if (isset($this->request->data['hciagent']) && count($this->request->data['hciagent']) > 0) {
                if (count($this->request->data['hciagent']) == 1) {
                    $conditions += array('user_id' => $this->request->data['hciagent'][0]);
                } elseif (count($this->request->data['hciagent']) > 1) {
                    $conditions += array('user_id IN' => $this->request->data['hciagent']);
                }
            }

            $orderLookup = $this->Orders->find('all', ['conditions' => $conditions, 'order' => ['order_number' => 'asc']])->toArray();

            foreach ($orderLookup as $orderRow) {

                $quoteItemsLoop = $this->QuoteLineItems->find('all', ['conditions' => ['quote_id' => $orderRow['quote_id']], 'order' => ['line_number' => 'asc']])->toArray();

                $quoteData = $this->Quotes->get($orderRow['quote_id'])->toArray();

                $customer = $this->Customers->get($orderRow['customer_id'])->toArray();
                $thisCustomer = $this->Customers->get($orderRow['customer_id'])->toArray();

                foreach ($quoteItemsLoop as $quoteItem) {

                    $thisClass = $this->ProductClasses->get($quoteItem['product_class'])->toArray();
                    $classValue = $thisClass['class_name'];


                    $thisSubclass = $this->ProductSubclasses->get($quoteItem['product_subclass'])->toArray();
                    $subclassValue = $thisSubclass['subclass_name'];


                    if ($quoteItem['parent_line'] == 0) {

                        /* PPSASCRUM-326: start */
                        // $orderItemFind=$this->OrderItems->find('all',['conditions' => ['quote_line_item_id' => $quoteItem['id']]])->toArray();
                        // $orderItemFind = $this->OrderLineItems->find('all', ['conditions' => ['quote_line_item_id' => $quoteItem['id']]])->toArray();
                        $orderItemFind = $this->WorkOrderLineItems->find('all', ['conditions' => ['quote_line_item_id' => $quoteItem['id']]])->toArray(); //Used WOLI to fetch accurate data. work orders line items are created upon quote line item ids, hence there will be change if fetched from orders and work_orders.
                        
                        /* PPSASCRUM-326: end */
                        foreach ($orderItemFind as $orderItem) {

                            /* PPSASCRUM-326: start */
                            //look for BATCHES, if found, loop through those, then loop through the remainders or unbatched items
                            // $batchesScheduled=$this->OrderItemStatus->find('all',['conditions' => ['order_item_id' => $orderItem['id'], 'status IN' => ['Scheduled','Completed','Invoiced','Shipped']]])->toArray();
                            $batchesScheduled = $this->WorkOrderItemStatus->find('all', ['conditions' => ['work_order_id' => $orderItem['order_id'], 'order_line_number' => $orderItem['line_number'], 'status IN' => ['Scheduled', 'Completed', 'Invoiced', 'Shipped']]])->toArray();
                            /* PPSASCRUM-326: end */
                            $qtyShipped = 0;
                            $qtyInvoiced = 0;
                            $qtyCompleted = 0;
                            $qtyScheduled = 0;

                            $loop = array(
                                'batches' => array(),
                                'unbatched' => 0
                            );

                            $scheduledBatchesThisLine = 0;

                            foreach ($batchesScheduled as $batchData) {
                                switch ($batchData['status']) {
                                    case 'Shipped':
                                        $qtyShipped = ($qtyShipped + intval($batchData['qty_involved']));
                                        break;
                                    case 'Invoiced':
                                        $qtyInvoiced = ($qtyInvoiced + intval($batchData['qty_involved']));
                                        break;
                                    case 'Scheduled':
                                        $qtyScheduled = ($qtyScheduled + intval($batchData['qty_involved']));
                                        $loop['batches'][] = array('batchid' => $batchData['sherry_batch_id'], 'qty' => $batchData['qty_involved'], 'scheduledTS' => $batchData['time']);
                                        $scheduledBatchesThisLine++;
                                        break;
                                    case 'Completed':
                                        $qtyCompleted = ($qtyCompleted + intval($batchData['qty_involved']));
                                        break;
                                }
                            }

                            //loop back through again to add Shipped or Invoiced timestamps to batches that have them
                            foreach ($batchesScheduled as $batchData) {
                                switch ($batchData['status']) {
                                    case 'Shipped':
                                        foreach ($loop['batches'] as $num => $batchloopitem) {
                                            if ($batchloopitem['batchid'] == $batchData['sherry_batch_id']) {
                                                $loop['batches'][$num]['shippedTS'] = $batchData['time'];
                                            }
                                        }
                                        break;
                                    case 'Invoiced':
                                        foreach ($loop['batches'] as $num => $batchloopitem) {
                                            if ($batchloopitem['batchid'] == $batchData['sherry_batch_id']) {
                                                $loop['batches'][$num]['invoicedTS'] = $batchData['time'];
                                            }
                                        }
                                        break;
                                }
                            }

                            $remainingUnscheduled = (intval($quoteItem['qty']) - $qtyScheduled);
                            $remainingUninvoiced = (intval($quoteItem['qty']) - $qtyInvoiced);
                            $remainingUnshipped = (intval($quoteItem['qty']) - $qtyShipped);
                            $remainingIncompleteScheduled = (intval($quoteItem['qty']) - $qtyCompleted);

                            $loop['unbatched'] = $remainingUnscheduled;


                            $itemMetas = $this->QuoteLineItemMeta->find('all', ['conditions' => ['quote_item_id' => $quoteItem['id']]])->toArray();
                            $metaArray = array();
                            foreach ($itemMetas as $meta) {
                                $metaArray[$meta['meta_key']] = $meta['meta_value'];
                            }

                            if ($quoteItem['product_type'] != 'custom' && $quoteItem['product_type'] != 'services' && $quoteItem['product_type'] != 'track_systems') {


                                if ($metaArray['fabrictype'] != 'none' && $metaArray['fabrictype'] != 'typein') {

                                    if (isset($metaArray['fabricid']) && strlen(trim($metaArray['fabricid'])) > 0 && $metaArray['fabricid'] != '0') {
                                        $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                    } else {
                                        $thisFabric = array('fabric_name' => '', 'color' => '');
                                    }

                                    //$thisFabric=$this->Fabrics->get($metaArray['fabricid'])->toArray();
                                } elseif ($metaArray['fabrictype'] == 'typein') {
                                    $thisFabric = array('fabric_name' => $metaArray['fabric_name'], 'color' => $metaArray['fabric_color']);
                                } else {
                                    $thisFabric = array('fabric_name' => '', 'color' => '');
                                }
                            } else {
                                if ($metaArray['fabrictype'] != 'none' && $metaArray['fabrictype'] != 'typein') {
                                    if (isset($metaArray['fabricid']) && strlen(trim($metaArray['fabricid'])) > 0 && $metaArray['fabricid'] != '0') {
                                        $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                    } else {
                                        $thisFabric = array('fabric_name' => '', 'color' => '');
                                    }
                                } elseif ($metaArray['fabrictype'] == 'typein') {
                                    $thisFabric = array('fabric_name' => $metaArray['fabric_name'], 'color' => $metaArray['fabric_color']);
                                } else {
                                    $thisFabric = array('fabric_name' => '', 'color' => '');
                                }
                            }



                            $thisbookingdate = '';

                            //lookup the original Order Item Status for this line item and get the date value
                            /*$itemstatuslookup=$this->OrderItemStatus->find('all',['conditions' => ['order_item_id' => $orderItem['id'],'status' => 'Not Started']])->toArray();
    						foreach($itemstatuslookup as $itemstatusrow){
    							//$thisbookingdate=date('n/j/Y',$itemstatusrow['time']);
    						*/
                            $bookDateTimeObj = new \DateTime();

                            $bookDateTimeObj->setTimestamp($orderRow['created']);

                            $thisbookingdate = \PHPExcel_Shared_Date::PHPToExcel($bookDateTimeObj);
                            //}


                            $customerValue = $thisCustomer['company_name'];
                            $customerPOValue = $orderRow['po_number'];
                            $facilityValue = $orderRow['facility'];


                            $quoteNumberValue = '';
                            if ($quoteData['revision'] > 0) {
                                $quoteNumberValue = $quoteData['quote_number'] . "\n[REV " . $quoteData['revision'] . "]";
                            } else {
                                $quoteNumberValue = $quoteData['quote_number'];
                            }



                            if ($orderRow['due'] < 1000) {
                                $shipDateValue = '';
                            } else {
                                //$shipDateValue=date('n/d/Y',$orderRow['due']);
                                $dueDateTimeObj = new \DateTime();
                                $dueDateTimeObj->setTimestamp($orderRow['due']);
                                $shipDateValue = \PHPExcel_Shared_Date::PHPToExcel($dueDateTimeObj);
                            }

                            $lineNumberValue = $quoteItem['line_number'];
                            $locationValue = $quoteItem['room_number'];
                            $unitValue = $quoteItem['unit'];
                            $itemDescription = '';

                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

                            if ($metaArray['lineitemtype'] == 'calculator') {
                                if ($metaArray['calculator-used'] == "straight-cornice") {
                                    $itemDescription .= $metaArray['cornice-type'] . " Cornice";
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                    $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];
                                    $welts = '';
                                    if ($metaArray['welt-top'] == '1' && $metaArray['welt-bottom'] == '1') {
                                        $welts = "Top + Bottom";
                                    } else {
                                        if ($metaArray['welt-top'] == '1') {
                                            $welts = "Top Only";
                                        } elseif ($metaArray['welt-bottom'] == '1') {
                                            $welts = "Bottom Only";
                                        }
                                    }
                                    if ($welts != '') {
                                        $itemDescription .= "<br><b>Welts:</b> " . $welts;
                                    } else {
                                        $itemDescription .= "<br><b>Welts:</b> None";
                                    }
                                    if ($metaArray['individual-nailheads'] == '1') {
                                        $itemDescription .= "<br>Individual Nailheads";
                                    }
                                    if ($metaArray['nailhead-trim'] == '1') {
                                        $itemDescription .= "<br>Nailhead Trim";
                                    }
                                    if ($metaArray['covered-buttons'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['covered-buttons-count'] . " Covered Buttons";
                                    }

                                    if ($metaArray['horizontal-straight-banding'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['horizontal-straight-banding-count'] . " H Straight Banding";
                                    }
                                    if ($metaArray['horizontal-shaped-banding'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['horizontal-shaped-banding-count'] . " H Shaped Banding";
                                    }
                                    if ($metaArray['extra-welts'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['extra-welts-count'] . " Extra Welts";
                                    }
                                    if ($metaArray['trim-sewn-on'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['trim-lf'] . " LF Sewn-On Trim";
                                    }
                                    if ($metaArray['tassels'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['tassels-count'] . " Tassels";
                                    }
                                    if ($metaArray['drill-holes'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['drill-hole-count'] . " Drill Holes";
                                    }
                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "bedspread" || $metaArray['calculator-used'] == "bedspread-manual") {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Up-the-Roll";
                                    }

                                    $itemDescription .= "<br>";
                                    if (isset($metaArray['style']) && strlen(trim($metaArray['style'])) > 0) {
                                        $itemDescription .= "Style: " . $metaArray['style'];
                                    }
                                    if (isset($metaArray['quilted']) && $metaArray['quilted'] == '1') {
                                        $itemDescription .= "<br>Quilted";
                                        if (isset($metaArray['quilting-pattern']) && strlen(trim($metaArray['quilting-pattern'])) > 0) {
                                            $itemDescription .= ", " . $metaArray['quilting-pattern'];
                                        }
                                        if (isset($metaArray['matching-thread']) && $metaArray['matching-thread'] == '1') {
                                            $itemDescription .= ", Matching Thread";
                                        }
                                        $itemDescription .= ", " . $thisFabric['bs_backing_material'] . " Backing";
                                    } else {
                                        $itemDescription .= "<br>Unquilted";
                                    }

                                    $itemDescription .= "<br>Mattress: ";
                                    if (!isset($metaArray['custom-top-width-mattress-w'])) {
                                        $itemDescription .= "36&quot;";
                                    } else {
                                        $itemDescription .= $metaArray['custom-top-width-mattress-w'] . "&quot;";
                                    }

                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "box-pleated") {
                                    $itemDescription .= $metaArray['valance-type'] . " Valance";

                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    $itemDescription .= "<br>" . $metaArray['pleats'] . " Pleats";

                                    $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                    $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];

                                    if ($metaArray['straight-banding'] == 1) {
                                        $itemDescription .= "<br>Straight Banding";
                                    }
                                    if ($metaArray['shaped-banding'] == 1) {
                                        $itemDescription .= "<Br>Shaped Banding";
                                    }
                                    if ($metaArray['trim-sewn-on'] == 1) {
                                        $itemDescription .= "<br>Sewn-On Trim";
                                    }
                                    if ($metaArray['welt-covered-in-fabric'] == 1) {
                                        $itemDescription .= "<br>Welt Covered In Fabric";
                                    }
                                    if ($metaArray['contrast-fabric-inside-pleat'] == 1) {
                                        $itemDescription .= "<br>Contrast Fabric Inside Pleat";
                                    }
                                    if (isset($metaArray['vert-repeat']) && floatval($metaArray['vert-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vert-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "cubicle-curtain") {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    if ($metaArray['mesh'] > 0 && $metaArray['mesh'] != '') {
                                        $itemDescription .= "<br><b>Mesh:</b> " . $metaArray['mesh'] . "&quot; " . $metaArray['mesh-color'] . " (" . str_replace(" Mesh", "", $metaArray['mesh-type']) . ")";
                                    }
                                    if ($metaArray['mesh-type'] == 'None') {
                                        $itemDescription .= "<br>NO MESH";
                                    }
                                    if ($metaArray['mesh-type'] == 'Integral Mesh') {
 olor:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['trklf'] > 0 ? $dayTotals['trklf'] : '')."</td>";
			}

			if($bedspreads == 1){
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['bs'] > 0 ? $dayTotals['bs'] : '')."</td>";
				//$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">&nbsp;</td>";
			}

			if($draperies == 1){
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['drape'] > 0 ? $dayTotals['drape'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['drape_widths'] > 0 ? $dayTotals['drape_widths'] : '')."</td>";
				//$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">&nbsp;</td>";
			}

			if($toptreatments == 1){
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['val'] > 0 ? $dayTotals['val'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['vallf'] > 0 ? $dayTotals['vallf'] : '')."</td>";
				//$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">&nbsp;</td>";
			}

            if($toptreatments == 1){
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['corn'] > 0 ? $dayTotals['corn'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['cornlf'] > 0 ? $dayTotals['cornlf'] : '')."</td>";
				//$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">&nbsp;</td>";
			}
			if($hardware == 1){
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['wthw'] > 0 ? $dayTotals['wthw'] : '')."</td>";
			}

			if($blinds == 1){
				$thisDayOutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center; font-weight:bold;\">".($dayTotals['blinds'] > 0 ? $dayTotals['blinds'] : '')."</td>";
			}

			$thisDayOutput .= "</tr>";
			
			$output .= $thisDayOutput.$thisRowOutput;
		}
		
			
		$totalsoutput = "<tr style=\"background-color:#000000;\">";
		$totalsoutput .= "<td colspan=\"8\">&nbsp;</td>";
		$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">\$".number_format($overallTotals['dollars'],2,'.',',')."</td>";

		if($cubicles == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['cc']."</td>";
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['cclf']."</td>";
			//$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".ceil(floatval($overallTotals['ccdiff']))."</td>";
		}

		if($tracks == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['trklf']."</td>";
		}

		if($bedspreads == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['bs']."</td>";
			//$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">&nbsp;</td>";
		}

		if($draperies == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['drape']."</td>";
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['drape_widths']."</td>";
		//	$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">&nbsp;</td>";
		}

		if($toptreatments == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['val']."</td>";
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['vallf']."</td>";
		//	$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">&nbsp;</td>";
		}
		if($toptreatments == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['corn']."</td>";
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['cornlf']."</td>";
		//	$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">&nbsp;</td>";
		}

		if($hardware == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['wthw']."</td>";
		}

		if($blinds == 1){
			$totalsoutput .= "<td style=\"font-size:5px; color:#FFFFFF; text-align:center;\">".$overallTotals['blinds']."</td>";
		}

		$totalsoutput .= "</tr>";
	
		
		$tableoutput='<table width="94%" cellpadding="2" cellspacing="0" border="1" bordercolor="#000000">
			<thead>
				<tr style="background-color:#000000;">';

					if($cubicles==0 && $tracks==0 && $bedspreads == 0 && $draperies == 0 && $toptreatments == 0 && $hardware == 0 && $blinds == 0){
						$tableoutput .= '<th class="wonumber" style="font-size:5px; text-align:center; color:#FFFFFF;">BATCH#</th>
						<th class="wonumber" style="font-size:5px; text-align:center; color:#FFFFFF;">WO#</th>
						<th class="customer" style="font-size:5px; text-align:center; color:#FFFFFF;">Customer</th>
						<th class="ponumber" style="font-size:5px; text-align:center; color:#FFFFFF;">PO#</th>
						<th class="wodate" style="font-size:5px; text-align:center; color:#FFFFFF;">Date</th>
						<th class="project" style="font-size:5px; text-align:center; color:#FFFFFF;">Project</th>
						<th class="facility" style="font-size:5px; text-align:center; color:#FFFFFF;">Facility</th>
						<th class="woshipdate" style="font-size:5px; text-align:center; color:#FFFFFF;">WO Ship Date</th>
						<th class="totals" style="font-size:5px; text-align:center; color:#FFFFFF;">Totals</th>
						</tr>';
					}else{
						$tableoutput .= '<th class="wonumber" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">BATCH#</th>
						<th class="wonumber" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">WO#</th>
						<th class="customer" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">Customer</th>
						<th class="ponumber" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">PO#</th>
						<th class="wodate" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">Date</th>
						<th class="project" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">Project</th>
						<th class="facility" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">Facility</th>
						<th class="woshipdate" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">WO Ship Date</th>
						<th class="totals" rowspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">Totals</th>';
					
						if($cubicles == 1){
							$tableoutput .= '<th class="cubicles" colspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">CC</th>';
						}

						if($tracks == 1){
							$tableoutput .= '<th class="trk" style="font-size:5px; text-align:center; color:#FFFFFF;">TRK</th>';
						}
						
						if($bedspreads == 1){
							$tableoutput .= '<th class="bedspreads" colspan="1" style="font-size:5px; text-align:center; color:#FFFFFF;">BS</th>';
						}

						if($draperies == 1){
							$tableoutput .= '<th class="draperies" colspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">DRAPERIES</th>';
						}

						if($toptreatments == 1){
							$tableoutput .= '<th class="toptreatments" colspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">Valances</th>';
						}
						if($toptreatments == 1){
							$tableoutput .= '<th class="toptreatments" colspan="2" style="font-size:5px; text-align:center; color:#FFFFFF;">Cornices</th>';
						}
						
						if($hardware == 1){
							$tableoutput .= '<th class="wthw" style="font-size:5px; text-align:center; color:#FFFFFF;">WT HW</th>';
						}

						if($blinds == 1){
							$tableoutput .= '<th class="blinds" style="font-size:5px; text-align:center; color:#FFFFFF;">B&amp;S</th>';
						}

					$tableoutput .= '</tr>
					<tr style="background-color:#000000;">';
					if($cubicles == 1){
						$tableoutput .= '<th class="ccqty" style="font-size:5px; text-align:center; color:#FFFFFF;">QTY</th>';
						$tableoutput .= '<th class="cclf" style="font-size:5px; text-align:center; color:#FFFFFF;">LF</th>';
						//$tableoutput .= '<th class="ccdiff" style="font-size:5px; text-align:center; color:#FFFFFF;">DIFF</th>';
					}

					if($tracks == 1){
						$tableoutput .= '<th class="trklf" style="font-size:5px; text-align:center; color:#FFFFFF;">LF</th>';
					}

					if($bedspreads == 1){
						$tableoutput .= '<th class="bsqty" style="font-size:5px; text-align:center; color:#FFFFFF;">QTY</th>';
						//$tableoutput .= '<th class="bsdiff" style="font-size:5px; text-align:center; color:#FFFFFF;">DIFF</th>';
					}

					if($draperies == 1){
						$tableoutput .= '<th class="drapeqty" style="font-size:5px; text-align:center; color:#FFFFFF;">QTY</th>';
						$tableoutput .= '<th class="drapewidths" style="font-size:5px; text-align:center; color:#FFFFFF;">WIDTHS</th>';
					//	$tableoutput .= '<th class="drapediff" style="font-size:5px; text-align:center; color:#FFFFFF;">DIFF</th>';
					}

					if($toptreatments == 1){
						$tableoutput .= '<th class="topqty" style="font-size:5px; text-align:center; color:#FFFFFF;">QTY</th>';
						$tableoutput .= '<th class="toplf" style="font-size:5px; text-align:center; color:#FFFFFF;">LF</th>';
					//	$tableoutput .= '<th class="topdiff" style="font-size:5px; text-align:center; color:#FFFFFF;">DIFF</th>';
					}
					if($toptreatments == 1){
						$tableoutput .= '<th class="topqty" style="font-size:5px; text-align:center; color:#FFFFFF;">QTY</th>';
						$tableoutput .= '<th class="toplf" style="font-size:5px; text-align:center; color:#FFFFFF;">LF</th>';
					//	$tableoutput .= '<th class="topdiff" style="font-size:5px; text-align:center; color:#FFFFFF;">DIFF</th>';
					}

					if($hardware == 1){
						$tableoutput .= '<th class="wthwqty" style="font-size:5px; text-align:center; color:#FFFFFF;">QTY</th>';
					}

					if($blinds == 1){
						$tableoutput .= '<th class="blindqty" style="font-size:5px; text-align:center; color:#FFFFFF;">QTY</th>';
					}
					$tableoutput .= '</tr>';
				}
			$tableoutput .= '</thead>
			<tbody>
			'.$output.'
			</tbody>
			<tfoot>
			'.$totalsoutput.'
			</tfoot>
			</table>';

			//echo $tableoutput;exit;

			$this->set('htmloutput',$tableoutput);

			$this->viewBuilder()->options([
                'pdfConfig' => [
                    'orientation' => 'landscape',
                    'filename' => 'Sherry Schedule '.$startDate.'-'.$endDate.'.pdf',
					'title' => 'Sherry Schedule '.$startDate.'-'.$endDate
                ]
            ]);

			
		

	}


	public function ordercsv($orderID){
		$this->autoRender=false;
		$thisOrder=$this->Orders->get($orderID)->toArray();
		$thisCustomer=$this->Customers->get($thisOrder['customer_id'])->toArray();

		if($thisOrder['contact_id'] == 0){
			$thisContact=array('first_name'=>'','last_name'=>'');
		}else{
			$thisContact=$this->CustomerContacts->get($thisOrder['contact_id'])->toArray();
		}

		$list = array (
			0 => array(
				'Order Number',
				'PO Number',
				'Order Date',
				'Due Date',
				'Customer Name',
				'Contact',
				'Billing Address',
				'Billing City',
				'Billing State',
				'Billing Zipcode',
				'Quantity',
				'Item',
				'Description',
				'Price Each',
				'Extended Price',
				'Shipping Address Line 1',
				'Shipping Address Line 2',
				'Shipping City',
				'Shipping State',
				'Shipping Zipcode'
			)
		);
		

		$orderItems=$this->OrderItems->find('all',['conditions' => ['order_id' => $orderID]])->toArray();

		$quoteItems=$this->QuoteLineItems->find('all',['conditions' => ['quote_id' => $thisOrder['quote_id']], 'order' => ['sortorder'=>'asc']])->toArray();

		foreach($quoteItems as $item){
			$thisitemmeta=array();
			
			$allmeta=$this->QuoteLineItemMeta->find('all',['conditions'=>['quote_item_id' => $item['id']]])->toArray();
			foreach($allmeta as $metarow){
				$thisitemmeta[$metarow['meta_key']]=$metarow['meta_value'];
			}


			if($fabricAlias=$this->getFabricAlias($thisitemmeta['fabricid'],$thisOrder['customer_id'])){
				$fabricName=$fabricAlias['fabric_name'];
				$fabricColor=$fabricAlias['color'];
			}else{
				$thisFabric=$this->Fabrics->get($thisitemmeta['fabricid'])->toArray();
				$fabricName=$thisFabric['fabric_name'];
				$fabricColor=$thisFabric['color'];
			}

			switch($item['product_type']){
				case "bedspreads":
					$thisitem='Bedspread';
					$thisdescription='';
				break;
				case "calculator":
					switch($item['calculator_used']){
						case "bedspread":
						case "bedspread-manual":
							$thisitem="Bedspread";
							$thisdescription=$fabricName." ".$fabricColor." ".$thisitemmeta['width']."x".$thisitemmeta['length'];
						break;
						case "box-pleated":
							$thisitem=$thisitemmeta['valance-type']." Valance";
							$thisdescription=$fabricName." ".$fabricColor." ".$thisitemmeta['width']."x".$thisitemmeta['length'];
						break;
						case "cubicle-curtain":
							$thisitem="Cubicle Curtain";
							$thisdescription=$fabricName." ".$fabricColor." ".$thisitemmeta['width']."x".$thisitemmeta['length'];
						break;
						case "pinch-pleated":
					    /* PPSASCRUM-56: start */
						case 'new-pinch-pleated':
						/* PPSASCRUM-56: end */
							$thisitem="Pinch Pleated Drapery";
							$thisdescription=$fabricName." ".$fabricColor." ".$thisitemmeta['width']."x".$thisitemmeta['length'];
						break;
						case "straight-cornice":
							$thisitem=$thisitemmeta['cornice-type']." Cornice";
							$thisdescription=$fabricName." ".$fabricColor." ".$thisitemmeta['width']."x".$thisitemmeta['length'];
						break;
					}
				break;
				case "cubicle_curtains":
					$thisitem="Cubicle Curtain";
					$thisdescription=$fabricName." ".$fabricColor." ".$thisitemmeta['width']."x".$thisitemmeta['length'];
				break;
				case "custom":
					$thisitem=$item['title'];
					$thisdescription=$item['description'];
				break;
				case "window_treatments":
					$thisitem=$thisitemmeta['wttype'];
					$thisdescription=$fabricName." ".$fabricColor." ".$thisitemmeta['width']."x".$thisitemmeta['length'];;
				break;
				case "track_systems":
					$thisitem='TRACK';
					$thisdescription='';
				break;
				case "services":
					$thisitem=$item['title'];
					$thisdescription='';
				break;
			}

			$list[]=array(
				$thisOrder['order_number'],
				$thisOrder['po_number'],
				date('m/d/Y',$thisOrder['created']),
				date('m/d/Y',$thisOrder['due']),
				$thisCustomer['company_name'],
				$thisContact['first_name'].' '.$thisContact['last_name'],
				$thisCustomer['billing_address'],
				$thisCustomer['billing_address_city'],
				$thisCustomer['billing_address_state'],
				$thisCustomer['billing_address_zipcode'],
				$item['qty'],
				$thisitem,
				$thisdescription,
				$item['pmi_adjusted'],
				$item['extended_price'],
				$thisOrder['shipping_address_1'],
				$thisOrder['shipping_address_2'],
				$thisOrder['shipping_city'],
				$thisOrder['shipping_state'],
				$thisOrder['shipping_zipcode']
			);

		}
		$orderNum=$thisOrder['order_number'];

		$fp = fopen($_SERVER['DOCUMENT_ROOT'].'/tmp/Order '.$orderNum.'.csv', 'w');

		foreach ($list as $fields) {
		    fputcsv($fp, $fields);
		}

		fclose($fp);

		
		header('Content-Description: File Transfer');
		header('Content-Type: application/force-download');
		header('Content-Disposition: attachment; filename="Order '.$orderNum.'.csv"');
		readfile($_SERVER['DOCUMENT_ROOT'].'/tmp/Order '.$orderNum.'.csv');
		unlink($_SERVER['DOCUMENT_ROOT'].'/tmp/Order '.$orderNum.'.csv');
	}


	public function schedulesummary($dateStart=false,$dateEnd=false){
		if(!$dateStart || !$dateEnd){
			//show date range form
			$this->autoRender=false;
			$this->render('schedulesummaryform');
		}else{

			$this->viewBuilder()->options([

                'pdfConfig' => [
                	'pageSize' => 'LETTER',
                    'orientation' => 'landscape',
                    'filename' => 'Schedule Summary ' . $dateStart.' through '.$dateEnd.'.pdf',
					'title' => 'Schedule Summary ' . $dateStart.' through '.$dateEnd
                ]

            ]);

			$GLOBALS['pdfmargins']='custom';

			$GLOBALS['pdfmarginscustom']=array('left'=>10,'top'=>10,'right'=>10,'header'=>10);

			$GLOBALS['pdfheader']="<h3>Sherry Schedule <u>".$dateStart." through ".$dateEnd."</u><br>Summary</h3>";

			//render it (PDF)
			$this->set('dateStart',$dateStart);
			$this->set('dateEnd',$dateEnd);

			$output='';
		
			$startTS=strtotime($dateStart,' 00:00:00');
			$endTS = strtotime($dateEnd.' 23:59:59');
			
			$overallTotals=array(
				'dollars' => 0,
				'cc' => 0,
				'cclf' => 0,
				'ccdiff' => 0,
				'bs' => 0,
				'bsdiff' => 0,
				//'wt' => 0,
				//'wtlf' => 0,
				'val' => 0,
				'vallf' => 0,
				'corn' => 0,
				'cornlf' => 0,
				'drape' => 0,
				'drape_widths' => 0,
				'wthw' => 0,
				'blinds' => 0,
				'trklf' => 0,
				'drapediff' => 0,
				'wtdiff' => 0,
				'total_items' => 0
			);
			
			$days = ceil((($endTS-$startTS)/86400));
			
			for($i = 1; $i <= $days; $i++){
				
				$thisDayTS=($startTS + (($i-1) * 86400));
				$thisDayDate = date('Y-m-d',$thisDayTS);
				
				$dayTotals=array(
					'dollars' => 0,
					'cc' => 0,
					'cclf' => 0,
					'ccdiff' => 0,
					'bs' => 0,
					'bsdiff' => 0,
					//'wt' => 0,
					//'wtlf' => 0,
					'val' => 0,
					'vallf' => 0,
					'corn' => 0,
					'cornlf' => 0,
					'drape' => 0,
					'drape_widths' => 0,
					'wthw' => 0,
					'blinds' => 0,
					'trklf' => 0,
					'drapediff' => 0,
					'wtdiff' => 0,
					'total_items' => 0
				);
				
				$conditions=['date' => $thisDayDate];
				//print_r($conditions);
				$thisRowOutput='';
				$thisDayOutput='';
				
				$scheduleEntries=$this->SherryCache->find('all',['conditions' => $conditions])->toArray();
				//print_r($scheduleEntries);exit;
				
				foreach($scheduleEntries as $scheduleItem){
					
					foreach($dayTotals as $key => $val){
						$dayTotals[$key] = ($dayTotals[$key] + floatval($scheduleItem[$key]));
					}
					
					foreach($overallTotals as $key => $val){
						$overallTotals[$key] = ($overallTotals[$key] + floatval($scheduleItem[$key]));
					}
				
					
				}
				
				
				$thisDayOutput = "<tr class=\"daterow\">";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:left; color:#000;\">".date("n/j/Y",$thisDayTS)."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">\$".number_format($dayTotals['dollars'],2,'.',',')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['cc'] > 0 ? $dayTotals['cc'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['cclf'] > 0 ? $dayTotals['cclf'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['trklf'] > 0 ? $dayTotals['trklf'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['bs'] > 0 ? $dayTotals['bs'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['drape'] > 0 ? $dayTotals['drape'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['drape_widths'] > 0 ? $dayTotals['drape_widths'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['val'] > 0 ? $dayTotals['val'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['vallf'] > 0 ? $dayTotals['vallf'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['corn'] > 0 ? $dayTotals['corn'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['cornlf'] > 0 ? $dayTotals['cornlf'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['wthw'] > 0 ? $dayTotals['wthw'] : '')."</td>";
				$thisDayOutput .= "<td style=\"font-size:7px; text-align:center; color:#000;\">".($dayTotals['blinds'] > 0 ? $dayTotals['blinds'] : '')."</td>";
				$thisDayOutput .= "</tr>";
				
				$output .= $thisDayOutput.$thisRowOutput;
			}
			
				
			$totalsoutput = "<tr bgcolor=\"#555555\">";
			$totalsoutput .= "<td style=\"font-size:7px; color:#FFF; font-weight:bold;\">TOTALS:</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">\$".number_format($overallTotals['dollars'],2,'.',',')."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['cc']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['cclf']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['trklf']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['bs']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['drape']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['drape_widths']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['val']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['vallf']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['corn']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['cornlf']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['wthw']."</td>";
			$totalsoutput .= "<td style=\"font-size:7px; text-align:center; color:#FFF; font-weight:bold;\">".$overallTotals['blinds']."</td>";
			$totalsoutput .= "</tr>";
	
		
		
			$this->set('rawoutput','<table id="sherrytable" cellpadding="3" cellspacing="0" border="1" bordercolor="#000000">
			<thead>
				<tr bgcolor="#555555">
					<th class="date" rowspan="2" style="font-size:7px; text-align:center; color:#FFF; font-weight:bold;">Date</th>
					<th class="dollars" rowspan="2" style="font-size:7px; text-align:center; color:#FFF; font-weight:bold;">Dollars</th>
					<th class="cubicles" colspan="2" style="font-size:7px; text-align:center; color:#FFF; font-weight:bold;">CC</th>
					<th class="trk" style="font-size:7px; text-align:center; color:#FFF; font-weight:bold;">TRK</th>
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         $on_credit_hold = ($thisCustomer['on_credit_hold']) ? '<div><span style="color: red;"> On Credit            $allusers = $this->Users->find('all', ['order' => ['last_name' => 'asc', 'first_name' => 'asc']])->toArray();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            �   �   �   �   d                               	   �   �   e               r   �   �   �   P      &   i   �   �   �                      !   �   �   �   �                   �   �   �   �   >                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               }   �   �   �                                  	   �   �   e                   �   �   �   �   �   �   �   �   �   9                           �   �   �   j                   O   �   �   �                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ,   �   �   �                                      �   �   b                      r   �   �   �   �   �   �   $                               �   �   �   +                      �   �   �                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 +                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ��0�   ��0�  �	      
     ��             �	     <?php

/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */

namespace App\Controller;

use Cake\Datasource\ConnectionManager;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Utility\Security;
use Cake\Core\Configure;
use Cake\ORM\TableRegistry;
use Cake\Mailer\Email;
use Cake\ORM\Table;
use Cake\Datasource\Exception\RecordNotFoundException;


/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link http://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */
class ReportsController extends AppController
{



    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Security');
        $this->loadModel('UserTypes');
        $this->loadModel('Users');
        $this->loadModel('Customers');
        $this->loadModel('CustomerContacts');
        $this->loadModel('Products');
        $this->loadModel('Quotes');
        $this->loadModel('QuoteLineItems');
        $this->loadModel('QuoteLineItemMeta');
        $this->loadModel('Orders');
        $this->loadModel('OrderItems');
        $this->loadModel('OrderItemStatus');
        $this->loadModel('Calculators');
        $this->loadModel('Vendors');
        $this->loadModel('Shipments');
        $this->loadModel('SherryCache');
        $this->loadModel('SherryBatches');
        $this->loadModel('Fabrics');
        $this->loadModel('Linings');
        $this->loadModel('FabricMarkupRules');
        $this->loadModel('Assemblies');
        $this->loadModel('Bedspreads');
        $this->loadModel('BedspreadSizes');
        $this->loadModel('BsDataMap');
        $this->loadModel('CubicleCurtains');
        $this->loadModel('CubicleCurtainSizes');
        $this->loadModel('MiscellaneousProducts');
        $this->loadModel('Services');
        $this->loadModel('TrackSystems');
        $this->loadModel('WindowTreatments');
        $this->loadModel('QuoteNotes');
        $this->loadModel('QuoteDiscounts');
        $this->loadModel('QuoteLineItemNotes');
        $this->loadModel('LibraryImages');
        $this->loadModel('LibraryCategories');
        $this->loadModel('CcDataMap');
        $this->loadModel('WtDataMap');
        $this->loadModel('WindowTreatmentSizes');
        $this->loadModel('QuoteBomRequirements');
        $this->loadModel('MaterialPurchases');
        $this->loadModel('MaterialInventory');
        $this->loadModel('MaterialUsages');
        $this->loadModel('Projects');
        $this->loadModel('ShippingMethods');
        $this->loadModel('Msr');
        $this->loadModel('QuoteTypes');
        $this->loadModel('ProductClasses');
        $this->loadModel('ProductSubclasses');
        $this->loadModel('OrderLineItems');

        /** PPSASCRUM-62 start **/
        $this->loadModel('ShipTo');
        $this->loadModel('Facility');
        /** PPSASCRUM-62 end **/
    }


    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        /**PPSA-40 start **/
        if ($this->request->action == 'msr' || $this->request->action == 'bulkeditmsr' || $this->request->action == 'productiondetailbacklog' || $this->request->action == 'backlogreport' || $this->request->action == 'bookingreport' || $this->request->action == 'backlogsummary' || $this->request->action == 'getmsrlist' || $this->request->action == 'consolidatedquotes' || $this->request->action == 'consolidateddraftquotes' || $this->request->action == 'bigquotes' || $this->request->action == 'quotesnewlines') {

            $this->Security->config('unlockedActions', ['msr', 'getmsrlist', 'backlogreport', 'bookingreport', 'backlogsummary', 'productiondetailbacklog', 'bulkeditmsr', 'consolidatedquotes', 'consolidateddraftquotes', 'bigquotes', 'quotesnewlines']);
            $this->eventManager()->off($this->Csrf);
            $this->eventManager()->off($this->Security);
        }
        /**PPSA-40 end **/
    }


    public function index() {}

    public function productiondetailbacklog()
    {
        $productMap = array(
            'cubicle-curtain' => 'Cubicle Curtain',
            'box-pleated' => 'Box Pleated Valance',
            'straight-cornice' => 'Straight Cornice',
            'bedspread' => 'Calculated Bedspread',
            'bedspread-manual' => 'Manually Entered Bedspread',
            'pinch-pleated' => 'Pinch Pleated Drapery'
        );

        $allsettings = $this->getsettingsarray();

        if ($this->request->data) {
            $this->autoRender = false;

            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");

            $objPHPExcel = new \PHPExcel();
            $objPHPExcel->setActiveSheetIndex(0);


            $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'ORDER #');
            $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'QUOTE #');

            $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'STAGE');

            $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'PM');
            $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'CUSTOMER');
            $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'CUSTOMER PO');
            $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'RECIPIENT');
            $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'SHIP DATE');

            $objPHPExcel->getActiveSheet()->SetCellValue('I1', 'SCHEDULED'); //moved from AB

            $objPHPExcel->getActiveSheet()->SetCellValue('J1', 'BOOK DATE');
            $objPHPExcel->getActiveSheet()->SetCellValue('K1', 'BATCH');
            $objPHPExcel->getActiveSheet()->SetCellValue('L1', 'LINE');

            $objPHPExcel->getActiveSheet()->SetCellValue('M1', 'LOCATION');

            $objPHPExcel->getActiveSheet()->SetCellValue('N1', 'QTY');
            $objPHPExcel->getActiveSheet()->SetCellValue('O1', 'UNIT');
            $objPHPExcel->getActiveSheet()->SetCellValue('P1', 'LINE ITEM');
            $objPHPExcel->getActiveSheet()->SetCellValue('Q1', 'FABRIC');
            $objPHPExcel->getActiveSheet()->SetCellValue('R1', 'COLOR');

            $objPHPExcel->getActiveSheet()->SetCellValue('S1', 'CUT WIDTH');
            $objPHPExcel->getActiveSheet()->SetCellValue('T1', 'FIN WIDTH');

            $objPHPExcel->getActiveSheet()->SetCellValue('U1', 'LENGTH');

            $objPHPExcel->getActiveSheet()->SetCellValue('V1', 'TOTAL LF');
            $objPHPExcel->getActiveSheet()->SetCellValue('W1', 'YDS / UNIT');
            $objPHPExcel->getActiveSheet()->SetCellValue('X1', 'TOTAL YARDS');
            $objPHPExcel->getActiveSheet()->SetCellValue('Y1', 'BASE');
            $objPHPExcel->getActiveSheet()->SetCellValue('Z1', 'TIERS');
            $objPHPExcel->getActiveSheet()->SetCellValue('AA1', 'ADJ PRICE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AB1', 'EXT PRICE');



            $objPHPExcel->getActiveSheet()->SetCellValue('AC1', 'PRODUCED');
            $objPHPExcel->getActiveSheet()->SetCellValue('AD1', 'SHIPPED');

            $objPHPExcel->getActiveSheet()->SetCellValue('AE1', 'TRACKING #');

            $objPHPExcel->getActiveSheet()->SetCellValue('AF1', 'INVOICED');

            $objPHPExcel->getActiveSheet()->SetCellValue('AG1', 'LINE NOTES');

            $objPHPExcel->getActiveSheet()->SetCellValue('AH1', 'BS QUILT');
            $objPHPExcel->getActiveSheet()->SetCellValue('AI1', 'BS MAT SIZE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AJ1', 'BS DROP');
            $objPHPExcel->getActiveSheet()->SetCellValue('AK1', 'BS WIDTHS EA');
            $objPHPExcel->getActiveSheet()->SetCellValue('AL1', 'BS TOP WIDTHS EA');
            $objPHPExcel->getActiveSheet()->SetCellValue('AM1', 'BS TOP WIDTHS CL');
            $objPHPExcel->getActiveSheet()->SetCellValue('AN1', 'BS TOP CUT SIZE W');
            $objPHPExcel->getActiveSheet()->SetCellValue('AO1', 'BS TOP CUT SIZE L');
            $objPHPExcel->getActiveSheet()->SetCellValue('AP1', 'BS DROP CUT SIZE W');
            $objPHPExcel->getActiveSheet()->SetCellValue('AQ1', 'BS DROP CUT SIZE L');
            $objPHPExcel->getActiveSheet()->SetCellValue('AR1', 'CC MESH SIZE');
            $objPHPExcel->getActiveSheet()->SetCellValue('AS1', 'CC MESH COLOR');
            $objPHPExcel->getActiveSheet()->SetCellValue('AT1', 'CC WIDTHS EA');
            $objPHPExcel->getActiveSheet()->SetCellValue('AU1', 'CC CUT LENGTH');
            $objPHPExcel->getActiveSheet()->SetCellValue('AV1', 'CC ACTUAL LF');


            $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(40);
            $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(55);
            $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15); //SCHEDULED moved from AB

            $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(75);

            $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(20);

            $objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(30);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(15);


            $objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AD')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AE')->setWidth(29);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AF')->setWidth(15);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AG')->setWidth(70);

            $objPHPExcel->getActiveSheet()->getColumnDimension('AH')->setWidth(32);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AI')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AJ')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AK')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AL')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AM')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AN')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AO')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AP')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AQ')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AR')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AS')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AT')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AU')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('AV')->setWidth(16);


            $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(22);
            $objPHPExcel->getActiveSheet()->getStyle('A1:AV1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);

            $objPHPExcel->getActiveSheet()->getStyle('A1:AV1')->applyFromArray(
                array(
                    'fill' => array(
                        'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'F8CBAD')
                    )
                )
            );


            $rowCount = 2;

            $conditions = array();

            $conditions += array('status !=' => 'Canceled');

            if ((isset($this->request->data['datestart']) && strlen(trim($this->request->data['datestart'])) > 0) && (isset($this->request->data['dateend']) && strlen(trim($this->request->data['dateend'])) > 0)) {
                $conditions += array('created >=' => strtotime($this->request->data['datestart'] . ' 00:00:00'));
                $conditions += array('created <=' => strtotime($this->request->data['dateend'] . ' 23:59:59'));
            }

            if (isset($this->request->data['quotenumber']) && strlen(trim($this->request->data['quotenumber'])) > 0) {
            }

            if (isset($this->request->data['ordernumber']) && strlen(trim($this->request->data['ordernumber'])) > 0) {
            }

            if (isset($this->request->data['clientponumber']) && strlen(trim($this->request->data['clientponumber'])) > 0) {
            }


            if (isset($this->request->data['customer']) && count($this->request->data['customer']) > 0) {
                if (count($this->request->data['customer']) == 1) {
                    $conditions += array('customer_id' => $this->request->data['customer'][0]);
                } elseif (count($this->request->data['customer']) > 1) {
                    $conditions += array('customer_id IN' => $this->request->data['customer']);
                }
            }

            if (isset($this->request->data['hciagent']) && count($this->request->data['hciagent']) > 0) {
                if (count($this->request->data['hciagent']) == 1) {
                    $conditions += array('user_id' => $this->request->data['hciagent'][0]);
                } elseif (count($this->request->data['hciagent']) > 1) {
                    $conditions += array('user_id IN' => $this->request->data['hciagent']);
                }
            }

            $orderLookup = $this->Orders->find('all', ['conditions' => $conditions, 'order' => ['order_number' => 'asc']])->toArray();

            foreach ($orderLookup as $orderRow) {

                $quoteItemsLoop = $this->QuoteLineItems->find('all', ['conditions' => ['quote_id' => $orderRow['quote_id']], 'order' => ['line_number' => 'asc']])->toArray();

                $quoteData = $this->Quotes->get($orderRow['quote_id'])->toArray();

                $customer = $this->Customers->get($orderRow['customer_id'])->toArray();
                $thisCustomer = $this->Customers->get($orderRow['customer_id'])->toArray();

                foreach ($quoteItemsLoop as $quoteItem) {
                    if ($quoteItem['parent_line'] == 0) {

                        $orderItemFind = $this->OrderItems->find('all', ['conditions' => ['quote_line_item_id' => $quoteItem['id']]])->toArray();
                        foreach ($orderItemFind as $orderItem) {

                            //look for BATCHES, if found, loop through those, then loop through the remainders or unbatched items
                            $batchesScheduled = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status IN' => ['Scheduled', 'Completed', 'Invoiced', 'Shipped']]])->toArray();
                            $qtyShipped = 0;
                            $qtyInvoiced = 0;
                            $qtyCompleted = 0;
                            $qtyScheduled = 0;

                            $loop = array(
                                'batches' => array(),
                                'unbatched' => 0
                            );

                            $scheduledBatchesThisLine = 0;

                            foreach ($batchesScheduled as $batchData) {
                                switch ($batchData['status']) {
                                    case 'Shipped':
                                        $qtyShipped = ($qtyShipped + intval($batchData['qty_involved']));
                                        break;
                                    case 'Invoiced':
                                        $qtyInvoiced = ($qtyInvoiced + intval($batchData['qty_involved']));
                                        break;
                                    case 'Scheduled':
                                        $qtyScheduled = ($qtyScheduled + intval($batchData['qty_involved']));
                                        $loop['batches'][] = array('batchid' => $batchData['sherry_batch_id'], 'qty' => $batchData['qty_involved'], 'scheduledTS' => $batchData['time']);
                                        $scheduledBatchesThisLine++;
                                        break;
                                    case 'Completed':
                                        $qtyCompleted = ($qtyCompleted + intval($batchData['qty_involved']));
                                        break;
                                }
                            }

                            //loop back through again to add Shipped or Invoiced timestamps to batches that have them
                            foreach ($batchesScheduled as $batchData) {
                                switch ($batchData['status']) {
                                    case 'Shipped':
                                        foreach ($loop['batches'] as $num => $batchloopitem) {
                                            if ($batchloopitem['batchid'] == $batchData['sherry_batch_id']) {
                                                $loop['batches'][$num]['shippedTS'] = $batchData['time'];
                                            }
                                        }
                                        break;
                                    case 'Invoiced':
                                        foreach ($loop['batches'] as $num => $batchloopitem) {
                                            if ($batchloopitem['batchid'] == $batchData['sherry_batch_id']) {
                                                $loop['batches'][$num]['invoicedTS'] = $batchData['time'];
                                            }
                                        }
                                        break;
                                }
                            }

                            $remainingUnscheduled = (intval($quoteItem['qty']) - $qtyScheduled);
                            $remainingUninvoiced = (intval($quoteItem['qty']) - $qtyInvoiced);
                            $remainingUnshipped = (intval($quoteItem['qty']) - $qtyShipped);
                            $remainingIncompleteScheduled = (intval($quoteItem['qty']) - $qtyCompleted);

                            $loop['unbatched'] = $remainingUnscheduled;


                            $itemMetas = $this->QuoteLineItemMeta->find('all', ['conditions' => ['quote_item_id' => $quoteItem['id']]])->toArray();
                            $metaArray = array();
                            foreach ($itemMetas as $meta) {
                                $metaArray[$meta['meta_key']] = $meta['meta_value'];
                            }

                            if ($quoteItem['product_type'] != 'custom' && $quoteItem['product_type'] != 'services' && $quoteItem['product_type'] != 'track_systems') {


                                if ($metaArray['fabrictype'] != 'none' && $metaArray['fabrictype'] != 'typein') {

                                    if (isset($metaArray['fabricid']) && strlen(trim($metaArray['fabricid'])) > 0 && $metaArray['fabricid'] != '0') {
                                        $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                    } else {
                                        $thisFabric = array('fabric_name' => '', 'color' => '');
                                    }

                                    //$thisFabric=$this->Fabrics->get($metaArray['fabricid'])->toArray();
                                } elseif ($metaArray['fabrictype'] == 'typein') {
                                    $thisFabric = array('fabric_name' => $metaArray['fabric_name'], 'color' => $metaArray['fabric_color']);
                                } else {
                                    $thisFabric = array('fabric_name' => '', 'color' => '');
                                }
                            } else {
                                if ($metaArray['fabrictype'] != 'none' && $metaArray['fabrictype'] != 'typein') {
                                    if (isset($metaArray['fabricid']) && strlen(trim($metaArray['fabricid'])) > 0 && $metaArray['fabricid'] != '0') {
                                        $thisFabric = $this->Fabrics->get($metaArray['fabricid'])->toArray();
                                    } else {
                                        $thisFabric = array('fabric_name' => '', 'color' => '');
                                    }
                                } elseif ($metaArray['fabrictype'] == 'typein') {
                                    $thisFabric = array('fabric_name' => $metaArray['fabric_name'], 'color' => $metaArray['fabric_color']);
                                } else {
                                    $thisFabric = array('fabric_name' => '', 'color' => '');
                                }
                            }



                            $thisbookingdate = '';

                            //lookup the original Order Item Status for this line item and get the date value
                            $itemstatuslookup = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Not Started']])->toArray();
                            foreach ($itemstatuslookup as $itemstatusrow) {
                                //$thisbookingdate=date('n/j/Y',$itemstatusrow['time']);
                                $bookDateTimeObj = new \DateTime();
                                $bookDateTimeObj->setTimestamp($itemstatusrow['time']);

                                $thisbookingdate = \PHPExcel_Shared_Date::PHPToExcel($bookDateTimeObj);
                            }


                            $customerValue = $thisCustomer['company_name'];
                            $customerPOValue = $orderRow['po_number'];
                            $facilityValue = $orderRow['facility'];


                            $quoteNumberValue = '';
                            if ($quoteData['revision'] > 0) {
                                $quoteNumberValue = $quoteData['quote_number'] . "\n[REV " . $quoteData['revision'] . "]";
                            } else {
                                $quoteNumberValue = $quoteData['quote_number'];
                            }



                            if ($orderRow['due'] < 1000) {
                                $shipDateValue = '';
                            } else {
                                //$shipDateValue=date('n/d/Y',$orderRow['due']);
                                $dueDateTimeObj = new \DateTime();
                                $dueDateTimeObj->setTimestamp($orderRow['due']);
                                $shipDateValue = \PHPExcel_Shared_Date::PHPToExcel($dueDateTimeObj);
                            }

                            $lineNumberValue = $quoteItem['line_number'];
                            $locationValue = $quoteItem['room_number'];
                            $unitValue = $quoteItem['unit'];
                            $itemDescription = '';

                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

                            if ($metaArray['lineitemtype'] == 'calculator') {
                                if ($metaArray['calculator-used'] == "straight-cornice") {
                                    $itemDescription .= $metaArray['cornice-type'] . " Cornice";
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                    $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];
                                    $welts = '';
                                    if ($metaArray['welt-top'] == '1' && $metaArray['welt-bottom'] == '1') {
                                        $welts = "Top + Bottom";
                                    } else {
                                        if ($metaArray['welt-top'] == '1') {
                                            $welts = "Top Only";
                                        } elseif ($metaArray['welt-bottom'] == '1') {
                                            $welts = "Bottom Only";
                                        }
                                    }
                                    if ($welts != '') {
                                        $itemDescription .= "<br><b>Welts:</b> " . $welts;
                                    } else {
                                        $itemDescription .= "<br><b>Welts:</b> None";
                                    }
                                    if ($metaArray['individual-nailheads'] == '1') {
                                        $itemDescription .= "<br>Individual Nailheads";
                                    }
                                    if ($metaArray['nailhead-trim'] == '1') {
                                        $itemDescription .= "<br>Nailhead Trim";
                                    }
                                    if ($metaArray['covered-buttons'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['covered-buttons-count'] . " Covered Buttons";
                                    }

                                    if ($metaArray['horizontal-straight-banding'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['horizontal-straight-banding-count'] . " H Straight Banding";
                                    }
                                    if ($metaArray['horizontal-shaped-banding'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['horizontal-shaped-banding-count'] . " H Shaped Banding";
                                    }
                                    if ($metaArray['extra-welts'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['extra-welts-count'] . " Extra Welts";
                                    }
                                    if ($metaArray['trim-sewn-on'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['trim-lf'] . " LF Sewn-On Trim";
                                    }
                                    if ($metaArray['tassels'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['tassels-count'] . " Tassels";
                                    }
                                    if ($metaArray['drill-holes'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['drill-hole-count'] . " Drill Holes";
                                    }
                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "bedspread" || $metaArray['calculator-used'] == "bedspread-manual") {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Up-the-Roll";
                                    }

                                    $itemDescription .= "<br>";
                                    if (isset($metaArray['style']) && strlen(trim($metaArray['style'])) > 0) {
                                        $itemDescription .= "Style: " . $metaArray['style'];
                                    }
                                    if (isset($metaArray['quilted']) && $metaArray['quilted'] == '1') {
                                        $itemDescription .= "<br>Quilted";
                                        if (isset($metaArray['quilting-pattern']) && strlen(trim($metaArray['quilting-pattern'])) > 0) {
                                            $itemDescription .= ", " . $metaArray['quilting-pattern'];
                                        }
                                        if (isset($metaArray['matching-thread']) && $metaArray['matching-thread'] == '1') {
                                            $itemDescription .= ", Matching Thread";
                                        }
                                        $itemDescription .= ", " . $thisFabric['bs_backing_material'] . " Backing";
                                    } else {
                                        $itemDescription .= "<br>Unquilted";
                                    }

                                    $itemDescription .= "<br>Mattress: ";
                                    if (!isset($metaArray['custom-top-width-mattress-w'])) {
                                        $itemDescription .= "36&quot;";
                                    } else {
                                        $itemDescription .= $metaArray['custom-top-width-mattress-w'] . "&quot;";
                                    }

                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "box-pleated") {
                                    $itemDescription .= $metaArray['valance-type'] . " Valance";

                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    $itemDescription .= "<br>" . $metaArray['pleats'] . " Pleats";

                                    $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                    $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];

                                    if ($metaArray['straight-banding'] == 1) {
                                        $itemDescription .= "<br>Straight Banding";
                                    }
                                    if ($metaArray['shaped-banding'] == 1) {
                                        $itemDescription .= "<Br>Shaped Banding";
                                    }
                                    if ($metaArray['trim-sewn-on'] == 1) {
                                        $itemDescription .= "<br>Sewn-On Trim";
                                    }
                                    if ($metaArray['welt-covered-in-fabric'] == 1) {
                                        $itemDescription .= "<br>Welt Covered In Fabric";
                                    }
                                    if ($metaArray['contrast-fabric-inside-pleat'] == 1) {
                                        $itemDescription .= "<br>Contrast Fabric Inside Pleat";
                                    }
                                    if (isset($metaArray['vert-repeat']) && floatval($metaArray['vert-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vert-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == "cubicle-curtain") {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    if ($metaArray['mesh'] > 0 && $metaArray['mesh'] != '') {
                                        $itemDescription .= "<br><b>Mesh:</b> " . $metaArray['mesh'] . "&quot; " . $metaArray['mesh-color'] . " (" . str_replace(" Mesh", "", $metaArray['mesh-type']) . ")";
                                    }
                                    if ($metaArray['mesh-type'] == 'None') {
                                        $itemDescription .= "<br>NO MESH";
                                    }
                                    if ($metaArray['mesh-type'] == 'Integral Mesh') {
                                        $itemDescription .= "<br>INTEGRAL MESH";
                                    }
                                    if ($metaArray['liner'] == 1) {
                                        $itemDescription .= "<br>Liner";
                                    }
                                    if ($metaArray['nylon-mesh'] == 1) {
                                        $itemDescription .= "<br>Nylon Mesh";
                                    }
                                    if ($metaArray['angled-mesh'] == 1) {
                                        $itemDescription .= "<br>Angled Mesh";
                                    }
                                    if ($metaArray['mesh-frame'] != 'No Frame') {
                                        $itemDescription .= "<br><b>Mesh Frame:</b> " . $metaArray['mesh-frame'];
                                    }
                                    if ($metaArray['hidden-mesh'] == 1) {
                                        $itemDescription .= "<br>Hidden Mesh";
                                    }

                                    if ($metaArray['snap-tape'] != "None") {
                                        $itemDescription .= "<br>" . $metaArray['snap-tape'] . " Snap Tape (" . $metaArray['snaptape-lf'] . ")";
                                    }
                                    if ($metaArray['velcro'] != 'None') {
                                        $itemDescription .= "<br>" . $metaArray['velcro'] . " Velcro (" . $metaArray['velcro-lf'] . " LF)";
                                    }
                                    if ($metaArray['weights'] == 1) {
                                        $itemDescription .= "<br>" . $metaArray['weight-count'] . " Weights";
                                    }
                                    if ($metaArray['magnets'] == 1) {
                                        $itemDescription .= "<br>" . $metaArray['magnet-count'] . " Magnets";
                                    }
                                    if ($metaArray['banding'] == 1) {
                                        $itemDescription .= "<br>Banding";
                                    }
                                    if ($metaArray['buttonholes'] == 1) {
                                        $itemDescription .= "<br>" . $metaArray['buttonhole-count'] . " Buttonholes";
                                    }
                                    if (isset($metaArray['vertical-repeat']) && floatval($metaArray['vertical-repeat']) > 0) {
                                        $itemDescription .= "<br>Matched Repeat (" . $metaArray['vertical-repeat'] . "&quot;)";
                                    }
                                } elseif ($metaArray['calculator-used'] == 'pinch-pleated') {
                                    $itemDescription .= $productMap[$metaArray['calculator-used']];
                                    if ($metaArray['unit-of-measure'] == 'pair') {
                                        $itemDescription .= "<br>Pair";
                                    } elseif ($metaArray['unit-of-measure'] == 'panel') {
                                        $itemDescription .= "<br>" . $metaArray['panel-type'] . " Panel";
                                    }
                                    if ($metaArray['railroaded'] == '1') {
                                        $itemDescription .= "<br>Fabric Railroaded";
                                    } else {
                                        $itemDescription .= "<br>Fabric Vertically Seamed";
                                    }
                                    if (isset($metaArray['linings_id']) && floatval($metaArray['linings_id']) > 0) {
                                        $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                        $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];
                                    }
                                    $itemDescription .= "<br><b>Hardware:</b> " . ucfirst($metaArray['hardware']);
                                    if ($metaArray['trim-sewn-on'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['trim-lf'] . " LF Sewn-On Trim";
                                    }
                                    if ($metaArray['tassels'] == '1') {
                                        $itemDescription .= "<br>" . $metaArray['tassels-count'] . " Tassels";
                                    }
                                }
                            } elseif ($metaArray['lineitemtype'] == 'simpleproduct') {
                                switch ($quoteItem['product_type']) {
                                    case "cubicle_curtains":
                                        $itemDescription .= "Price List CC";
                                        if ($thisFabric['railroaded'] == '1') {
                                            $itemDescription .= "<br>Fabric Railroaded";
                                        } else {
                                            $itemDescription .= "<br>Fabric Vertically Seamed";
                                        }
                                        if ($metaArray['mesh'] > 0 && $metaArray['mesh'] != '') {
                                            $itemDescription .= "<br><b>Mesh:</b> " . $metaArray['mesh'] . "&quot; " . $metaArray['mesh-color'] . " (MOM)";
                                        }
                                        if ($metaArray['mesh'] == 'No Mesh' || $metaArray['mesh'] == '0') {
                                            $itemDescription .= "<br>NO MESH";
                                        }
                                        if (floatval($thisFabric['vertical_repeat']) > 0) {
                                            $itemDescription .= "<br>Matched Repeat (" . $thisFabric['vertical_repeat'] . "&quot;)";
                                        }
                                        break;
                                    case "bedspreads":
                                        $itemDescription .= "Price List BS";
                                        $thisBS = "";
                                        try {
                                            $thisBS = $this->Bedspreads->get($quoteItem['product_id'])->toArray();
                                        } catch (RecordNotFoundException $e) {
                                        }

                                        if ($thisFabric['railroaded'] == '1') {
                                            $itemDescription .= "<br>Fabric Railroaded";
                                        } else {
                                            $itemDescription .= "<br>Fabric Vertically Seamed";
                                        }
                                        $itemDescription .= "<br>Style: ";
                                        $styleval = explode(" (", $metaArray['style']);
                                        $itemDescription .= $styleval[0];
                                        if (!empty($thisBS) && $thisBS['quilted'] == '1') {
                                            $itemDescription .= "<br>Quilted, Double Onion, " . $thisFabric['bs_backing_material'] . " Backing";
                                        } else {
                                            $itemDescription .= "<br>Unquilted";
                                        }
                                        $itemDescription .= "<br>Mattress: ";
                                        if (!isset($metaArray['custom-top-width-mattress-w'])) {
                                            $itemDescription .= "36&quot;";
                                        } else {
                                            $itemDescription .= $metaArray['custom-top-width-mattress-w'] . "&quot;";
                                        }

                                        if (floatval($thisFabric['vertical_repeat']) > 0) {
                                            $itemDescription .= "<br>Matched Repeat (" . $thisFabric['vertical_repeat'] . "&quot;)";
                                        }
                                        break;
                                    case "services":
                                        $itemDescription .= $quoteItem['title'];
                                        break;
                                    case "window_treatments":
                                        if ($metaArray['wttype'] == 'Pinch Pleated Drapery') {
                                            $itemDescription .= "<b>" . ucfirst($metaArray['unit-of-measure']) . "</b><br>";
                                        }
                                        $itemDescription .= 'Price List ' . $metaArray['wttype'];
                                        if (preg_match("#Cornice#i", $metaArray['wttype']) || preg_match("#Valance#i", $metaArray['wttype'])) {
                                            $itemDescription .= "<br>Fabric Vertically Seamed";
                                        }
                                        if (preg_match("#Valance#i", $metaArray['wttype'])) {
                                            $itemDescription .= "<br>" . $metaArray['pleats'] . " Pleats";
                                        }
                                        if (isset($metaArray['linings_id']) && floatval($metaArray['linings_id']) > 0) {
                                            $thisLining = $this->Linings->get($metaArray['linings_id'])->toArray();
                                            $itemDescription .= "<br><b>Lining:</b> " . $thisLining['short_title'];
                                        }
                                        if (preg_match("#Cornice#i", $metaArray['wttype'])) {
                                            $welts = '';
                                            if ($metaArray['welt-top'] == '1' && $metaArray['welt-bottom'] == '1') {
                                                $welts = "Top + Bottom";
                                            } else {
                                                if ($metaArray['welt-top'] == '1') {
                                                    $welts = "Top Only";
                                                } elseif ($metaArray['welt-bottom'] == '1') {
                                                    $welts = "Bottom Only";
                                                }
                                            }
                                            if ($welts != '') {
                                                $itemDescription .= "<br><b>Welts:</b> " . $welts;
                                            } else {
                                                $itemDescription .= "<br><b>Welts:</b> None";
                                            }
                                        }

                                        break;
                                    case "track_systems":
                                        $itemDescription .= "<b>" . $quoteItem['title'] . "</b>";
                                        if (isset($metaArray['_component_numlines']) && intval($metaArray['_component_numlines']) > 0) {
                                            $itemDescription .= "<br><button style=\"padding:4px; border:1px solid #000; background:#CCC; color:#000; font-size:11px;\" onclick=\"loadTrackBreakdown('" . $quoteItem['id'] . "');\" type=\"button\">List Components</button>";
                                        }
                                        break;
                                }
                            } elseif ($metaArray['lineitemtype'] == 'custom' || $metaArray['lineitemtype'] == 'newcatchall') {
                                $itemDescription .= "<b>" . $quoteItem['title'] . "</b>";
                                $itemDescription .= "<br>" . $quoteItem['description'];
                                $itemDescription .= "<br>" . nl2br($metaArray['specs']);
                            }

                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////


                            $ttwizard = new \PHPExcel_Helper_HTML;
                            $lineItemValue = $ttwizard->toRichTextObject($itemDescription);


                            $fabricValue = '';
                            $fabricFR = '';
                            if (isset($thisFabric['flammability']) && strlen(trim($thisFabric['flammability'])) > 0) {
                                $fabricFR = '<br><b>FR: ' . $thisFabric['flammability'] . '</b>';
                            }

                            if ($quoteItem['product_type'] == 'track_systems') {
                                $fabricValue .= '---';
                            } elseif ($quoteItem['product_type'] == 'custom') {
                                if (isset($metaArray['com-fabric']) && $metaArray['com-fabric'] == "1") {
                                    $fabricValue .= "COM ";
                                }
                                if ($fabricAlias = $this->getFabricAlias($metaArray['fabricid'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $fabricValue .= $fabricAlias['fabric_name'] . "<br>" . $metaArray['fabric_name'] . $fabricFR;
                                    } else {
                                        $fabricValue .= $metaArray['fabric_name'] . "<br><em>(" . $fabricAlias['fabric_name'] . ")</em>" . $fabricFR;
                                    }
                                } else {
                                    $fabricValue .= $metaArray['fabric_name'] . $fabricFR;
                                }
                            } else {
                                if (isset($metaArray['com-fabric']) && $metaArray['com-fabric'] == "1") {
                                    $fabricValue .= "COM ";
                                }
                                if ($fabricAlias = $this->getFabricAlias($thisFabric['id'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $fabricValue .= "<b>" . $fabricAlias['fabric_name'] . "</b><br>" . $thisFabric['fabric_name'];
                                    } else {
                                        $fabricValue .= $thisFabric['fabric_name'] . "<br><em>(" . $fabricAlias['fabric_name'] . ")</em>";
                                    }
                                } else {
                                    $fabricValue .= $thisFabric['fabric_name'];
                                }
                                $fabricValue .= $fabricFR;
                            }

                            $fabricwizard = new \PHPExcel_Helper_HTML;
                            $fabricrichText = $fabricwizard->toRichTextObject($fabricValue);


                            $colorValue = '';
                            if ($quoteItem['product_type'] == 'track_systems') {
                                $colorValue .= '---';
                            } elseif ($quoteItem['product_type'] == 'custom') {
                                if ($fabricAlias = $this->getFabricAlias($metaArray['fabricid'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $colorValue .= "<b>" . $fabricAlias['color'] . "</b><br>" . $metaArray['fabric_color'];
                                    } else {
                                        $colorValue .= $metaArray['fabric_color'] . "<br><em>(" . $fabricAlias['color'] . ")</em>";
                                    }
                                } else {
                                    $colorValue .= $metaArray['fabric_color'];
                                }
                            } else {
                                if ($fabricAlias = $this->getFabricAlias($thisFabric['id'], $thisQuote['customer_id'])) {
                                    if (isset($metaArray['usealias']) && $metaArray['usealias'] == 'yes') {
                                        $colorValue .= "<b>" . $fabricAlias['color'] . "</b><Br>" . $thisFabric['color'];
                                    } else {
                                        $colorValue .= $thisFabric['color'] . "<br><em>(" . $fabricAlias['color'] . ")</em>";
                                    }
                                } else {
                                    $colorValue .= $thisFabric['color'];
                                }
                            }

                            $colorwizard = new \PHPExcel_Helper_HTML;
                            $colorrichText = $colorwizard->toRichTextObject($colorValue);

                            $cutwidthValue = '';
                            $finwidthValue = '';

                            if ($quoteItem['product_type'] == 'track_systems') {
                                $cutwidthValue .= '---';
                            } elseif ($quoteItem['product_type'] == "bedspreads") {
                                $cutwidthValue .= number_format(floatval($metaArray['width']), 0, '', '');
                                if (isset($metaArray['width']) && strlen(trim($metaArray['width'])) > 0) {
                                    $finwidthValue .= $metaArray['width'];
                                }
                            } elseif ($quoteItem['product_type'] == "cubicle_curtains") {
                                $cutwidthValue .= number_format(floatval($metaArray['width']), 0, '', '');
                                if (isset($metaArray['expected-finish-width']) && strlen(trim($metaArray['expected-finish-width'])) > 0) {
                                    $finwidthValue .= $metaArray['expected-finish-width'];
                                }
                            } elseif ($quoteItem['product_type'] == 'window_treatments') {
                                if ($metaArray['wttype'] == 'Pinch Pleated Drapery') {
                                    $cutwidthValue .= number_format(floatval($metaArray['rod-width']), 0, '', '') . " (Rod)";
                                    $finwidthValue .= $metaArray['default-return'] . " (Return)";
                                } elseif (preg_match("#Cornice#i", $metaArray['wttype']) || preg_match("#Valance#i", $metaArray['wttype'])) {
                                    $cutwidthValue .= number_format(floatval($metaArray['width']), 0, '', '') . " (Face)";
                                    if (isset($metaArray['return']) && floatval(trim($metaArray['return'])) > 0) {
                                        $finwidthValue .= $metaArray['return'] . " (Return)";
                                    } else {
                                        $finwidthValue .= "No Return";
                                    }
                                }
                            } else {
                                if ($metaArray['calculator-used'] == "box-pleated") {
                                    if (isset($metaArray['face']) && strlen(trim($metaArray['face'])) > 0) {
                                        $cutwidthValue .= $metaArray['face'] . " (Face)";
                                    }
                                    if (isset($metaArray['return']) && floatval(trim($metaArray['return'])) > 0) {
                                        $finwidthValue .= $metaArray['return'] . " (Return)";
                                    } else {
                                        $finwidthValue .= "No Return";
                                    }
                                } elseif ($metaArray['calculator-used'] == "bedspread" || $metaArray['calculator-used'] == "bedspread-manual") {
                                    if (isset($metaArray['width']) && strlen(trim($metaArray['width'])) > 0) {
                                        $finwidthValue .= $metaArray['width'];
                                    }
                                } elseif ($metaArray['calculator-used'] == "cubicle-curtain") {
                                    if (isset($metaArray['width']) && strlen(trim($metaArray['width'])) > 0) {
                                        $cutwidthValue .= $metaArray['width'];
                                    }
                                    if (isset($metaArray['expected-finish-width']) && strlen(trim($metaArray['expected-finish-width'])) > 0) {
                                        $finwidthValue .= $metaArray['expected-finish-width'];
                                    } else {
                                        if (isset($metaArray['fw']) && strlen(trim($metaArray['fw'])) > 0) {
                                            $finwidthValue .= $metaArray['fw'];
                                        }
                                    }
                                } elseif ($metaArray['calculator-used'] == "straight-cornice") {
                                    if (isset($metaArray['face']) && strlen(trim($metaArray['face'])) > 0) {
                                        $cutwidthValue .= $metaArray['face'] . " (Face)";
                                    }
                                    if (isset($metaArray['return']) && floatval(trim($metaArray['return'])) > 0) {
                                        $finwidthValue .= $metaArray['return'] . " (Return)";
                                    } else {
                                        $finwidthValue .= "No Return";
                                    }
                                } elseif ($metaArray['calculator-used'] == 'pinch-pleated') {
                                    if ($metaArray['unit-of-measure'] == 'pair') {
                                        if (isset($metaArray['rod-width']) && strlen(trim($metaArray['rod-width'])) > 0) {
                                            $cutwidthValue .= $metaArray['rod-width'] . " (Rod)";
                                        }
                                    } else {
                                        if (isset($metaArray['fabric-widths-per-panel'])) {
                                            $cutwidthValue .= $metaArray['fabric-widths-per-panel'] . " Widths";
                                        }
                                    }
                                    if (isset($metaArray['fullness']) && strlen(trim($metaArray['fullness'])) > 0) {
                                        $finwidthValue .= $metaArray['fullness'] . "X Fullness";
                                    }
                                    if (isset($metaArray['default-return']) && strlen(trim($metaArray['default-return'])) > 0) {
                                        $finwidthValue .= "<br>" . $metaArray['default-return'] . " Ret";
                                    }
                                    if (isset($metaArray['default-overlap']) && strlen(trim($metaArray['default-overlap'])) > 0) {
                                        $finwidthValue .= "<br>" . $metaArray['default-overlap'] . " Ovrlp";
                                    }
                                }
                            }

                            $cutwidthwizard = new \PHPExcel_Helper_HTML;
                            $cutwidthValue = $cutwidthwizard->toRichTextObject($cutwidthValue);

                            $finwidthwizard = new \PHPExcel_Helper_HTML;
                            $finwidthValue = $finwidthwizard->toRichTextObject($finwidthValue);

                            $lengthValue = '';
                            if ($quoteItem['product_type'] == 'track_systems') {
                                $lengthValue = '---';
                            } else {
                                if ($metaArray['calculator-used'] == "box-pleated") {
                                    $lengthValue .= $metaArray['height'] . " (Height)";
                                } elseif ($metaArray['calculator-used'] == "straight-cornice") {
                                    $lengthValue .= $metaArray['height'] . " (Height)";
                                } else {
                                    $lengthValue .= $metaArray['length'];
                                    if ($quoteItem['product_type'] == 'window_treatments' && (preg_match("#Cornice#i", $metaArray['wttype']) || preg_match("#Valance#i", $metaArray['wttype']))) {
                                        $lengthValue .= " (Height)";
                                    }
                                }
                                if (isset($metaArray['fl-short']) && floatval($metaArray['fl-short']) > 0) {
                                    $lengthValue .= "<br>" . $metaArray['fl-short'] . "(Short Point)";
                                }
                            }
                            $lengthwizard = new \PHPExcel_Helper_HTML;
                            $lengthrichText = $lengthwizard->toRichTextObject($lengthValue);






                            if (isset($metaArray['yds-per-unit'])) {
                                $ydsperunitValue = $metaArray['yds-per-unit'];
                            } else {
                                $ydsperunitValue = '---';
                            }




                            $bestprice = $quoteItem['best_price'];
                            $installadjustmentpercentage = 0;
                            $tieradjustmentpercentage = 0;
                            $tierDiscountOrPremium = 'Disc';
                            $rebateadjustmentpercentage = 0;

                            if ($metaArray['specialpricing'] == '1') {
                                $tieradjusted = number_format(floatval($quoteItem['best_price']), 2, '.', ',');
                                $installadjusted = number_format(floatval($quoteItem['best_price']), 2, '.', ',');
                                $rebateadjusted = number_format(floatval($quoteItem['best_price']), 2, '.', ',');
                                $pmiadjusted = number_format(floatval($quoteItem['pmi_adjusted']), 2, '.', ',');
                                $pmiadjustmentdollars = number_format((floatval(str_replace(',', '', $pmiadjusted)) - floatval(str_replace(',', '', $rebateadjusted))), 2, '.', ',');
                            } else {
                                $tieradjusted = number_format(floatval($quoteItem['tier_adjusted_price']), 2, '.', ',');
                                $installadjusted = number_format(floatval($quoteItem['install_adjusted_price']), 2, '.', ',');
                                $rebateadjusted = number_format(floatval($quoteItem['rebate_adjusted_price']), 2, '.', ',');
                                $pmiadjusted = number_format(floatval($quoteItem['pmi_adjusted']), 2, '.', ',');

                                $tieradjustmentpercentage = round(abs((((1 / floatval(str_replace(',', '', $quoteItem['best_price']))) * floatval(str_replace(',', '', $tieradjusted))) * 100)), 2);
                                $installadjustmentpercentage = round(abs(((1 - ((1 / floatval(str_replace(',', '', $tieradjusted))) * floatval(str_replace(',', '', $installadjusted)))) * 100)), 2);
                                $rebateadjustmentpercentage = round(abs(((1 - ((1 / floatval(str_replace(',', '', $installadjusted))) * floatval(str_replace(',', '', $rebateadjusted)))) * 100)), 2);
                                $pmiadjustmentdollars = number_format((floatval(str_replace(',', '', $pmiadjusted)) - floatval(str_replace(',', '', $rebateadjusted))), 2, '.', ',');
                            }

                            $breakdownValue = '';
                            $basePriceValue = number_format($bestprice, 2, '.', ',');

                            if ($metaArray['specialpricing'] == '1') {
                                $breakdownValue .= "<font color=\"#FF0000\"><b><em>SPECIAL PRICING</em></b></font>";
                            } else {
                                $breakdownValue .= "<font color=\"#0000FF\">" . $tieradjusted . " Tier (";
                                if (floatval(str_replace(',', '', $quoteItem['best_price'])) > floatval(str_replace(',', '', $tieradjusted))) {
                                    $breakdownValue .= '-' . $tieradjustmentpercentage . "% Disc";
                                } elseif (floatval(str_replace(',', '', $quoteItem['best_price'])) < floatval(str_replace(',', '', $tieradjusted))) {
                                    if ($tieradjustmentpercentage > 100) {
                                        $breakdownValue .= '+' . ($tieradjustmentpercentage - 100) . "% Prem";
                                    } else {
                                        $breakdownValue .= '+' . $tieradjustmentpercentage . "% Prem";
                                    }
                                } else {
                                    $breakdownValue .= "0%";
                                }

                                $breakdownValue .= ")<br>" . $installadjusted . " INST (+" . $installadjustmentpercentage . "%)<br>" . $rebateadjusted . " ADD ";
                                $breakdownValue .= "(+" . $rebateadjustmentpercentage . "%)";
                                $breakdownValue .= "<br>" . $pmiadjusted . " PMI (+\$" . $pmiadjustmentdollars . ")</font>"                                        $colorValue .= $metaArray['fabric_color'] . "<br><em>(" . $fabricAlias['color'] . ")</em>";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              d to orders

				if(!$this->quoteHasOrder($materialQuote['id'])){

					continue;

				}

				//get all line item data

				$lines=$this->QuoteLineItems->find('all',['conditions' => ['quote_id' => $materialQuote['id']]])->toArray();

				foreach($lines as $lineitem){

					//gather all line item metadata

					$lineItemMetas=$this->QuoteLineItemMeta->find('all',['conditions' => ['quote_item_id' => $lineitem['id']]])->toArray();

					$lineItemMetaArray=array();

					foreach($lineItemMetas as $lineItemMetaRow){

						$lineItemMetaArray[$lineItemMetaRow['meta_key']]=$lineItemMetaRow['meta_value'];

					}

					if(isset($lineItemMetaArray['com-fabric']) && $lineItemMetaArray['com-fabric'] == '1' && floatval($lineItemMetaArray['yds-per-unit']) >0){

						//this is COM

						if(!in_array($materialOrder['id'],$maybeMaterialsCOM[$lineItemMetaArray['fabricid']]['orders'])){

							$maybeMaterialsCOM[$lineItemMetaArray['fabricid']]['quotes'][]=$materialQuote['quote_number'];

						}

						if(!isset($maybeMaterialsCOM[$lineItemMetaArray['fabricid']]['total-yards'])){

							$maybeMaterialsCOM[$lineItemMetaArray['fabricid']]['total-yards'] = (floatval($lineItemMetaArray['yds-per-unit']) * floatval($lineitem['qty']) );

						}else{

							$maybeMaterialsCOM[$lineItemMetaArray['fabricid']]['total-yards'] = ($maybeMaterialsCOM[$lineItemMetaArray['fabricid']]['total-yards'] + (floatval($lineItemMetaArray['yds-per-unit']) * floatval($lineitem['qty']) ));

						}

						$maybeMaterialsCOM[$lineItemMetaArray['fabricid']]['yardages'][]=array(

							'quote_number' => $materialQuote['quote_number'],

							'line_number' => $lineitem['line_number'],

							'yards' => (floatval($lineItemMetaArray['yds-per-unit']) * floatval($lineitem['qty']) )

						);

					}

					if(!isset($lineItemMetaArray['com-fabric']) || (isset($lineItemMetaArray['com-fabric']) && $lineItemMetaArray['com-fabric'] == '0') && floatval($lineItemMetaArray['yds-per-unit']) >0){

						//this is MOM

						if(!in_array($materialOrder['id'],$maybeMaterialsMOM[$lineItemMetaArray['fabricid']]['orders'])){

							$maybeMaterialsMOM[$lineItemMetaArray['fabricid']]['quotes'][]=$materialQuote['quote_number'];

						}

						if(!isset($maybeMaterialsMOM[$lineItemMetaArray['fabricid']]['total-yards'])){

							$maybeMaterialsMOM[$lineItemMetaArray['fabricid']]['total-yards'] = (floatval($lineItemMetaArray['yds-per-unit']) * floatval($lineitem['qty']) );

						}else{

							$maybeMaterialsMOM[$lineItemMetaArray['fabricid']]['total-yards'] = ($maybeMaterialsMOM[$lineItemMetaArray['fabricid']]['total-yards'] + (floatval($lineItemMetaArray['yds-per-unit']) * floatval($lineitem['qty']) ));

						}

						$maybeMaterialsMOM[$lineItemMetaArray['fabricid']]['yardages'][] = array(

							'quote_number' => $materialQuote['quote_number'],

							'line_number' => $lineitem['line_number'],

							'yards' => (floatval($lineItemMetaArray['yds-per-unit']) * floatval($lineitem['qty']) )

						);

					}

				}

			}

			$this->set('maybeMaterialsCOM',$maybeMaterialsCOM);

			$this->set('maybeMaterialsMOM',$maybeMaterialsMOM);

			$this->render('ordermaterial');

		}

	}

	

	

	public function buildbluesheet($quoteLineID,$step='step1',$other=false){

		

		$this->autoRender=false;

		
		
		$allFabrics=$this->Fabrics->find('all')->toArray();
		$this->set('allFabrics',$allFabrics);

		$allLinings=$this->Linings->find('all')->toArray();
		$this->set('allLinings',$allLinings);
		
		switch($step){

			case "step1":

				//select a template

				

				$blueSheetTemplates=$this->BluesheetTemplates->find('all')->toArray();

				$this->set('bluesheetTemplates',$blueSheetTemplates);

				

				$this->set('lineItemID',$quoteLineID);

				

				$this->render('selectbluesheettemplate');

				

			break;

			case "step2":

				

				$thisTemplate=$this->BluesheetTemplates->get($other)->toArray();

				$this->set('template',$thisTemplate);

				

				

				//$this->viewBuilder()->layout('iframeinner');

				$lineItem=$this->QuoteLineItems->get($quoteLineID)->toArray();

				$thisQuote=$this->Quotes->get($lineItem['quote_id'])->toArray();

				$this->set('thisQuote',$thisQuote);

				$this->set('lineItemData',$lineItem);

				$thisOrderFind=$this->Orders->find('all',['conditions'=>['quote_id' => $thisQuote['id']]])->toArray();

				foreach($thisOrderFind as $thisOrderRow){

					$this->set('thisOrder',$thisOrderRow);

					$thisCustomer=$this->Customers->get($thisOrderRow['customer_id'])->toArray();

					$this->set('thisCustomer',$thisCustomer);

				}

				$this->set('thisUser',$this->Auth->user());

				$lineItemMetas=$this->QuoteLineItemMeta->find('all',['conditions'=>['quote_item_id'=>$quoteLineID]])->toArray();

				$this->set('lineItemMetas',$lineItemMetas);
				

				$this->render('buildbluesheet');

				

			break;

		}

		

	}

	

	

	public function materialusageform($orderID){

		$thisOrder=$this->Orders->get($orderID)->toArray();

		$this->set('orderData',$thisOrder);

		$GLOBALS['pdfmargins']='custom';

		$GLOBALS['pdfmarginscustom']=array('left'=>6,'top'=>4,'right'=>6,'header'=>6);

		$thisCustomer=$this->Customers->get($thisOrder['customer_id'])->toArray();

		$this->set('customerData',$thisCustomer);

		//find all the line items in this order

		$lineItems=$this->QuoteLineItems->find('all',['conditions'=>['quote_id'=>$thisOrder['quote_id']],'order'=>['sortorder'=>'asc']])->toArray();

		$this->set('lineItems',$lineItems);

		$lineItemsArray=array();

		foreach($lineItems as $lineitem){

			$lineItemsArray[$lineitem['id']]=array();

			$lineItemsArray[$lineitem['id']]['data']=$lineitem;

			$lineItemsArray[$lineitem['id']]['metadata']=array();

			$lineItemsArray[$lineitem['id']]['fabricdata']=array();

			$lineItemMetas=$this->QuoteLineItemMeta->find('all',['conditions'=>['quote_item_id'=>$lineitem['id']]])->toArray();

			$lineItemMetaArray=array();
			foreach($lineItemMetas as $lineitemmeta){
				$lineItemMetaArray[$lineitemmeta['meta_key']]=$lineitemmeta['meta_value'];
			}
			
			foreach($lineItemMetas as $lineitemmeta){

				$lineItemsArray[$lineitem['id']]['metadata'][$lineitemmeta['meta_key']]=$lineitemmeta['meta_value'];	

				if($lineitemmeta['meta_key']=='fabricid' && $lineitemmeta['meta_value'] != '0'){

					$thisFabric=$this->Fabrics->get($lineitemmeta['meta_value'])->toArray();

					$lineItemsArray[$lineitem['id']]['fabricdata']=$thisFabric;

				}elseif($lineitemmeta['meta_key']=='fabricid' && $lineitemmeta['meta_value'] == '0'){
					
					$thisFabric=array('fabric_name' => $lineItemMetaArray['fabric_name'], 'color' => $lineItemMetaArray['fabric_color']);
					$lineItemsArray[$lineitem['id']]['fabricdata']=$thisFabric;
					
				}

			}

		}

		$this->set('productTypeCounts',array('cc'=>$numCC,'bs'=>$numBS,'wt'=>$numWT));

		$this->set('lineItems',$lineItemsArray);

		

	}

	

	public function packingslipform($orderID){

		
/**PPSASCRUM-29 start */
		//$thisOrder=$this->Orders->get($orderID)->toArray();
		$thisOrder=$this->WorkOrders->get($orderID)->toArray();	
/**PPSASCRUM-29 end */
		$this->set('orderData',$thisOrder);

		
		$allShipMethods=array();
		$shipMethodsLookup=$this->ShippingMethods->find('all')->toArray();
		foreach($shipMethodsLookup as $shipMethod){
			$allShipMethods[$shipMethod['id']]=$shipMethod['name'];
		}
		$this->set('allShipMethods',$allShipMethods);



		$thisCustomer=$this->Customers->get($thisOrder['customer_id'])->toArray();

		$this->set('customerData',$thisCustomer);
		/**PPSASCRUM-7 start **/
		if($thisOrder['userType'] != "customer"){
		    if($thisOrder['shipto_id'] != NULL && $thisOrder['userType'] != 'default') {
		    $thisShipTo=$this->ShipTo->get($thisOrder['shipto_id'])->toArray();
		    
		        $this->set('shipToName',$thisShipTo['ship_to_name']);
		    }
		    else if($thisOrder['facility_id'] != NULL) {
		    $thisFacilityDetails= $this->Facility->get($thisOrder['facility_id'])->toArray();
		    $thisShipTo=$this->ShipTo->get($thisFacilityDetails['default_address'])->toArray();
		    $this->set('shipToName',$thisShipTo['ship_to_name']);
		        
		    }
		    else 
		     $this->set('shipToName',$thisCustomer['shipping_name']);

		//$this->set('shipToName',$thisShipTo['ship_to_name']);
		}else 
		{
		    $this->set('shipToName',$thisCustomer['shipping_name']);
		}

		/**PPSASCRUM-7 end **/

		//find all the line items in this order
		/**PPSASCRUM-29 start */
		//$lineItems=$this->QuoteLineItems->find('all',['conditions'=>['quote_id'=>$thisOrder['quote_id']],'order'=>['sortorder'=>'asc']])->toArray();
		$lineItems=$this->WorkOrderLineItems->find('all',['conditions'=>['quote_id'=>$thisOrder['quote_id']],'order'=>['sortorder'=>'asc']])->toArray();
		/**PPSASCRUM-29 end */
		$this->set('lineItems',$lineItems);

		$lineItemsArray=array();

		foreach($lineItems as $lineitem){

			$lineItemsArray[$lineitem['id']]=array();

			$lineItemsArray[$lineitem['id']]['data']=$lineitem;

			$lineItemsArray[$lineitem['id']]['metadata']=array();

			$lineItemsArray[$lineitem['id']]['fabricdata']=array();

			/**PPSASCRUM-29 start */
			//$lineItemMetas=$this->QuoteLineItemMeta->find('all',['conditions'=>['quote_item_id'=>$lineitem['id']]])->toArray();

			$lineItemMetas=$this->WorkOrderLineItemMeta->find('all',['conditions'=>['worder_item_id'=>$lineitem['id']]])->toArray();
			/**PPSASCRUM-29 end */
			$lineItemMetaArray=array();
			foreach($lineItemMetas as $lineitemmeta){
				$lineItemMetaArray[$lineitemmeta['meta_key']]=$lineitemmeta['meta_value'];
			}
			
			foreach($lineItemMetas as $lineitemmeta){

				$lineItemsArray[$lineitem['id']]['metadata'][$lineitemmeta['meta_key']]=$lineitemmeta['meta_value'];	

				if($lineitemmeta['meta_key']=='fabricid' && $lineitemmeta['meta_value'] != '0'){

					$thisFabric=$this->Fabrics->get($lineitemmeta['meta_value'])->toArray();

					$lineItemsArray[$lineitem['id']]['fabricdata']=$thisFabric;

				}elseif($lineitemmeta['meta_key']=='fabricid' && $lineitemmeta['meta_value'] == '0'){
					$thisFabric=array('fabric_name' => $lineItemMetaArray['fabric_name'], 'color' => $lineItemMetaArray['fabric_color']);
					$lineItemsArray[$lineitem['id']]['fabricdata']=$thisFabric;
				}

				if($fabricAlias=$this->getFabricAlias($thisFabric['id'],$thisOrder['customer_id'])){

					$usealias=false;

					foreach($lineItemMetas as $metaloopentry){

						if($metaloopentry['meta_key'] == "usealias" && $metaloopentry['meta_value'] == "yes"){

							$usealias=true;

						}

					}

					if($usealias){

						$lineItemsArray[$lineitem['id']]['fabricdata']['fabric_name']=$fabricAlias['fabric_name'];

						$lineItemsArray[$lineitem['id']]['fabricdata']['color'] = $fabricAlias['color'];

					}

				}

			}

			

			

			//find the matching order item id# for this quote item id#

			$orderItemID=0;

			$lookupOrderItem=$this->OrderItems->find('all',['conditions'=>['quote_line_item_id'=>$lineitem['id']]])->toArray();

			foreach($lookupOrderItem as $orderitemrow){

				$orderItemID=$orderitemrow['id'];

			}

			

			$lineItemsArray[$lineitem['id']]['order_item_id']=$orderItemID;

			

			$alreadyPackagedCount=0;

			//find all previously shipped items in this line

			$shippedItemsLookup=$this->OrderItemStatus->find('all',['conditions'=>['order_line_number'=>$lineitem['line_number'],'order_item_id'=>$orderItemID,'work_order_id'=>$orderID,'status IN' => ['Shipped','Warehoused']]]);

			foreach($shippedItemsLookup as $shippedItemRow){

				$alreadyPackagedCount=($alreadyPackagedCount + floatval($shippedItemRow['qty_involved']));

			}

			

			$lineItemsArray[$lineitem['id']]['previously_shipped']=$alreadyPackagedCount;

		}

		$this->set('productTypeCounts',array('cc'=>$numCC,'bs'=>$numBS,'wt'=>$numWT));

		$this->set('lineItems',$lineItemsArray);

		

		/*if($this->request->data){

			

			$this->set('postdata',$_POST);*/

			

			$this->set('allSettings',$this->getsettingsarray());

			$GLOBALS['pdforientation']='P';

			$GLOBALS['pdfmargins']='custom';

			$GLOBALS['pdfmarginscustom']=array('left'=>6,'top'=>15,'right'=>6,'header'=>20);

		

			foreach($lineItemsArray as $itemID => $itemData){

				if($this->request->data["useline_".$itemID]=="1"){

					//mark this line and qty as warehoused

					$orderItemStatusTable=TableRegistry::get('OrderItemStatus');

					$newItemStatus=$orderItemStatusTable->newEntity();

					$newItemStatus->order_line_number=$itemData['data']['line_number'];

					$newItemStatus->order_item_id=$itemData['order_item_id'];

					$newItemStatus->time=time();

					$newItemStatus->status='Warehoused';

					$newItemStatus->user_id=$this->Auth->user('id');

					$newItemStatus->qty_involved=$this->request->data["qty_in_package_".$itemID];

					$newItemStatus->work_order_id=$orderID;

					$newItemStatus->shipment_id=0;

					$orderItemStatusTable->save($newItemStatus);

					

					

				}

			}
			$this->auditOrderItemStatuses($orderID);
			

			

			/*

			$packSlipTable=TableRegistry::get('PackingSlips');

			$newPackSlip=$packSlipTable->newEntity();

			$newPackSlip->time=time();

			$newPackSlip->order_id=$orderID;

			$newPackSlip->user_id=$this->Auth->user('id');

			$newPackSlip->packing_slip_number=$this->request->data['packslip_number'];

			$newPackSlip->formdata=json_encode($this->request->data);

			$newPackSlip->shipment_id=0;

			$packSlipTable->save($newPackSlip);

			

		}else{

			//show the form to build this packing slip

			$this->autoRender=false;

			$this->viewBuilder()->layout('default');

			

			

			$this->render('packingslipform');

		}*/

		

	}

	

	

	public function buildbompdf($orderID){

		
		/**PPSASCRUM-29 start */
		//$thisOrder=$this->Orders->get($orderID)->toArray();

		$thisOrder=$this->WorkOrders->get($orderID)->toArray();
		/**PPSASCRUM-29 end */

		$this->set('orderData',$thisOrder);

		

		$fabricsDataArray=array();

		$allFabrics=$this->Fabrics->find('all')->toArray();

		foreach($allFabrics as $fabric){

			$fabricsDataArray[$fabric['id']]=$fabric;

		}

		

		$this->set('fabricsDataArray',$fabricsDataArray);

		

		

		$GLOBALS['pdfmargins']='custom';

		$GLOBALS['pdfmarginscustom']=array('left'=>6,'top'=>4,'right'=>6,'header'=>6);

		

		$thisCustomer=$this->Customers->get($thisOrder['customer_id'])->toArray();

		$this->set('customerData',$thisCustomer);

		

		//find all the line items in this order
		/**PPSASCRUM-29 start */
		//$lineItems=$this->QuoteLineItems->find('all',['conditions'=>['quote_id'=>$thisOrder['quote_id']],'order'=>['sortorder'=>'asc']])->toArray();
		$lineItems=$this->WorkOrderLineItems->find('all',['conditions'=>['quote_id'=>$thisOrder['quote_id']],'order'=>['sortorder'=>'asc']])->toArray();
		/**PPSASCRUM-29 end */

		$this->set('lineItems',$lineItems);

		

		$lineItemsArray=array();

		$COMs=array();

		foreach($lineItems as $lineitem){

			

			

			$lineItemsArray[$lineitem['id']]=array();

			$lineItemsArray[$lineitem['id']]['data']=$lineitem;

			

			$lineItemsArray[$lineitem['id']]['metadata']=array();

			

			$lineItemsArray[$lineitem['id']]['fabricdata']=array();
				$lineItemsArray[$lineitem['id']]['liningsdata']=array();
			
			$lineItemMetaArray=array();

			/**PPSASCRUM-29 start */
			//$lineItemMetas=$this->QuoteLineItemMeta->find('all',['conditions'=>['quote_item_id'=>$lineitem['id']]])->toArray();

			$lineItemMetas=$this->WorkOrderLineItemMeta->find('all',['conditions'=>['worder_item_id'=>$lineitem['id']]])->toArray();
			/**PPSASCRUM-29 end */

			foreach($lineItemMetas as $lineitemmeta){
				$lineItemMetaArray[$lineitemmeta['meta_key']] = $lineitemmeta['meta_value'];
			}
			
			foreach($lineItemMetas as $lineitemmeta){

				$lineItemsArray[$lineitem['id']]['metadata'][$lineitemmeta['meta_key']]=$lineitemmeta['meta_value'];	

				if($lineitemmeta['meta_key']=='fabricid' && $lineitemmeta['meta_value'] != '0'){
if(!empty($lineitemmeta['meta_value'])){
    	$thisFabric=$this->Fabrics->get($lineitemmeta['meta_value'])->toArray();

					$lineItemsArray[$lineitem['id']]['fabricdata']=$thisFabric;
				
}
					

				}elseif($lineitemmeta['meta_key']=='fabricid' && $lineitemmeta['meta_value'] == '0'){
					$thisFabric=array('fabric_name'=>$lineItemMetaArray['fabric_name'], 'color' => $lineItemMetaArray['fabric_color']);
					$lineItemsArray[$lineitem['id']]['fabricdata']=$thisFabric;
				}
			

				if(isset($lineItemMetas['com-fabric']) && $lineItemMetas['com-fabric'] == '1'){
					$lineItemsArray[$lineitem['id']]['fabricdata']['isCOM']=true;
				}else{
					$lineItemsArray[$lineitem['id']]['fabricdata']['isCOM']=false;
				}
				
				/**PPSASCRUM-13 start**/
			/* PPSASCRUM-56: start */
    // 		if(isset($lineItemsArray[$lineitem['id']]['metadata']['linings_id']) && ($lineItemsArray[$lineitem['id']]['metadata']['linings_id']!= 'none' &&  !empty($lineItemsArray[$lineitem['id']]['metadata']['linings_id']))){
		    if(isset($lineItemsArray[$lineitem['id']]['metadata']['linings_id']) && ($lineItemsArray[$lineitem['id']]['metadata']['linings_id']!= 'none' && $lineItemsArray[$lineitem['id']]['metadata']['linings_id']!= 'default' &&  !empty($lineItemsArray[$lineitem['id']]['metadata']['linings_id']))){
	        /* PPSASCRUM-56: end */
                $liningData=$this->Linings->get($lineItemsArray[$lineitem['id']]['metadata']['linings_id'])->toArray();
                $qty = $lineItemsArray[$lineitem['id']]['metadata']['qty'];//$lineItemMetaArray['qty'];
                
                if($lineItemsArray[$lineitem['id']]['metadata']['lineitemtype'] == 'calculator'){
                    //$liningPricePerYd =$lineItemsArray[$lineitem['id']]['metadata']['lining-yds-per-unit']; 
                    if($lineItemsArray[$lineitem['id']]['metadata']['calculator-used']=='box-pleated'){
                         $liningPricePerYd =$lineItemsArray[$lineitem['id']]['metadata']['lining-yards']; 
                    /* PPSASCRUM-56: start */
                    /* PPSASCRUM-384: start */
                    // }elseif($lineItemsArray[$lineitem['id']]['metadata']['calculator-used']=='pinch-pleated'){
                    }elseif($lineItemsArray[$lineitem['id']]['metadata']['calculator-used']=='pinch-pleated' || $lineItemsArray[$lineitem['id']]['metadata']['calculator-used']=='new-pinch-pleated' ||
                            $lineItemsArray[$lineitem['id']]['metadata']['calculator-used']=='ripplefold-drapery' || $lineItemsArray[$lineitem['id']]['metadata']['calculator-used']=='accordiafold-drapery'){
					/* PPSASCRUM-384: end */
                    /* PPSASCRUM-56: end */
                         $liningPricePerYd =$lineItemsArray[$lineitem['id']]['metadata']['lining-yds-per-unit']; 
                    }elseif($lineItemsArray[$lineitem['id']]['metadata']['calculator-used']=='straight-cornice'){
                         $liningPricePerYd =$lineItemsArray[$lineitem['id']]['metadata']['yds-of-lining']; 
                    }

                }else
                $liningPricePerYd =$lineItemsArray[$lineitem['id']]['metadata']['lining-per-unit'];// (float)$lineItemsArray[$lineitem['id']]['metadata']["lining-price-per-yd"];//$lineItemMetaArray['lining-price-per-yd'];
                    
                $total =  ($liningPricePerYd* $qty);
                $thisFabric=array('fabric_name'=>'Lining', 'color' => $liningData['short_title'],'wo_line_number'=>$lineitem['wo_line_number'],'line_number'=>$lineitem['line_number'],'total'=>$total,'qty'=>$qty,'liningPricePerYd'=>$liningPricePerYd,'test'=>$lineitemmeta);
                $lineItemsLiningsArray[$lineitem['id']]['liningdata']=$thisFabric;
            }
    
    		/**PPSASCRUM-13 end**/
				
			}

		}

		
        $allUsers=$this->Users->find('all')->toArray();
        $this->set('allUsers',$allUsers);
        	/**PPSASCRUM-13 Start**/	$this->set('lineLiningItems',$lineItemsLiningsArray);/**PPSASCRUM-13 end**/

		

		//all purchasing notes
		$pNotes=$this->QuoteBomPurchasingNotes->find('all',['conditions' => ['quote_id' => $thisOrder['quote_id']]])->toArray();
		$this->set('pNotes',$pNotes);
		

		$this->set('productTypeCounts',array('cc'=>$numCC,'bs'=>$numBS,'wt'=>$numWT));

		$this->set('lineItems',$lineItemsArray);

		

		$GLOBALS['pdforientation']='P';

		$GLOBALS['pdfmargins']='custom';

		$GLOBALS['pdfmarginscustom']=array('left'=>6,'top'=>15,'right'=>6,'header'=>20);

	}

	

	

	public function exportorder($orderid){

		$this->autoRender=false;

		//$this->viewBuilder()->layout('textfile');

		

		$orderData=$this->Orders->get($orderid)->toArray();

		

		$orderContactEmail='';

		$contactFirstname='';

		$contactLastname='';

		

		if($orderData['contact_id'] > 0){

			$orderContact=$this->CustomerContacts->get($orderData['contact_id'])->toArray();

			$orderContactEmail=$orderContact['email_address'];

			$contactFirstname=$orderContact['first_name'];

			$contactLastname=$orderContact['last_name'];

		}

		

		$orderCustomer=$this->Customers->get($orderData['customer_id'])->toArray();

		

		

		//qb account line(s)

		echo "!ACCNT	NAME	ACCNTTYPE	DESC	ACCNUM	EXTRA\n";

		echo "ACCNT	Accounts Receivable	AR		1200	\n";

		echo "ACCNT	Cubicle Curtains	INC		4100	\n";

		echo "ACCNT	Bedspreads	INC	4105	\n";

		echo "ACCNT	Inventory Asset	OCASSET	1120	INVENTORYASSET\n";

		echo "ACCNT	Cost of Goods Sold	COGS	Cost of Goods Sold	5000	COGS\n";

		//invoice item(s)
		echo "!INVITEM	NAME	INVITEMTYPE	DESC	PURCHASEDESC	ACCNT	ASSETACCNT	COGSACCNT	PRICE	COST	TAXABLE	PAYMETH	TAXVEND	TAXDIST	PREFVEND	REORDERPOINT	EXTRA\n";

		

		

		echo "!CLASS	NAME\n";

		echo "CLASS	class\n";

		

		//customer line(s)

		echo "!CUST	NAME	BADDR1	BADDR2	BADD3	BADDR4	BADDR5	SADDR1	SADDR2	SADDR3	SADDR4	SADDR5	PHONE1	PHONE2	FAXNUM	EMAIL	NOTE	CONT1	CONT2	CTYPE	TERMS	TAXABLE	LIMIT	RESALENUM	REP	TAXITEM	NOTEPAD	SALUTATION	COMPANYNAME	FIRSTNAME	MIDINIT	LASTNAME\n";

		echo "CUST	".$orderCustomer['company_name']."	".$orderCustomer['billing_address']."	".$orderCustomer['billing_city'].", ".$orderCustomer['billing_state']." ".$orderCustomer['billing_zipcode']."				".$orderData['shipping_address_1']."	".$orderData['shipping_address_2']."	".$orderData['shipping_city'].", ".$orderData['shipping_state']." ".$orderData['shipping_zipcode']."			".$orderCustomer['phone']."		".$orderCustomer['fax']."	".$orderContactEmail."	NOTE	CONT1	CONT2	CTYPE	TERMS	TAXABLE	LIMIT	RESALENUM	REP	TAXITEM	NOTEPAD	SALUTATION	".$orderCustomer['company_name']."	".$contactFirstname."		".$contactLastname."\n";

		

		//vendor line(s)

		echo "!VEND	NAME	PRINTAS	ADDR1	ADDR2	ADDR3	ADDR4	ADDR5	VTYPE	CONT1	CONT2	PHONE1	PHONE2	FAXNUM	EMAIL	NOTE	TAXID	LIMIT	TERMS	NOTEPAD	SALUTATION	COMPANYNAME	FIRSTNAME	MIDINIT	LASTNAME\n";

	

		

		//transaction line(2)

		

		

		//invoice line item(s)

		

		

	}

	

	

	public function schedule(){

	/*	$lineSchedule=array();

		

		$scheduledOrders=$this->Orders->find('all',['conditions'=>['completed'=>0,'status !=' => 'Needs Line Items','sherry_status !='=>'Not Scheduled']])->toArray();

		foreach($scheduledOrders as $order){

			

			$thisCustomer=$this->Customers->get($order['customer_id'])->toArray();

			

			$quoteLineItems=$this->QuoteLineItems->find('all',['conditions'=>['quote_id'=>$order['quote_id']],'order'=>['sortorder'=>'asc']])->toArray();

			foreach($quoteLineItems as $quoteItem){

				$thisitemtype='';

				

				$lineItemMetas=$this->QuoteLineItemMeta->find('all',['conditions' => ['quote_item_id' => $quoteItem['id']]])->toArray();

				$itemMeta=array();

				foreach($lineItemMetas as $lineItemMetaRow){

					$itemMeta[$lineItemMetaRow['meta_key']]=$lineItemMetaRow['meta_value'];

				}

				

				switch($quoteItem['product_type']){

					case "bedspreads":

						$thisitemtypelabel="Bedspread";

						$thisitemtype='BS';

					break;

					case "cubicle_curtains":

						$thisitemtypelabel="Cubicle Curtain";

						$thisitemtype='CC';

					break;

					case "window_treatments":

						$thisitemtypelabel=$itemMeta['wttype'];

						switch($itemMeta['wttype']){

							case "Pinch Pleated Drapery":

								$thisitemtype='DRAPE';

							break;

							default:

								$thisitemtype='WT';

							break;

						}

						

					break;

					case "calculator":

						switch($quoteItem['calculator_used']){

							case "pinch-pleated":
							// PPSASCRUM-56: start
							case "new-pinch-pleated":
							// PPSASCRUM-56: end

								$thisitemtypelabel="Pinch Pleated Drapery";

								$thisitemtype='DRAPE';

							break;

							case "bedspread":

								$thisitemtypelabel="Bedspread";

								$thisitemtype='BS';

							break;

							case "cubicle-curtain":

								$thisitemtypelabel="Cubicle Curtain";

								$thisitemtype='CC';

							break;

							case "box-pleated":

								$thisitemtypelabel=$itemMeta['valance-type']." Valance";

								$thisitemtype='WT';

							break;

							case "straight-cornice":

								$thisitemtypelabel=$itemMeta['cornice-type']." Cornice";

								$thisitemtype='WT';

							break;

						}

					break;

				}

				

			

				$statuses=$this->OrderItemStatus->find('all',['conditions'=>['work_order_id'=>$order['id'],'order_line_number'=>$quoteItem['line_number'],'status !=' => 'Not Started'], 'order'=>['time'=>'desc']])->hydrate(false)->toArray();

			

				foreach($statuses as $status){

					$lineSchedule[]=array(

						'statusid'=>$status['id'],

						'statustext'=>$status['status'],

						'wo_number'=>$order['order_number'],

						'customer'=>$thisCustomer['company_name'],

						'timestamp'=>$status['time'],

						'line_number'=>$status['order_line_number'],

						'orderid'=>$order['id'],

						'qty_involved'=>$status['qty_involved'],

						'total_line_qty'=>$quoteItem['qty'],

						'itemtypelabel'=>$thisitemtypelabel,

						'itemtype'=>$thisitemtype,

						'difficulty'=>(floatval($itemMeta['difficulty-rating'])*floatval($quoteItem['qty'])),

						'laborlf'=>(floatval($itemMeta['labor-billable']) * floatval($quoteItem['qty']))

						);

				}

			}

		}

		$this->set('lineSchedule',$lineSchedule);*/

	}

	

	

	

	

	public function getunscheduled(){

		

		$orders=array();

		

		$overallTotalRows=0;

		

		//lookup schedules

		$allUnscheduledOrders=$this->Orders->find('all',['conditions'=>['completed'=>0,'status !=' => 'Needs Line Items','sherry_status'=>'Not Scheduled']])->toArray();

		foreach($allUnscheduledOrders as $order){

			

				$customerData=$this->Customers->get($order['customer_id'])->toArray();

				$userData=$this->Users->get($order['user_id'])->toArray();

				$quoteData=$this->Quotes->get($order['quote_id'])->toArray();

				if($quoteData['project_id'] == '0'){

					$projectName='';

				}else{

					$projectData=$this->Projects->get($quoteData['project_id'])->toArray();

					$projectName=$projectData['title'];

				}

			

				$overallTotalRows++;

				$orderTitle='';

				if(strlen(trim($quote['title'])) >0){

					$orderTitle .= "<b>".$quote['title']."</b><br>";

				}

				$orderTitle .= $customerData['company_name'];

				$orderstatus="<div class=\"orderlabel\">".ucfirst($order['status']);

				$addclasses='';

				if($order['due'] > time() && $order['due'] <= (time()+432000)){

					$addclasses .= " duesoon";

					$orderstatus .= " (DUE SOON)";

				}

				if($order['due'] < time() && $order['due'] > 1000){

					$addclasses .= " pastdue";

					$orderstatus .= " (PAST DUE)";

				}

				if($order['status']=="On Hold"){

					$addclasses .= " onhold";

				}

				if($order['status']=="Complete"){

					$addclasses .= " complete";

				}

				if($order['status'] == 'Canceled'){

					$addclasses .= " canceled";

				}

				$orderstatus .= "</div>";

				/*

				$completedpercent=$this->getOrderProgressPercent($order['id']);

				$orderstatus .= "<div class=\"progressbar\"><div class=\"progresscompleted\" style=\"width:".$completedpercent['percent']."%;\"></div></div>

				<div class=\"percentlabel\">".$completedpercent['completed']." / ".$completedpercent['total']." (".$completedpercent['percent']."%) Completed</div>";

				*/

			

				$totals='';

				if($order['cc_dollar'] >0){

					$totals .= 'CC: $'.number_format($order['cc_dollar'],2,'.',',').'<br>';

				}

				if($order['track_dollar'] > 0){

					$totals .= 'TRK: $'.number_format($order['track_dollar'],2,'.',',').'<br>';

				}

				if($order['bs_dollar'] > 0){

					$totals .= 'BS: $'.number_format($order['bs_dollar'],2,'.',',').'<br>';

				}

				if($order['drape_dollar'] >0){

					$totals .= 'DRAPERIES: $'.number_format($order['drape_dollar'],2,'.',',').'<br>';

				}

				if($order['val_dollar'] >0){

					$totals .= 'VAL: $'.number_format($order['val_dollar'],2,'.',',').'<br>';

				}

				if($order['corn_dollar'] >0){

					$totals .= 'CORN: $'.number_format($order['corn_dollar'],2,'.',',').'<br>';

				}

				if($order['wt_hw_dollar'] >0){

					$totals .= 'WTHW: $'.number_format($order['wt_hw_dollar'],2,'.',',').'<br>';

				}

				if($order['blinds_dollar'] >0){

					$totals .= 'B&amp;S: $'.number_format($order['blinds_dollar'],2,'.',',').'<br>';

				}

				if($order['fab_dollars'] >0){

					$totals .= 'FAB: $'.number_format($order['fab_dollars'],2,'.',',').'<br>';

				}

				if($order['measure_dollars'] >0){

					$totals .= 'MEAS: $'.number_format($order['measure_dollars'],2,'.',',').'<br>';

				}

				if($order['install_dollars'] >0){

					$totals .= 'INST: $'.number_format($order['install_dollars'],2,'.',',').'';

				}

				$totals .= "<hr style=\"margin:0; height:4px;\" />";

				$totals .= '<strong>$'.number_format($order['order_total'],2,'.',',').'</strong>';

				if($order['due'] > 1000){

					$duedate=date('n/j/Y',$order['due']);

				}else{

					$duedate='---';

				}

				$orders[]=array(

					'DT_RowId'=>'row_'.$order['id'],

					'DT_RowClass'=>'rowtest'.$addclasses,

					'0' => '<a href="/orders/scheduleorder/'.$order['id'].'"/><img src="/img/calendar.png" /></a>',

					'1' => $order['order_number'],

					'2' => $orderTitle,

					'3' => $order['po_number'],

					'4' => date('n/j/Y - g:iA',$order['created']),

					'5' => $projectName,

					'6' => $order['facility'],

					'7' => $duedate,

					'8' => $totals,

					'9' => $order['cc_qty'],

					'10' => $order['cc_lf'],

					'11' => $order['cc_diff'],

					'12' => $order['track_qty'],

					'13' => $order['bs_qty'],

					'14' => $order['bs_diff'],

					'15' => $order['drape_qty'],

					'16' => $order['drape_widths'],

					'17' => $order['drape_diff'],

					'18' => $order['tt_qty'],

					'19' => $order['tt_lf'],

					'20' => $order['tt_diff'],

					'21' => $order['wt_hw_qty'],

					'22' => $order['blinds_qty'],

					'23' => ''

				);

			

		}

	

		$totalFilteredRows=$overallTotalRows;

		

		$this->set('draw',$draw);

		$this->set('recordsTotal',$overallTotalRows);

		$this->set('recordsFiltered',$totalFilteredRows);

		$this->set('data',$orders);

		$this->set('_serialize',['draw','recordsTotal','recordsFiltered','data']);

		

	}

	

	

	

	public function getscheduled(){

		

		$orders=array();

		

		$overallTotalRows=0;

		

		//lookup schedules

		$allScheduledOrders=$this->Orders->find('all',['conditions'=>['completed'=>0,'status !=' => 'Needs Line Items','sherry_status IN'=>['Partially Scheduled','Fully Scheduled']]])->toArray();

		foreach($allScheduledOrders as $order){

			

				$customerData=$this->Customers->get($order['customer_id'])->toArray();

				$userData=$this->Users->get($order['user_id'])->toArray();

				$quoteData=$this->Quotes->get($order['quote_id'])->toArray();

				if($quoteData['project_id'] == '0'){

					$projectName='';

				}else{

					$projectData=$this->Projects->get($quoteData['project_id'])->toArray();

					$projectName=$projectData['title'];

				}

			

				$overallTotalRows++;

				$orderTitle='';

				if(strlen(trim($quote['title'])) >0){

					$orderTitle .= "<b>".$quote['title']."</b><br>";

				}

				$orderTitle .= $customerData['company_name'];

				$orderstatus="<div class=\"orderlabel\">".ucfirst($order['status']);

				$addclasses='';

				if($order['due'] > time() && $order['due'] <= (time()+432000)){

					$addclasses .= " duesoon";

					$orderstatus .= " (DUE SOON)";

				}

				if($order['due'] < time() && $order['due'] > 1000){

					$addclasses .= " pastdue";

					$orderstatus .= " (PAST DUE)";

				}

				if($order['status']=="On Hold"){

					$addclasses .= " onhold";

				}

				if($order['status']=="Complete"){

					$addclasses .= " complete";

				}

				if($order['status'] == 'Canceled'){

					$addclasses .= " canceled";

				}

				$orderstatus .= "</div>";

				/*

				$completedpercent=$this->getOrderProgressPercent($order['id']);

				$orderstatus .= "<div class=\"progressbar\"><div class=\"progresscompleted\" style=\"width:".$completedperc                                    foreach ($thisLineBatchesShipped as $shippedBatch) {
                                        //$dateShipped = date('n/j/Y',$shippedBatch['time']);
                                        $shipDateTimeObj = new \DateTime();
                                        $shipDateTimeObj->setTimestamp($shippedBatch['time']);
                                        $dateShipped = \PHPExcel_Shared_Date::PHPToExcel($shipDateTimeObj);
                                    }


                                    $dateScheduled = '';
                                    $thisLineBatchesScheduled = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Scheduled', 'sherry_batch_id' => $batchValue]])->toArray();
                                    foreach ($thisLineBatchesScheduled as $scheduledBatch) {
                                        //$dateScheduled = date('n/j/Y',$scheduledBatch['time']);
                                        $schedDateTimeObj = new \DateTime();
                                        $schedDateTimeObj->setTimestamp($scheduledBatch['time']);

                                        $dateScheduled = \PHPExcel_Shared_Date::PHPToExcel($schedDateTimeObj);
                                    }


                                    $dateProduced = '';
                                    $thisLineBatchesCompleted = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Completed', 'sherry_batch_id' => $batchValue]])->toArray();
                                    foreach ($thisLineBatchesCompleted as $producedBatch) {
                                        //$dateProduced = date('n/j/Y',$producedBatch['time']);
                                        $prodDateTimeObj = new \DateTime();
                                        $prodDateTimeObj->setTimestamp($producedBatch['time']);

                                        $dateProduced = \PHPExcel_Shared_Date::PHPToExcel($prodDateTimeObj);
                                    }

                                    $dateInvoiced = '';
                                    $invoiceNumber = '';

                                    //look up whether this line has been Invoiced, if so, populate the variable
                                    $thisLineBatchesInvoiced = $this->OrderItemStatus->find('all', ['conditions' => ['order_item_id' => $orderItem['id'], 'status' => 'Invoiced', 'sherry_batch_id' => $batchValue]])->toArray();
                                    foreach ($thisLineBatchesInvoiced as $invoicedBatch) {
                                        //$dateInvoiced = date('n/j/Y',$invoicedBatch['time']);
                                        $invDateTimeObj = new \DateTime();
                                        $invDateTimeObj->setTimestamp($invoicedBatch['time']);

                                        $invoiceNumber = $invoicedBatch['invoice_number'];

                                        $dateInvoiced = \PHPExcel_Shared_Date::PHPToExcel($invDateTimeObj);
                                    }



                                    //recalc and override the TOTAL LF, TOTAL YARDS, EXTENDED PRICE variables for [this qty]
                                    if ($orderRow['project_manager_id'] == 0 || is_null($orderRow['project_manager_id'])) {
                                        $managerName = 'N/A';
                                    } else {
                                        $pmLookup = $this->Users->get($orderRow['project_manager_id'])->toArray();
                                        $managerName = $pmLookup['first_name'] . ' ' . $pmLookup['last_name'];
                                    }

                                    $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $orderRow['order_number']);

                                    $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $orderRow['status']);

                                    //$objPHPExcel->getActiveSheet()->SetCellValue('C'.$rowCount, $quoteNumberValue);


                                    if (!is_null($orderRow['type_id']) && $orderRow['type_id'] > 0) {
                                        $thisType = $this->QuoteTypes->get($orderRow['type_id'])->toArray();
                                        $thisOrderType = $thisType['type_label'];
                                    } else {
                                        $thisOrderType = '';
                                    }

                                    $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $thisOrderType);

                                    $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $orderRow['stage']);

                                    $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $managerName);

                                    $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $customerValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $customerPOValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $facilityValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $shipDateValue);
                                    $objPHPExcel->getActiveSheet()->getStyle('I' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $dateScheduled);
                                    $objPHPExcel->getActiveSheet()->getStyle('J' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $thisbookingdate);
                                    $objPHPExcel->getActiveSheet()->getStyle('K' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $batchValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowCount, $lineNumberValue);
                                    //$objPHPExcel->getActiveSheet()->SetCellValue('O'.$rowCount, $locationValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowCount, $qtyValue);


                                    $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowCount, $classValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowCount, $subclassValue);


                                    $objPHPExcel->getActiveSheet()->SetCellValue('Q' . $rowCount, $unitValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('R' . $rowCount, $lineItemValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('S' . $rowCount, $fabricrichText);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('T' . $rowCount, $colorrichText);
                                    //$objPHPExcel->getActiveSheet()->SetCellValue('W'.$rowCount, $cutwidthValue);
                                    //$objPHPExcel->getActiveSheet()->SetCellValue('X'.$rowCount, $finwidthValue);
                                    //$objPHPExcel->getActiveSheet()->SetCellValue('Y'.$rowCount, $lengthrichText);
                                    //$objPHPExcel->getActiveSheet()->SetCellValue('Z'.$rowCount, $cclfValue);

                                    //$objPHPExcel->getActiveSheet()->SetCellValue('AA'.$rowCount, $drapewidthsValue);
                                    //$objPHPExcel->getActiveSheet()->SetCellValue('AB'.$rowCount, $ttlfValue);

                                    //$objPHPExcel->getActiveSheet()->SetCellValue('AC'.$rowCount, $ydsperunitValue);


                                    $objPHPExcel->getActiveSheet()->SetCellValue('U' . $rowCount, $totalydsvalue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('V' . $rowCount, $basePriceValue);
                                    //$objPHPExcel->getActiveSheet()->SetCellValue('AF'.$rowCount, $breakdownrichText);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('W' . $rowCount, $adjustedColValue);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('X' . $rowCount, $extendedprice);



                                    $objPHPExcel->getActiveSheet()->SetCellValue('Y' . $rowCount, $dateProduced);
                                    $objPHPExcel->getActiveSheet()->getStyle('Y' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('Z' . $rowCount, $dateShipped);
                                    $objPHPExcel->getActiveSheet()->getStyle('Z' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('AA' . $rowCount, $trackingNumber);
                                    $objPHPExcel->getActiveSheet()->SetCellValue('AB' . $rowCount, $dateInvoiced);
                                    $objPHPExcel->getActiveSheet()->getStyle('AB' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                                    $objPHPExcel->getActiveSheet()->SetCellValue('AC' . $rowCount, $invoiceNumber); //INV#

                                    $objPHPExcel->getActiveSheet()->SetCellValue('AD' . $rowCount, $linenotesrichText);




                                    if ($rowCount % 2 == 0) {
                                        $thisrowcolor = 'F8F8F8';
                                    } else {
                                        $thisrowcolor = 'FFFFFF';
                                    }

                                    $objPHPExcel->getActiveSheet()->getStyle('A' . $rowCount . ':AD' . $rowCount)->applyFromArray(
                                        array(
                                            'fill' => array(
                                                'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                                                'color' => array('rgb' => $thisrowcolor)
                                            )
                                        )
                                    );

                                    $brlines = explode("<br", $itemDescription);
                                    if (count($brlines) < 5) {
                                        $rowheight = 90;
                                    } elseif (count($brlines) >= 5 && count($brlines) < 8) {
                                        $rowheight = 120;
                                    } else {
                                        $rowheight = 145;
                                    }

                                    $objPHPExcel->getActiveSheet()->getRowDimension($rowCount)->setRowHeight($rowheight);

                                    $rowCount++;
                                }
                            }
                        }
                    }
                }
            }

            $objPHPExcel->getActiveSheet()->getStyle('A1:A' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('B1:B' . $rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('C1:C'.$rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('C1:C' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('D1:D' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('E1:E' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('F1:F' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('G1:G' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('H1:H' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('I1:I' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('J1:J' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('K1:K' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('L1:L' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('M1:M' . $rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('O1:O'.$rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('N1:N' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('O1:O' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('P1:P' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('Q1:Q' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('R1:R' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('S1:S' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('T1:T' . $rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('W1:W'.$rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('X1:X'.$rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('Y1:Y'.$rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('Z1:Z'.$rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('AA1:AA'.$rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('AB1:AB'.$rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('AC1:AC'.$rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('U1:U' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('V1:V' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('W1:W' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('X1:X' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('Y1:Y' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('Z1:Z' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AA1:AA' . $rowCount)->getAlignment()->setHorizontal('center');
            //$objPHPExcel->getActiveSheet()->getStyle('AK1:AK'.$rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AB1:AB' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('AC1:AC' . $rowCount)->getAlignment()->setHorizontal('center'); //INV#
            $objPHPExcel->getActiveSheet()->getStyle('AD1:AD' . $rowCount)->getAlignment()->setHorizontal('left');


            $objPHPExcel->getActiveSheet()->getStyle('A1:AD' . $rowCount)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);

            $objPHPExcel->getActiveSheet()->getStyle('A1:AD' . $rowCount)->getAlignment()->setWrapText(true);



            $objPHPExcel->getActiveSheet()->getStyle("A1:AD" . $rowCount)->applyFromArray(
                array(
                    'borders' => array(
                        'allborders' => array(
                            'style' => \PHPExcel_Style_Border::BORDER_THIN,
                            'color' => array('rgb' => '111111')
                        )
                    )
                )
            );

            $objPHPExcel->getActiveSheet()->freezePane('A2');

            // Redirect output to a client’s web browser (Excel5)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="QB Reconciliation Report - ' . $this->request->data['report_date_start'] . ' thru ' . $this->request->data['report_date_end'] . '.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');

            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0

            $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
        } else {
            //show the form
            //get all the users for filtering by user
            $allUsers = $this->Users->find('all', ['conditions' => ['status' => 'Active'], 'order' => ['first_name' => 'asc', 'last_name' => 'asc']])->toArray();
            $this->set('allUsers', $allUsers);

            $allCustomers = $this->Customers->find('all', ['order' => ['company_name' => 'asc']])->toArray();
            $this->set('allCustomers', $allCustomers);

            $quoteTypes = $this->QuoteTypes->find('all', ['order' => ['type_label' => 'asc']])->toArray();
            $this->set('quoteTypes', $quoteTypes);
        }
    }

    /**PPSA-40 start **/
public function quotesnewlines() {
        if ($this->request->data) {
            $this->autoRender = false;
            $productMap = array('cubicle-curtain' => 'Cubicle Curtain', 'box-pleated' => 'Box Pleated Valance', 'straight-cornice' => 'Straight Cornice', 'bedspread' => 'Calculated Bedspread', 'bedspread-manual' => 'Manually Entered Bedspread', 'pinch-pleated' => 'Pinch Pleated Drapery');
            $startTS = strtotime($this->request->data['report_date_start'] . ' 00:00:00');
            $endTS = strtotime($this->request->data['report_date_end'] . ' 23:59:59');
            $db = ConnectionManager::get('default');
            $query = "SELECT quote_line_items.created AS  CREATED, ";
            $query .= "users.first_name  AS CREATEDBY,users.last_name  AS CREATEDLASTBY, quotes.quote_number, ";
            $query .= "quote_types.type_label AS QUOTETYPE, quotes.status AS QUOTESTATUS, customers.company_name AS CUSTOMER, ";
            $query .= "IF(quotes.order_number IS NULL, quotes.title, orders.facility) AS RECIPIENT, ";
            $query .= "quote_line_items.line_number, quote_line_items.qty, quote_line_items.product_class, ";
            $query .= "	IF(quote_line_items.override_active=1, quote_line_items.override_price, quote_line_items.pmi_adjusted) AS PRICEEA,";
            $query .= " quote_line_items.extended_price,";
            $query .= "  quotes.order_number";
            $query .= " FROM quote_line_items";
            $query .= " JOIN quotes ON quotes.id = quote_line_items.quote_id";
            $query .= " JOIN users ON users.id = quotes.created_by";
            $query .= " JOIN quote_types ON quote_types.id = quotes.type_id";
            $query .= " JOIN customers ON customers.id   = quotes.customer_id";
            $query .= " LEFT JOIN orders ON orders.order_number = quotes.order_number";
            $query .= " WHERE  ";
            $query .= " quote_line_items.created >= " . $startTS . " AND quote_line_items.created <= " . $endTS;
            if (strlen($this->request->data['customer_id']) > 0) {
                $query .= " AND quotes.customer_id=" . $this->request->data['customer_id'];
            }
            if (strlen($this->request->data['quote_type']) > 0) {
                $query .= " AND quotes.type_id = " . $this->request->data['quote_type'];
            }
            if ($this->request->data['filterbyuser'] != 'allusers') {
                $query .= " AND orders.user_id = " . $this->request->data['filterbyuser'];
            }
            if (isset($this->request->data['revision']) &&  $this->request->data['revision'] == 'yes') {
            } else {
                $query .= " AND quotes.parent_quote = 0";
            }
            /* if ($this->request->data['revision'] == 'yes') {
                $query.= " AND quotes.revision >= 0 ";
            } else {
                $query.= " AND quotes.revision = 0 ";
            }*/
            $query .= " ORDER BY quote_line_items.created ASC";
            // print_r($query);
            $queryRun = $db->execute($query);
            $ordersLookup = $queryRun->fetchAll('assoc');
            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");
            $objPHPExcel = new \PHPExcel();
            $objPHPExcel->setActiveSheetIndex(0);
            $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'CREATED DATE #');
            $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'CREATED BY');
            $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'QUOTE #');
            $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'QUOTE TYPE');
            $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'QUOTE STATUS');
            $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'CUSTOMER');
            $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'RECIPIENT');
            $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'LINE #');
            $objPHPExcel->getActiveSheet()->SetCellValue('I1', 'QTY');
            $objPHPExcel->getActiveSheet()->SetCellValue('J1', 'CLASS');
            $objPHPExcel->getActiveSheet()->SetCellValue('K1', 'ADJ PRICE');
            $objPHPExcel->getActiveSheet()->SetCellValue('L1', 'EXT PRICE');
            $objPHPExcel->getActiveSheet()->SetCellValue('M1', 'ORDER #');

            $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(40);
            $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
            $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(55);
            $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
            $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(22);
            $objPHPExcel->getActiveSheet()->getStyle('A1:M1')->getAlignment()
                ->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $objPHPExcel->getActiveSheet()->getStyle('A1:M1')
                ->applyFromArray(array('fill' =>
                array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => 'F8CBAD')
                )));
            $rowCount = 2;
            $outputArr = array();

            foreach ($ordersLookup as $orderRow) {
                $thisClass = $this->ProductClasses
                    ->get($orderRow['product_class'])->toArray();
                $classValue = $thisClass['class_name'];

                $publishedDateTimeObj = new \DateTime();
                $publishedDateTimeObj->setTimestamp($orderRow['CREATED']);
                $thispublisheddate = \PHPExcel_Shared_Date::PHPToExcel($publishedDateTimeObj);
                $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $thispublisheddate);
                $objPHPExcel->getActiveSheet()->getStyle('A' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');
                $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $orderRow['CREATEDBY'] . ' ' . $orderRow['CREATEDLASTBY']);
                $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $orderRow['quote_number']);
                $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $orderRow['QUOTETYPE']);
                $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $orderRow['QUOTESTATUS']);
                $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $orderRow['CUSTOMER'] ? $orderRow['CUSTOMER'] : '');
                $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $orderRow['RECIPIENT']);
                $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $orderRow['line_number']);
                $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $orderRow['qty']);
                $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $classValue);
                $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $orderRow['PRICEEA']);
                $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $orderRow['extended_price']);
                $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowCount, $orderRow['order_number']);

                if ($rowCount % 2 == 0) {
                    $thisrowcolor = 'F8F8F8';
                } else {
                    $thisrowcolor = 'FFFFFF';
                }
                $objPHPExcel->getActiveSheet()
                    ->getStyle('A' . $rowCount . ':M' . $rowCount)
                    ->applyFromArray(array('fill' => array('type'
                    => \PHPExcel_Style_Fill::FILL_SOLID, 'color'
                    => array('rgb' => $thisrowcolor))));
                //$objPHPExcel->getActiveSheet()
                //->getRowDimension($rowCount)->setRowHeight($rowheight);
                $rowCount++;
            }

            $objPHPExcel->getActiveSheet()->getStyle('A1:A' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('B1:B' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('C1:C' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('D1:D' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('E1:E' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('F1:F' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('G1:G' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('H1:H' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('I1:I' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('J1:J' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('K1:K' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('L1:L' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle('M1:M' . $rowCount)->getAlignment()->setHorizontal('center');
            $objPHPExcel->getActiveSheet()->getStyle("A1:M1" . $rowCount)
                ->applyFromArray(array('borders' => array('allborders'
                => array(
                    'style' => \PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('rgb' => '111111')
                ))));
            $objPHPExcel->getActiveSheet()->freezePane('A2');

            // Redirect output to a client’s web browser (Excel5)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="Quotes NewLines Created Report-' . $this->request->data['report_date_start'] . '-' . $this->request->data['report_date_end'] . '.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');
            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0
            $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
        } else {
            //show the form
            //get all the users for filtering by user
            $allUsers = $this->Users->find('all', ['conditions' => ['status' => 'Active'], 'order' => ['first_name' => 'asc', 'last_name' => 'asc']])->toArray();
            $this->set('allUsers', $allUsers);
            $allCustomers = $this->Customers->find('all', ['order' => ['company_name' => 'asc']])->toArray();
            $this->set('allCustomers', $allCustomers);
            $quoteTypes = $this->QuoteTypes->find('all', ['order' => ['type_label' => 'asc']])->toArray();
            $this->set('quoteTypes', $quoteTypes);
        }
    }
    /**PPSA-40 end **/


    //PPSASCRUM-216 start

	public function consolidateddraftquotes(){
        if ($this->request->data) {
            $this->autoRender = false;

            $startTS = strtotime($this->request->data['report_date_start'] . ' 00:00:00');
            $endTS = strtotime($this->request->data['report_date_end'] . ' 23:59:59');


            $db = ConnectionManager::get('default');
            $query = "SELECT * FROM `quotes` WHERE `status` = 'draft' AND `created` >= " . $startTS . " AND `created` <= " . $endTS . " AND `revision` IS NULL AND `parent_quote`=0 ";
            if ($this->request->data['filterbyuser'] != 'allusers') {
                $query .= " AND `created_by` = " . $this->request->data['filterbyuser'];
            }

            if (strlen($this->request->data['customer_id']) > 0) {
                $query .= " AND `customer_id`=" . $this->request->data['customer_id'];
            }

            if (strlen($this->request->data['quote_type']) > 0) {
                $query .= " AND `type_id` = " . $this->request->data['quote_type'];
            }

            if ($this->request->data['dollarfilter'] == 'yes') {
                $query .= " AND `quote_total` >= " . $this->request->data['dollar_min'];
            }

            $query .= " ORDER BY `created` DESC";
            $queryRun = $db->execute($query);
            $quotesLookup = $queryRun->fetchAll('assoc');


            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel.php");
            require($_SERVER['DOCUMENT_ROOT'] . "/vendor/phpoffice/phpexcel/Classes/PHPExcel/Writer/Excel2007.php");

            $objPHPExcel = new \PHPExcel();
            $objPHPExcel->setActiveSheetIndex(0);


            $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'QUOTE NUMBER');
            $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'CUSTOMER');
            $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'CREATED BY');
            $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'CREATED DATE');
            $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'MODIFIED DATE');
            $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'QUOTE TITLE/PROJECT');
            $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'TYPE');
            $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'TOTALS');
            $objPHPExcel->getActiveSheet()->SetCellValue('I1', 'CC LF');
            $objPHPExcel->getActiveSheet()->SetCellValue('J1', 'TRK LF');
            $objPHPExcel->getActiveSheet()->SetCellValue('K1', 'BS QTY');
            $objPHPExcel->getActiveSheet()->SetCellValue('L1', 'DRAPERIES WIDTHS');
            $objPHPExcel->getActiveSheet()->SetCellValue('M1', 'TOP TREATMENTS QTY');
            $objPHPExcel->getActiveSheet()->SetCellValue('N1', 'TOP TREATMENT LF');
            $objPHPExcel->getActiveSheet()->SetCellValue('O1', 'WT HW QTY');
            $objPHPExcel->getActiveSheet()->SetCellValue('P1', 'B&S QTY');


            $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(24);

            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(16);

            $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(42);
            $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(14);
            $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(16);
            $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
            $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
            $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(12);
            $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
            $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(18);
            $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(22);
            $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(22);
            $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(12);



            $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(18);
            $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);


            $objPHPExcel->getActiveSheet()->getStyle('A1:P1')->applyFromArray(
                array(
                    'fill' => array(
                        'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('rgb' => 'F8CBAD')
                    )
                )
            );


            $rowCount = 2;

            $outputArr = array();
            foreach ($quotesLookup as $quote) {

                if (!is_null($quote['type_id']) && $quote['type_id'] > 0) {
                    $thisType = $this->QuoteTypes->get($quote['type_id'])->toArray();
                    $thisQuoteType = $thisType['type_label'];
                } else {
                    $thisQuoteType = '';
                }


                $totals = number_format(floatval($quote['quote_total']), 2, '.', '');


                $customerData = $this->Customers->get($quote['customer_id'])->toArray();
                $userData = $this->Users->get($quote['created_by'])->toArray();

                $projectname = '';
                if ($quote['project_id'] > 0) {
                    $projectData = $this->Projects->get($quote['project_id'])->toArray();
                    $projectname = $quote['title'] . ' / ' . $projectData['title'];
                } else {
                    $projectname = $quote['title'];
                }



                $numitems = 0;
                $quoteitems = $this->QuoteLineItems->find('all', ['conditions' => ['quote_id' => $quote['id']]])->toArray();
                foreach ($quoteitems as $quoteitem) {
                    $numitems = ($numitems + $quoteitem['qty']);
                }


                $cclf = $this->getTypeLF($quote['id'], 'cc');
                $tracklf = $this->getTypeLF($quote['id'], 'track');
                $bsqty = $this->getTypeQty($quote['id'], 'bs');
                $drapewidths = $this->getTypeWidths($quote['id'], 'drapes');
                $ttqty = $this->getTypeQty($quote['id'], 'tt');
                $ttlf = $this->getTypeLF($quote['id'], 'tt');
                $wthwqty = $this->getTypeQty($quote['id'], 'wthw');
                $blindsqty = $this->getTypeQty($quote['id'], 'blinds');


                if ($quote['order_number'] > 0) {
                    $ordernumber = $quote['order_number'];
                } else {
                    $ordernumber = '';
                }


                $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, $quote['quote_number']);
                $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, $customerData['company_name']);
                $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, $userData['first_name'] . ' ' . $userData['last_name']);

                //$objPHPExcel->getActiveSheet()->SetCellValue('D'.$rowCount, date('m/d/Y',$quote['publish_date']));
                $publishedDateTimeObj = new \DateTime();
                $publishedDateTimeObj->setTimestamp($quote['created']);
                $thispublisheddate = \PHPExcel_Shared_Date::PHPToExcel($publishedDateTimeObj);
                $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $thispublisheddate);
                $objPHPExcel->getActiveSheet()->getStyle('D' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');


                $modifiedDateTimeObj = new \DateTime();
                $modifiedDateTimeObj->setTimestamp($quote['modified']);
                $thismodifieddate = \PHPExcel_Shared_Date::PHPToExcel($modifiedDateTimeObj);
                $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, $thismodifieddate);


                $objPHPExcel->getActiveSheet()->getStyle('E' . $rowCount)->getNumberFormat()->setFormatCode('mm/dd/yyyy');

                $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $projectname);
                $objPHPExcel->getActiveSheet()->SetCellValue('G' . $rowCount, $thisQuoteType);
                $objPHPExcel->getActiveSheet()->SetCellValue('H' . $rowCount, $totals);
                $objPHPExcel->getActiveSheet()->SetCellValue('I' . $rowCount, $cclf);
                $objPHPExcel->getActiveSheet()->SetCellValue('J' . $rowCount, $tracklf);
                $objPHPExcel->getActiveSheet()->SetCellValue('K' . $rowCount, $bsqty);
                $objPHPExcel->getActiveSheet()->SetCellValue('L' . $rowCount, $drapewidths);
                $objPHPExcel->getActiveSheet()->SetCellValue('M' . $rowCount, $ttqty);
                $objPHPExcel->getActiveSheet()->SetCellValue('N' . $rowCount, $ttlf);
                $objPHPExcel->getActiveSheet()->SetCellValue('O' . $rowCount, $wthwqty);
                $objPHPExcel->getActiveSheet()->SetCellValue('P' . $rowCount, $blindsqty);

                $rowCount++;
            }


            //echo "<pre>"; print_r($outputArr); echo "</pre>";exit;

            $objPHPExcel->getActiveSheet()->getRowDimension(($rowCount - 1))->setRowHeight(-1);
            $objPHPExcel->getActiveSheet()->getStyle('A2:P' . ($rowCount - 1))->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            $objPHPExcel->getActiveSheet()->getStyle('A2:P' . ($rowCount - 1))->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_TOP);
            $objPHPExcel->getActiveSheet()->getStyle('A2:P' . ($rowCount - 1))->getAlignment()->setWrapText(true);

            // Redirect output to a client’s web browser (Excel5)
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="Consolidated Draft Quotes Report - ' . $this->request->data['report_date_start'] . ' thru ' . $this->request->data['report_date_end'] . '.xlsx"');
            header('Cache-Control: max-age=0');
            // If you're serving to IE 9, then the following may be needed
            header('Cache-Control: max-age=1');

            // If you're serving to IE over SSL, then the following may be needed
            header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
            header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
            header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
            header('Pragma: public'); // HTTP/1.0

            $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
            $objWriter->save('php://output');
        } else {
            //show the form
            //get all the users for filtering by user
            $allUsers = $this->Users->find('all', ['conditions' => ['status' => 'Active'], 'order' => ['first_name' => 'asc', 'last_name' => 'asc']])->toArray();
            $this->set('allUsers', $allUsers);

            $allCustomers = $this->Customers->find('all', ['order' => ['company_name' => 'asc']])->toArray();
            $this->set('allCustomers', $allCustomers);
            $quoteTypes = $this->QuoteTypes->find('all', ['order' => ['type_label' => 'asc']])->toArray();
            $this->set('quoteTypes', $quoteTypes);

            $this->set('bigquotestart', $this->getSettingValue('bq_qualifying_amount'));
        }
    }
    //PPSASCRUM-216 end
}
